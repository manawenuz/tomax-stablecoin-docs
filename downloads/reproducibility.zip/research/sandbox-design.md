# Funded FXSwap adversarial sandbox

The user requests a diagnosis and a mocked system around FXSwap, with finite actors seeking value, a keeper handling peg and liquidations, historical fortnights first and then a fourteen-day live paper run. This is a research simulator, not deployed lending contracts or real trading. Preserve 96% LP / 4% ETH for each new issuance bundle, 87.4% LP origination LTV, 75% ETH origination LTV and external seed capital as the main denominator.

## Diagnosis and testable remedy

The prior proportional LP-entry route adds liquidity as it sells debt. With no outside own tokens and a stale FXSwap center, its price impact becomes small and can converge above peg. Borrowing caps compound the problem; lifting them alone is insufficient. The internal trade EMA cannot learn an inaccessible external price, and refuels must fund a real recenter loss after release/protection.

Compare the original issuance-only controller with a keeper that uses its own finite seed LP and inventory. To move price down it may withdraw treasury LP proportionally and sell the recovered own token; to move price up it may sell recovered quote after a proportional withdrawal. Normal one-sided deposits or ordinary inventory swaps can recycle the resulting holdings. These paths use existing FXSwap operations and do not mint unbacked tokens. Treasury LP ownership, cash, own tokens, bootstrap liability, gas and loss are explicit. Parameter choices such as lower amplification are set at launch, not teleported during a run. Test original and lower-A pools before selecting the historical policy.

## Accounting and actions

- Every actor has quote, ETH, own-token and unlocked LP wallets. Vaults separately hold locked LP or ETH. Token minting is matched by vault principal or recorded bootstrap liability; debt burning and collateral netting reconcile supply. Refuels have no owner and remain separate from redeemable LP claims.
- A paired origination buys the entire LP own-token leg, deposits and locks it, issues 96/4 debt and sells both branches. Require funded gross input and gas, an authenticated nonstale mock FX report, and post-action health. Repayment/liquidation can change the outstanding mix; report it and suppress extra ETH issuance when its outstanding share exceeds 4%. Exact 96/4 outstanding after independent repayments would require involuntary paired actions, so do not claim that invariant.
- Mock reports expose timestamp, sequence, last known FX and ETH. The simulator knows historical marks for evaluation, while policies only see observations available at their event time. Outages halt risk-increasing actions. Signed cryptography is mocked, with replay/freshness rules tested.
- Liquidation is a funded transition. Liquidator supplies debt tokens, receives a capped collateral bonus and borrower surplus is preserved. LP collateral is recovered and controlled own tokens can atomically offset debt. A keeper can take over residual funded inventory only within its capital; shortfalls remain recorded rather than disappearing. Queue marking does not count as settlement. ETH venue and gas sinks have explicit inventories/accounts.
- Test adversarial trade sizing, manipulated pool composition before borrowing, stale-report borrowing, borrow/sell/repay loops, LP entry/exit around keeper/refuel actions, concentrated exits, borrower refusal and keeper outages. Profits are measured against actual initial wealth and holding, with own-token marks separated from realizable quote.

## Experiment and acceptance

Objectively select calm and volatile training fortnights plus a disjoint volatile holdout before policy P&L. Use actual archived closes; include cached native minute data where available. Missing minute history is not interpolated into supposed real ticks. Extra actor/keeper events between hourly observations use a stated last-observed feed. Report pre-keeper and post-keeper prices, fee-inclusive bid/ask, finite-size execution, price gaps, stale intervals, capital exhaustion, issuance/settlement restrictions, actor and treasury cash flows, credit loss and gas.

The operational target is a 1% control band with a 3% evaluation tolerance. A permissionless raw AMM cannot guarantee that every arbitrary trade or unseen FX jump stays inside 3% with finite capital. Success means a declared sampled response/funding envelope; stress failures remain visible. Do not select on the holdout. A passing historical candidate may proceed to paper mode; no real funds, wallet keys, chain submissions or exchange orders are permitted.

## Live stage

Persist checkpoints, configuration and append-only events for fourteen actual days. Process only data observed at retrieval, keep explicit observation age, and pause on feed failures. The recurring monitor must report actionable failures and the final study result, remain quiet otherwise, and never silently tune parameters using future data. The host/runtime and start/end dates are recorded once live mode starts; scheduling is not evidence that fourteen days have already elapsed.

## Implementation units

`model/sandbox/state.py`: finite wallets, custody, origination, repayment, liquidation, supply/asset invariants and atomic rollback. `model/sandbox/policies.py`: keeper and adversarial action selection. `model/sandbox/simulate.py`: causal event clock, feed views, experiment runner and metrics. `model/sandbox/paper.py`: persisted live paper state and public-feed observation. `tools/run_sandbox.py`: reproducible training/holdout/stress suite. `tests/test_sandbox.py`: economic and causal invariants. `evm/` and `tools/check_fxswap_evm.py`: local execution of pinned actual FXSwap contracts with mocked tokens/periphery for parity checks. `research/sandbox_data/`: independent input selection, coverage and hashes. Documentation and downloads extend the existing private research/public Pages workflow.
