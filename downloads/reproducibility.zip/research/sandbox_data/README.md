# Fortnight replay inputs: complete hourly observations, partial native minutes

These are three **disjoint 14-day market paths selected before policy P&L**.
Every path has 336 observed IRR/USDT hourly candles and 336 observed ETH/USDT
hourly candles, plus one preceding hour for causal initial marks. The archived
native minute data is **partial: 7,200 / 60,480 requested timestamps**. Missing
minute prices are not interpolated, forward filled or invented.

## Fixed selection

The previously archived 180-day IRR hourly input has 166 candidate windows
beginning at Asia/Tbilisi midnight. Strict eligibility requires every one of
336 hourly bars and the preceding-hour bar to exist with positive reported
volume. This leaves 137 eligible windows; 29 fail. No eligibility rule was
relaxed. Complete candidate metrics and exclusion reasons are in
[`window_metrics.csv`](window_metrics.csv); the fixed rule and input SHA-256
are in [`selected_windows.json`](selected_windows.json).

Hourly realized volatility is
`sqrt(sum_(h=1..336)(ln(C_h / C_(h-1)))^2)`, using the observed preceding-hour
close as `C_0`. It is dimensionless and not annualized. Select the minimum-RV
eligible window for calm training, then the maximum-RV eligible window disjoint
from it for volatile training, then the maximum-RV eligible window disjoint
from both for the volatile holdout. Ties use the earliest start date. No policy
results or future actor schedules enter this choice.

| ID | Local dates, end exclusive | Hourly RV | IRR/USDT preceding close to last close | Native minute coverage |
|---|---|---:|---:|---:|
| `calm_train` | 2026-08-05 → 2026-08-19 | 2.96799% | −0.73730% | 4,320 / 20,160 |
| `volatile_train` | 2026-04-28 → 2026-05-12 | 9.71336% | +13.89118% | 0 / 20,160 |
| `volatile_holdout` | 2026-06-07 → 2026-06-21 | 9.13601% | −8.90557% | 2,880 / 20,160 |

This is retrospective market-path selection. The holdout is a disjoint path to
withhold from policy calibration; its volatility was chosen from the full
history. It is **not temporal forward validation**. After evaluating or tuning
on its outcomes, it is no longer an untouched holdout. The calm training path
is later in time than the holdout.

Local midnight is 20:00 UTC on the preceding date. For example `calm_train`
runs from `2026-08-04T20:00:00Z` to `2026-08-18T20:00:00Z` exclusively.
Positive IRR/USDT returns mean rial depreciation. Token parity in USDT per
rial is reciprocal: `parity_return = 1/(1 + IRR_USDT_return) - 1`.

## Replay files and clocks

Use the following **complete observed hourly inputs** for the primary replay:

- [`IRR_1h_calm_train.csv`](IRR_1h_calm_train.csv) and [`ETH_USDT_1h_calm_train.csv`](ETH_USDT_1h_calm_train.csv)
- [`IRR_1h_volatile_train.csv`](IRR_1h_volatile_train.csv) and [`ETH_USDT_1h_volatile_train.csv`](ETH_USDT_1h_volatile_train.csv)
- [`IRR_1h_volatile_holdout.csv`](IRR_1h_volatile_holdout.csv) and [`ETH_USDT_1h_volatile_holdout.csv`](ETH_USDT_1h_volatile_holdout.csv)

Each file has 337 bars: the preceding-hour bar plus 336 replay hours. The
preceding bar closes exactly at replay start. Each selected hourly FX and ETH
subset has no missing timestamps or zero-volume bars.

`timestamp` is the candle **open** in Unix seconds UTC. Its close becomes
available only at `candle_end_timestamp`, exclusively. At a synthetic actor
event between actual observations, reveal only the latest close whose end
timestamp is at or before the event. Keep its age explicit. Repeated use of a
last-known hourly mark is controller state, **not a newly observed minute
price**. Do not reveal the following hourly close or construct a high/low
ordering. Neither these inputs nor such a replay establish continuous or
intra-hour 3% parity compliance. A live feed timeout should make input stale
and pause oracle-dependent actions according to the controller's staleness
rule; it supplies no new price and says nothing about whether the market moved.

The optional `IRR_1m_{id}.csv` files contain only native minute observations
for available days; the volatile training file is header-only. These are not
complete fortnight minute paths:

| Local day | Window | Minute bars | Zero-volume minutes | Acquisition |
|---|---|---:|---:|---|
| 2026-08-06 | calm training | 1,440 | 107 | Newly downloaded |
| 2026-08-08 | calm training | 1,440 | 129 | Newly downloaded |
| 2026-08-12 | calm training | 1,440 | 190 | Exact existing raw cache reused |
| 2026-06-09 | volatile holdout | 1,440 | 206 | Exact existing raw cache reused |
| 2026-06-15 | volatile holdout | 1,440 | 18 | Exact existing raw cache reused |

Each available day has all 1,440 timestamps at verified native 60-second
spacing. The 650 zero-volume minutes remain exchange-supplied candles, not
independently observed trades. All 53,280 unavailable minute timestamps are
disclosed in the manifest. No full-minute coverage is implied for any window.

Fresh requests on 2026-10-21 suffered intermittent connection/TLS timeouts and
`RemoteDisconnected` errors. Two new days returned successfully; further
stalled workers were stopped. A direct Binance public API check returned HTTP
200, so this was an observed Wallex connection problem from the collecting
environment, not evidence that all market sources were unavailable. The
official Wallex API documentation identifies `https://api.wallex.ir` as its
API host; an alternate source or unverified host was not substituted.

## Provenance and quality

[`manifest.json`](manifest.json) records normalized CSV hashes, exact daily
request URLs, raw-response hashes, retrieval timestamps, native minute coverage,
zero-volume counts and units. `windows[].hourly_fx` identifies complete hourly
FX files; `windows[].eth_collateral` identifies corresponding hourly ETH files;
`windows[].csv_file` identifies the **partial optional minute** files.
`unavailable_minute_days` lists all 37 unavailable days and their intended request URLs. The absence
of a payload or a cache is not proof that the exchange lacks historical bars.

Raw minute response bytes and metadata live in [`raw/`](raw/). Normalized daily
minute CSVs live in [`daily/`](daily/). [`sources/`](sources/) contains immutable
copies and provenance metadata for the selection hourly input, full ETH hourly
archive and original source manifests. The source hourly archive and existing
FXSwap day archive were not edited.

Wallex's `USDTTMN` is USDT quoted in Toman. Native OHLC is multiplied by exactly
10 to produce **IRR per USDT**; reported base volume remains USDT. Binance
`ETHUSDT` prices are **USDT per ETH**, with ETH base volume and USDT quote
volume. Source metadata and request hashes are retained in copied manifests.
Treating USDT as USD requires the separate USDT/USD parity assumption.

The [`hourly aggregation comparison`](hourly_aggregation_comparison.json)
compares all 120 available complete minute-hours with the prior hourly input
using exact Decimal arithmetic. Closes, lows and volume all match. Ten opens
and two highs differ; these are disclosed individually and not reconciled.
Selection uses the fixed prior hourly close archive; optional minute replay
uses the archived native minute data.

These are single-exchange candles, not an official central-bank fixing or an
executable cross-venue FX composite. OHLC does not identify within-bar high/low
order, spreads, depth, actual fills, slippage or continuous oracle compliance.
The ETH input remains hourly, including on days with native minute FX data.

## Reproduction

From the repository root, with Python 3.11+ and its standard library:

```sh
python3 tools/fetch_sandbox_data.py --offline --cached-only
```

This verifies archived input and raw cache hashes, repeats window selection,
normalizes every available native minute response, rebuilds complete hourly
subsets and partial minute files, then writes coverage and quality disclosures.
It performs no network requests. Generated-at timestamps can change; data CSVs
and selection artifacts are deterministic. Run without `--offline` to attempt
missing public minute downloads under the default 120-second request budget.
`--require-complete-minute` exits unsuccessfully after saving coverage if any
native minute data is unavailable. `--refresh` intentionally replaces snapshots
and responses with a new observation; exchange history may change.
