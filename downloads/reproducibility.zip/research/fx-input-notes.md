# Historical intraday FX inputs: provenance and limitations

These are downloaded exchange candles, not generated price paths. The common
requested window is **2026-04-24 00:00:00 UTC through 2026-10-21 00:00:00 UTC
exclusive**, covering 180 complete days. The last included candle opens at
2026-10-20 23:00:00 UTC. Responses were retrieved on 2026-10-21 between
11:30:03 and 11:30:11 UTC; exact retrieval timestamps, exchange HTTP dates,
request URLs, filenames and SHA-256 hashes are in
[`fx_inputs/manifest.json`](fx_inputs/manifest.json).

| Currency | Primary market | Native quote | Normalized prices | Observed / expected hours | Missing hours | Supplied zero-volume hours |
|---|---|---|---|---:|---:|---:|
| IRR | Wallex `USDTTMN` | Toman per USDT | IRR per USDT; native OHLC multiplied by 10 | 4,303 / 4,320 | 17 | 185 |
| TRY | Binance spot `USDTTRY` | TRY per USDT | TRY per USDT; unchanged | 4,320 / 4,320 | 0 | 0 |
| ARS | Binance spot `USDTARS` | ARS per USDT | ARS per USDT; unchanged | 4,320 / 4,320 | 0 | 0 |

The CSVs are [`IRR_1h.csv`](fx_inputs/IRR_1h.csv),
[`TRY_1h.csv`](fx_inputs/TRY_1h.csv), and
[`ARS_1h.csv`](fx_inputs/ARS_1h.csv). Every CSV uses the columns `timestamp`,
`datetime_utc`, `open`, `high`, `low`, `close`, `volume_usdt`. Timestamps identify
the candle **open** in Unix seconds and UTC. All prices are currency units per
one USDT. Volume is native base-asset volume in USDT. Decimal response precision
is preserved; the CSV writer does not round to a fixed number of places.

## Official sources and conventions

**Wallex.** The [official API reference](https://api-docs.wallex.ir/) documents
`GET /v1/markets` and `GET /v1/udf/history`, with `resolution=60` for hourly
candles and `from`/`to` as Unix timestamps in seconds. The history response uses
parallel `t`, `o`, `h`, `l`, `c`, `v` arrays. The downloaded
[`IRR_market.json`](fx_inputs/raw/IRR_market.json) confirms `USDTTMN` has
`baseAsset: USDT`, `quoteAsset: TMN`, `enName: Tether - Toman`, and
`enQuoteAsset: Toman`. **TMN is Toman, not rial.** The normalized IRR file uses
the standard accounting conversion of one Toman to ten Iranian rials. The
exchange's native data is preserved unchanged in `fx_inputs/raw/IRR_*.json`.

A representative exact request, for the first 30 days, is
[`USDTTMN` hourly history](https://api.wallex.ir/v1/udf/history?symbol=USDTTMN&resolution=60&from=1776988800&to=1779580799).
The fetcher makes six nonoverlapping 30-day requests and verifies each timestamp
and OHLCV candle. The complete list is in the manifest.

**Binance.** The [official market-data API reference](https://developers.binance.com/docs/binance-spot-api-docs/rest-api/market-data-endpoints#klinecandlestick-data)
documents `/api/v3/klines`, the `1h` interval, UTC default, inclusive millisecond
`startTime`/`endTime`, a maximum of 1,000 candles per request, and the response
column order. The fetcher requests at most 1,000 nonoverlapping hours at a time.
The downloaded [`TRY_market.json`](fx_inputs/raw/TRY_market.json) and
[`ARS_market.json`](fx_inputs/raw/ARS_market.json) confirm `baseAsset: USDT`,
the respective fiat quote asset, and `status: TRADING` at retrieval.

Binance's [original USDT/ARS spot-market announcement](https://www.binance.com/en/support/announcement/detail/23630cd14227410fae3543c6effad115)
confirms that ARS is fiat currency and that trading opened in April 2023.
These are **Binance spot ARS/USDT prices**, not a central-bank USD/ARS fixing,
cash "blue dollar" quote, or P2P advertisement history. They provide an actual
stablecoin/fiat venue comparison with Wallex, subject to each venue's premiums,
access restrictions and liquidity.

## Data quality

All three files start and end at the requested candle boundaries. Every supplied
candle has a positive price, nonnegative volume, an aligned hourly timestamp,
and a valid OHLC relationship. There were no duplicate candle timestamps. The
fetcher raises an error rather than silently accepting malformed candles,
conflicting duplicates, wrong quote assets or out-of-window timestamps.

Wallex returned no candle for these hours:

| First missing candle open, UTC | Last missing candle open, UTC | Missing hours |
|---|---|---:|
| 2026-09-22 13:00 | 2026-09-22 13:00 | 1 |
| 2026-10-12 23:00 | 2026-10-13 04:00 | 6 |
| 2026-10-19 22:00 | 2026-10-20 07:00 | 10 |

Missing bars remain absent. No reason for their absence is inferred from the
history endpoint, and no interpolation or forward filling is performed. The
185 zero-volume Wallex candles are retained exactly as supplied; they are
published OHLC bars without reported base-asset trading volume. They must not
be described as independently observed trades. Analyses of volatility or update
frequency must disclose these stale or unobserved portions of the series.

## Interpretation for an FX-following anchor

These files express `Q = currency / USDT`. A currency token's parity expressed
in USDT per currency is `M = 1 / Q`. Inverting OHLC requires swapping the high
and low: `M_high = 1 / Q_low`, `M_low = 1 / Q_high`. A maximum anchor error
measured against current parity is `abs(anchor / M - 1)`; applying the same
percentage threshold directly to `Q` is a different convention after inversion.

Hourly closes can support a reproducible **hourly sampled** reset count for a
2%, 3% or 5% anchor tolerance. Hourly high/low can detect an excursion beyond
a pre-existing boundary, but cannot recover the order of intrahour extremes or
the exact number of threshold crossings after a reset. A count derived from
the close series does not establish continuous compliance. Missing hours and
zero-volume bars further limit that claim. Neither data set contains order-book
spreads, fill prices, gas costs, cross-venue execution costs or a USDT/USD basis
series. Treating the prices as currency per USD additionally assumes USDT/USD
parity.

## Reproduction

Run from the repository root using Python's standard library:

```sh
python3 tools/fetch_fx_history.py --end-date 2026-10-21 --days 180
```

The end date is exclusive and interpreted in UTC. Public network access is
required. The script writes exact response bodies under `research/fx_inputs/raw`,
normalizes OHLC into the three CSVs, and writes the provenance/coverage manifest.
Running the command again re-downloads the data; exchanges may revise historical
candles. The checked-in raw responses and hashes preserve this particular
retrieval. The requested data was accessible directly from both exchanges, so
no secondary vendor or official-FX substitute was used.
