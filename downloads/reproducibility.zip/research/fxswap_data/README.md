# IRR/USDT inputs for the FXSwap day backtests

These are real exchange candles, with exact downloaded responses preserved in
[`raw/`](raw/). The six local days each contain **1,440 native one-minute bars**,
with no missing minute timestamps. They were not reconstructed from hourly
candles. Prices are **IRR per USDT**: Wallex reports Toman, so native OHLC values
are multiplied by 10; base volume stays in USDT. Treating USDT as USD requires
the separate USDT/USD parity assumption.

The [manifest](manifest.json) records original request URLs, retrieval timestamps,
exchange HTTP dates, exact raw-response SHA-256 hashes, normalized CSV hashes,
coverage and limitations. The original hourly selection source and its hash are
also recorded; it is not modified by this work.

## Selection before strategy results

The source contains 176 complete Asia/Tbilisi calendar days. Eligibility also
requires positive reported volume in every hour and the preceding hour, and an
observed preceding-hour close. This leaves **158 eligible days**. Days with zero
volume or incomplete coverage cannot become quiet-day evidence. The
[`daily_metrics.csv`](daily_metrics.csv) includes all local date groups, including
ineligible and partially covered boundary days, with exclusion reasons.

For each eligible day, hourly realized volatility is
`sqrt(sum(log(C_h / C_(h-1))^2))` over 24 hourly returns, using the preceding
hour's close as `C_0`. This is dimensionless and not annualized. Days are sorted
by that statistic, then date for ties. The fixed selection takes the nearest
order statistic to p10 and its next neighbor, the middle pair, and the two
largest values. It does not inspect strategy P&L. Exact indices, ranks, source
hash and formulas are in [`selected_days.json`](selected_days.json).

| Regime | Local day | RV rank / 158 | Hourly log RV | IRR/USDT open→close | High/low range | Zero-volume minutes / 1,440 |
|---|---|---:|---:|---:|---:|---:|
| Calm | 2026-04-26 | 17 | 0.7011% | +0.8769% | 1.6885% | 190 |
| Calm | 2026-08-12 | 18 | 0.7134% | −0.8366% | 0.9900% | 190 |
| Median | 2026-08-29 | 79 | 1.3065% | +1.6341% | 2.1825% | 142 |
| Median | 2026-06-09 | 80 | 1.3101% | −0.4512% | 1.7094% | 206 |
| High | 2026-06-15 | 157 | 4.8284% | −7.5011% | 8.5071% | 18 |
| High | 2026-05-24 | 158 | 5.8623% | +0.6758% | 8.1366% | 13 |

Positive IRR/USDT change means rial depreciation. Token parity in USDT per rial
is its reciprocal; its return is `1 / (1 + IRR/USDT return) - 1`. The high RV day
on May 24 has a small positive endpoint return but a large intraday excursion,
which is why endpoint movement alone is insufficient to select volatile days.

## Resolution, clocks and quality

Wallex's [official API reference](https://api-docs.wallex.ir/) is the documentation
entry point. The archived exact [May 24 request at resolution=1](https://api.wallex.ir/v1/udf/history?symbol=USDTTMN&resolution=1&from=1779566400&to=1779652799)
returns 1,440 bars with 60-second spacing. Every selected-day response passes
the same actual-interval check. A [resolution=5 probe](https://api.wallex.ir/v1/udf/history?symbol=USDTTMN&resolution=5&from=1779566400&to=1779652799)
returns HTTP 200 with `s: error` and `errmsg: Invalid resolution!`; that exact
response is archived. Five-minute availability is therefore not claimed.

Only these six days were fetched at one-minute resolution. The full six-month
IRR input remains hourly; this directory does not imply 180 days of minute data.
Each selected day begins at local midnight, which is 20:00 UTC on the preceding
date, and ends at 20:00 UTC on the named date, exclusively.

CSV `timestamp` is the candle **open**, in Unix seconds UTC. A close becomes
known at `candle_end_timestamp`, 60 seconds later. Explicit end timestamps avoid
presenting a minute close to a strategy at the minute's beginning. Every
supplied zero-volume minute is retained and counted; it is not independently
observed trading. The longest zero-volume sequences are 12, 7, 6, 8, 1 and 2
minutes in the table's order. No missing timestamps are interpolated, and no
agent-created ticks or forward fills are added.

Aggregating each set of 60 minute bars back to the prior hourly source gives
**all 144 hourly closes, lows and volumes exactly equal**. There are 13 differing
opens and two differing highs (in the same 13 hours), documented individually
in [`hourly_aggregation_comparison.json`](hourly_aggregation_comparison.json).
No reconciliation is applied. This can reflect exchange aggregation conventions
or historical revisions. The close-based day selection is unaffected by these
differences; minute replay uses the archived native minute feed.

OHLC cannot reveal high/low order, the path within a minute, executable spreads,
order-book depth, actual fills, slippage or continuous oracle compliance. These
inputs are a single exchange's USDT/TMN market, not a licensed cross-venue FX
composite, official central-bank fix or a USDT/USD basis history.

## ETH collateral marks

[`ETH_USDT_1h.csv`](ETH_USDT_1h.csv) contains **4,320 / 4,320** Binance ETH/USDT
hourly candles from 2026-04-24 00:00 UTC to 2026-10-21 00:00 UTC exclusive,
with no missing or zero-volume bars. Prices are USDT per ETH; base volume is
ETH and quote volume is USDT. The [official Binance kline reference](https://developers.binance.com/docs/binance-spot-api-docs/rest-api/market-data-endpoints#klinecandlestick-data)
defines the response and timestamp conventions. The five exact paginated
requests and response hashes are in the manifest. A [first-page request](https://api.binance.com/api/v3/klines?symbol=ETHUSDT&interval=1h&startTime=1776988800000&endTime=1780588799999&limit=1000)
is directly reproducible. Bar-end timestamps specify when hourly closes become
available; intrahour collateral and liquidation paths remain unobserved.

## Reproduction

From the repository root:

```sh
python3 tools/fetch_fxswap_data.py --offline
```

This regenerates selection, CSVs, QA and the manifest from the recorded source
and cached raw responses, verifying cache hashes. Without `--offline`, missing
responses are downloaded but existing cache is retained. Use `--refresh` only
to replace the archive with a new retrieval; exchange history can change.
No third-party Python package or API key is required.
