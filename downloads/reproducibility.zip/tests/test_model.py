import math
import unittest

from model.simulate import Pool, RangeExhausted, asymptote, simulate


class ModelChecks(unittest.TestCase):
    def test_below_parity_band_starts_at_parity_in_quote(self):
        pool=Pool.seeded(10000)
        self.assertAlmostEqual(pool.price,1,places=12)
        self.assertEqual(pool.lower,.97)
        self.assertEqual(pool.upper,1.0)
        x,y=pool.reserves()
        self.assertAlmostEqual(x,0,places=12)
        self.assertAlmostEqual(y,10000,places=8)
        row=simulate(max_multiple=1)[0]
        self.assertEqual(row['range_lower'],.97)
        self.assertEqual(row['range_upper'],1.0)

    def test_zero_fee_round_trip(self):
        pool=Pool.seeded(10000,sqrt_price=math.sqrt(.985))
        before=pool.reserves()
        starting_price=pool.price
        quote=pool.buy(1000)
        self.assertAlmostEqual(pool.sell(1000),quote,places=8)
        self.assertAlmostEqual(pool.price,starting_price,places=12)
        for actual, expected in zip(pool.reserves(),before):
            self.assertAlmostEqual(actual,expected,places=8)

    def test_range_boundary_spends_all_active_quote(self):
        pool=Pool.seeded(10000)
        quote=pool.reserves()[1]
        self.assertAlmostEqual(pool.sell(pool.sell_capacity()),quote,places=8)
        self.assertAlmostEqual(pool.price,.97,places=12)
        with self.assertRaises(RangeExhausted):
            pool.sell(1)

    def test_cohort_conserves_stable_and_quote_principal(self):
        pool=Pool.seeded(10000)
        x0,y0=pool.reserves()
        flow=pool.lp_entry(1000,.874)
        eth_proceeds=pool.sell(flow['debt']/9)
        x1,y1=pool.reserves()
        self.assertAlmostEqual(x1-x0,flow['debt']*10/9,places=7)
        self.assertAlmostEqual(y1-y0,flow['borrower_net_cash']-eth_proceeds,places=7)

    def test_scale_invariance(self):
        small=simulate(seed=10000,max_multiple=1)[-1]
        large=simulate(seed=50000,max_multiple=1)[-1]
        self.assertAlmostEqual(small['pool_spot'],large['pool_spot'],places=12)
        self.assertAlmostEqual(small['extra_sell_to_edge']*5,large['extra_sell_to_edge'],places=7)

    def test_ninety_ten_path_and_eighty_five_percent_failure(self):
        good=simulate(max_multiple=10)[-1]
        self.assertFalse(good['boundary_reached'])
        self.assertGreater(good['pool_spot'],.97)
        bad=simulate(lp_share=.85,max_multiple=100)[-1]
        self.assertTrue(bad['boundary_reached'])
        self.assertAlmostEqual(bad['pool_spot'],.97,places=9)

    def test_analytic_equilibrium_matches_inventory(self):
        price=asymptote()
        pool=Pool.seeded(10000,sqrt_price=math.sqrt(price))
        x,y=pool.reserves()
        self.assertAlmostEqual(x/(x+y),.874/.9,places=10)
        self.assertIsNone(asymptote(lp_share=.85))

    def test_finer_steps_have_small_effect(self):
        coarse=simulate(max_multiple=10,steps_per_seed=100)[-1]
        fine=simulate(max_multiple=10,steps_per_seed=400)[-1]
        self.assertLess(abs(coarse['discount_pct']-fine['discount_pct']),.002)
        self.assertLess(abs(coarse['extra_sell_to_edge']/fine['extra_sell_to_edge']-1),.002)

    def test_fees_are_separate_from_active_principal(self):
        pool=Pool.seeded(10000,fee=.0005,sqrt_price=math.sqrt(.985))
        pool.lp_entry(1000,.874)
        self.assertGreater(pool.stable_fees,0)
        self.assertGreater(pool.quote_fees,0)

    def test_full_maximum_ltv_changes_capacity_result(self):
        row=simulate(actual_ltv=.95,max_multiple=25)[-1]
        self.assertTrue(row['boundary_reached'])
        self.assertLess(row['total_debt'],250000)

    def test_first_loan_bootstraps_without_stable_purchase(self):
        pool=Pool.seeded(10000)
        flow=pool.lp_entry(1000,.874)
        self.assertEqual(flow['stable_bought'],0)
        self.assertEqual(flow['quote_buy'],0)
        self.assertAlmostEqual(flow['quote_deposit'],1000,places=8)
        self.assertLess(pool.price,1)


if __name__ == '__main__':
    unittest.main()
