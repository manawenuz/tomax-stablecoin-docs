import json
from pathlib import Path
import tempfile
import subprocess
import sys
from unittest.mock import patch
import unittest

try:
    from model.sandbox import paper
except ImportError:
    paper = None
from model.sandbox.state import Sandbox, Rejected


class OneSwapKeeper:
    def run(self, system, now):
        return {"actions": [system.swap("searcher", 0, 1, now)], "errors": []}


class RevertingKeeper:
    def run(self, system, now):
        system.swap("searcher", 0, 10**20, now)


class NoopKeeper:
    def run(self, system, now):
        return {"actions": [], "errors": []}


class PaperChecks(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(paper, "Persistent finite paper trading harness is not implemented")

    def quotes(self, t, fx=1000000, eth=2000):
        return (paper.Quote("IRR_USDT", fx, t, t, "Wallex test observation"),
                paper.Quote("ETH_USDT", eth, t, t, "Binance test observation"))

    def checkpoint(self):
        return paper.new_checkpoint({"initial_debt_multiple": 0, "actors_enabled": False}, 1000)

    def active(self):
        data = self.checkpoint()
        paper.advance(data, 1000, *self.quotes(1000), keeper=OneSwapKeeper(), activate=True, gate_passed=True)
        self.assertEqual(data["status"], "running")
        return data

    def test_paused_init_has_no_fabricated_prices_or_running_clock(self):
        data = self.checkpoint()
        self.assertIsNone(data["system"])
        self.assertIsNone(data["started_at"])
        self.assertIsNone(data["ends_at"])
        self.assertEqual(data["status"], "paused")

    def test_starting_actor_funding_and_paid_inventory_match_historical_setup(self):
        data = self.checkpoint()
        paper.advance(data, 1000, *self.quotes(1000), keeper=NoopKeeper(), activate=True, gate_passed=True)
        system = paper.restore_system(data["system"])
        self.assertAlmostEqual(system.wallets["lp"].eth, .1)
        self.assertAlmostEqual(system.wallets["eth"].eth, 5)
        self.assertAlmostEqual(system.wallets["holder"].quote, 3750)
        self.assertAlmostEqual(system.wallets["searcher"].quote, 18000)
        self.assertGreater(system.wallets["holder"].stable, 0)
        self.assertGreater(system.wallets["searcher"].stable, 0)
        system.assert_invariants()

    def test_activation_requires_gate_and_controller(self):
        data = self.checkpoint()
        paper.advance(data, 1000, *self.quotes(1000), keeper=OneSwapKeeper(), activate=True)
        self.assertIsNone(data["system"])
        paper.advance(data, 1001, *self.quotes(1001), activate=True, gate_passed=True)
        self.assertIsNone(data["system"])
        self.assertEqual(data["status"], "paused")

    def test_hard_end_stops_before_a_new_decision(self):
        data = self.active()
        before = json.dumps(data["system"], sort_keys=True)
        paper.advance(data, 1210600, *self.quotes(1210600), keeper=OneSwapKeeper())
        self.assertEqual(data["status"], "complete")
        self.assertEqual(data["ends_at"], 1210600)
        self.assertEqual(json.dumps(data["system"], sort_keys=True), before)
        self.assertEqual(data["decision_count"], 1)

    def test_duplicate_quote_does_not_repeat_a_wallet_action(self):
        data = self.active()
        before = data["system"]
        paper.advance(data, 1001, *self.quotes(1000), keeper=OneSwapKeeper())
        self.assertEqual(data["decision_count"], 1)
        self.assertEqual(data["system"], before)
        self.assertEqual(data["last_result"]["reason"], "duplicate_or_out_of_order_quote")

    def test_out_of_order_one_feed_does_not_accept_other_feed(self):
        data = self.active()
        fx, eth = self.quotes(1060)
        old_eth = paper.Quote("ETH_USDT", 2000, 999, 1060, "Binance test observation")
        paper.advance(data, 1060, fx, old_eth, keeper=OneSwapKeeper())
        self.assertEqual(data["decision_count"], 1)
        self.assertEqual(data["last_quotes"]["IRR_USDT"]["observed_at"], 1000)

    def test_future_quote_never_seeds_or_advances_state(self):
        data = self.checkpoint()
        paper.advance(data, 1000, *self.quotes(1001), keeper=OneSwapKeeper(), activate=True, gate_passed=True)
        self.assertIsNone(data["system"])
        self.assertEqual(data["status"], "paused")

    def test_feed_error_pauses_and_preserves_economic_state(self):
        data = self.active()
        before = data["system"]
        paper.advance(data, 1060, None, None, keeper=OneSwapKeeper(), feed_errors={"Wallex": "timeout"})
        self.assertEqual(data["status"], "stale")
        self.assertEqual(data["system"], before)
        self.assertEqual(data["decision_count"], 1)

    def test_old_actual_quote_is_stale_not_a_catchup_decision(self):
        data = self.active()
        paper.advance(data, 2000, *self.quotes(1060), keeper=OneSwapKeeper())
        self.assertEqual(data["status"], "stale")
        self.assertEqual(data["decision_count"], 1)

    def test_gap_in_wall_time_produces_one_current_decision(self):
        data = self.active()
        paper.advance(data, 2000, *self.quotes(2000), keeper=OneSwapKeeper())
        self.assertEqual(data["decision_count"], 2)
        self.assertEqual(data["last_result"]["gap_seconds"], 1000)

    def test_checkpoint_roundtrip_preserves_vaults_wallet_gas_and_conservation(self):
        system = Sandbox.seeded(10000, 2500, 2000, 1000)
        system.add_actor("lp", quote=30000, eth=1)
        system.add_actor("eth", quote=10000, eth=10)
        system.report(1, 2000, 1000, 1000, 1)
        system.open_bundle("lp", "eth", 1000, 1000)
        system.audit = object()
        encoded = paper.snapshot_system(system)
        restored = paper.restore_system(json.loads(json.dumps(encoded, allow_nan=False)))
        restored.assert_invariants()
        self.assertEqual(restored.wallets, system.wallets)
        self.assertEqual(restored.vaults, system.vaults)
        self.assertEqual(restored.gas_eth, system.gas_eth)
        self.assertEqual(restored.origination_band, .03)
        self.assertIsNone(restored.audit)
        self.assertEqual(restored.pool.journal, [])

    def test_funded_failed_action_still_preserves_its_gas_cost(self):
        data = self.active()
        before = paper.restore_system(data["system"]).gas_eth
        paper.advance(data, 1060, *self.quotes(1060), keeper=RevertingKeeper())
        restored = paper.restore_system(data["system"])
        self.assertGreater(restored.gas_eth, before)
        restored.assert_invariants()
        self.assertEqual(data["status"], "policy_error")

    def test_atomic_checkpoint_and_exclusive_lock(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "paper.json"
            data = self.active()
            with paper.checkpoint_lock(path):
                paper.save_checkpoint(path, data)
                with self.assertRaises(BlockingIOError):
                    with paper.checkpoint_lock(path):
                        pass
            loaded = paper.load_checkpoint(path)
            paper.restore_system(loaded["system"]).assert_invariants()
            self.assertEqual(loaded["decision_count"], 1)
            self.assertEqual(list(Path(directory).glob("*.tmp")), [])

    def test_closed_minute_parser_rejects_unclosed_future_bar(self):
        payload = {"s": "ok", "t": [900, 960], "o": [100, 110], "h": [100, 110],
                   "l": [100, 110], "c": [100, 110], "v": [1, 1]}
        quote = paper.wallex_quote(payload, 1000, "https://example.test")
        self.assertEqual(quote.value, 1000)
        self.assertEqual(quote.observed_at, 960)

    def test_binance_timestamp_comes_from_response_not_local_clock(self):
        quote = paper.binance_quote({"symbol": "ETHUSDT", "lastPrice": "2010", "closeTime": 999000},
                                    1000, "https://example.test")
        self.assertEqual(quote.value, 2010)
        self.assertEqual(quote.observed_at, 999)

    def test_cli_initializes_paused_checkpoint_without_market_prices(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "paper.json"
            script = Path(__file__).resolve().parents[1] / "tools" / "paper_trading.py"
            result = subprocess.run([sys.executable, str(script), "init", str(path)],
                                    text=True, capture_output=True, timeout=5)
            self.assertEqual(result.returncode, 0, result.stderr)
            data = paper.load_checkpoint(path)
            self.assertIsNone(data["started_at"])
            self.assertIsNone(data["system"])
            self.assertEqual(json.loads(result.stdout)["status"], "paused")

    def test_dns_or_tls_worker_deadline_fails_closed_after_bounded_attempts(self):
        error = None
        with patch("subprocess.run", side_effect=subprocess.TimeoutExpired("public-feed-worker", 1)) as transport:
            # Guard against bypassing the process deadline through a direct
            # request; DNS itself is not bounded by urllib's socket timeout.
            with patch("urllib.request.urlopen", side_effect=OSError("unbounded direct request")):
                try:
                    paper.PublicFeeds(timeout=1, attempts=2)._get("https://example.test")
                except Exception as caught:
                    error = caught
        self.assertIsInstance(error, TimeoutError)
        self.assertEqual(transport.call_count, 2)

    def test_actor_and_keeper_facade_never_executes_future_timestamps(self):
        system = Sandbox.seeded(10000, 2500, 2000, 1000)
        system.add_actor("searcher", quote=100, eth=1)
        bounded = paper.CurrentTimeSandbox(system, 1000)
        bounded.swap("searcher", 0, 1, 1002)
        trial = bounded.fork()
        trial.swap("searcher", 0, 1, 1004)
        self.assertEqual(system.now, 1000)
        self.assertEqual(system.events[-1]["t"], 1000)
        self.assertEqual(trial.events[-1]["t"], 1000)
        self.assertAlmostEqual(system.wallets["searcher"].quote, 99)

    def test_actor_cadence_and_past_only_forecast_survive_checkpoint_roundtrip(self):
        data = paper.new_checkpoint({"initial_debt_multiple": 0, "actors_enabled": True}, 1000)
        forecasts = []
        def cycle(system, keeper, now, forecast, config):
            forecasts.append(forecast)
            system.swap("searcher", 0, 1, now)
            return [{"type": "bounded_test_actor"}]
        with patch.object(paper, "actor_cycle", side_effect=cycle):
            paper.advance(data, 1000, *self.quotes(1000), keeper=NoopKeeper(), activate=True, gate_passed=True)
            data = json.loads(json.dumps(data))
            paper.advance(data, 1060, *self.quotes(1060), keeper=NoopKeeper())
            self.assertEqual(len(forecasts), 1)
            paper.advance(data, 87400, *self.quotes(87400, fx=1250000), keeper=NoopKeeper())
        self.assertEqual(forecasts, [1, .76])
        self.assertEqual(data["last_actor_at"], 87400)
        self.assertEqual(data["decision_count"], 3)
        paper.restore_system(data["system"]).assert_invariants()

    def test_real_actor_helpers_preserve_conservation_and_current_step_times(self):
        data = paper.new_checkpoint({"reserve": 1000, "actors_enabled": True}, 1000)
        keeper = paper.load_keeper(data["config"])
        paper.advance(data, 1000, *self.quotes(1000), keeper=keeper, activate=True, gate_passed=True)
        system = paper.restore_system(data["system"])
        system.assert_invariants()
        self.assertTrue(system.events)
        self.assertTrue(all(event["t"] == 1000 for event in system.events))
        self.assertEqual(system.now, 1000)
        self.assertEqual(data["last_actor_at"], 1000)


if __name__ == "__main__":
    unittest.main()
