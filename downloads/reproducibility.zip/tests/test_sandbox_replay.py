import unittest
from model.sandbox.simulate import load_window,replay


class ReplayChecks(unittest.TestCase):
    def test_three_disjoint_real_fortnights(self):
        windows=[load_window(n) for n in ('calm_train','volatile_train','volatile_holdout')]
        for w in windows:
            self.assertEqual(len(w),337)
            self.assertEqual(w[-1]['t']-w[0]['t'],14*86400)
            self.assertTrue(all(x['eth_time']<=x['t'] for x in w))
        for i,a in enumerate(windows):
            for b in windows[i+1:]:self.assertFalse(set(x['t'] for x in a)&set(x['t'] for x in b))

    def test_hourly_funding_replay_is_deterministic_and_reconciles_mix(self):
        c={'raw_a':200000,'reserve_multiple':.25,'keeper':{}}
        a,trace,events,attacks=replay('volatile_train',c,attack=False)
        b,*_=replay('volatile_train',c,attack=False)
        self.assertEqual(a,b)
        self.assertLess(a['max_post_keeper_error'],.03)
        self.assertEqual(a['post_keeper_breaches'],0)
        self.assertAlmostEqual(a['gross_lp_originated']/(a['gross_lp_originated']+a['gross_eth_originated']),.96)
        self.assertEqual(len(trace),3*337)

    def test_no_fake_minute_prices_fill_missing_days(self):
        hourly=load_window('volatile_train');minutes=load_window('volatile_train',True)
        self.assertEqual(hourly,minutes)
        self.assertFalse(any(x['native'] for x in minutes))

    def test_observed_block_order_never_suppresses_later_actors_as_time_travel(self):
        summary,trace,events,actions=replay('volatile_train',{'raw_a':600000,'reserve_multiple':.1})
        closes={x['t'] for x in load_window('volatile_train')}
        self.assertTrue(all(e['t'] in closes for e in events))
        self.assertFalse(any('predates' in e.get('rejected','') for e in events))

    def test_unseen_devaluation_during_feed_outage_is_reported_as_failure(self):
        s,*_=replay('volatile_train',{'raw_a':600000,'reserve_multiple':.1},attack=False,stress='devaluation_outage')
        self.assertGreater(s['max_post_keeper_error'],.2)
        self.assertGreater(s['post_keeper_breaches'],0)
        self.assertEqual(s['stale_observations'],24)


if __name__=='__main__':unittest.main()
