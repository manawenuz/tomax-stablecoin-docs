"""Research port checks, including pinned deployed-contract quote observations."""
import json
import math
from pathlib import Path
import unittest

from model.fxswap import FXParams, FXPool, _get_y


FIXTURES = Path(__file__).resolve().parents[1] / "research" / "fxswap_source"


class FXSwapChecks(unittest.TestCase):
    def test_output_solver_stops_at_machine_precision_of_invariant(self):
        y = _get_y(36831.42825550443, 37496.97547999498, 600000)
        self.assertAlmostEqual(y, 1912.42536710798, places=8)

    def test_withdraw_rejects_even_small_oversupply_and_preserves_user_dust(self):
        pool = FXPool.seeded(10000, 0)
        with self.assertRaises(ValueError):
            pool.withdraw(pool.user_supply + 1e-9, 1)
        remaining = 1e-11
        pool.withdraw(pool.user_supply - remaining, 1)
        self.assertGreater(pool.user_supply, 0)
        self.assertGreater(sum(pool.balances), 0)

    def fixture_pool(self):
        return FXPool.from_snapshot(json.loads((FIXTURES / "snapshot.json").read_text()))

    def test_pinned_live_quotes_both_directions_and_fee(self):
        pool = self.fixture_pool()
        observed = json.loads((FIXTURES / "analysis.json").read_text())
        for label, expected in observed["quote_results_token_units"].items():
            amount, direction = label.split()
            actual = pool.quote(0 if direction == "crvUSD_to_ZCHF" else 1, float(amount))
            # Floating arithmetic loses sub-wei precision; all six eth_call
            # observations must agree to <2e-9 token absolute or 2e-12 relative.
            self.assertTrue(math.isclose(actual, expected, rel_tol=2e-12, abs_tol=2e-9),
                            (label, actual, expected))
        self.assertAlmostEqual(pool.fee(), .0024756047, delta=1e-10)

    def test_balanced_entry_and_proportional_withdrawal(self):
        pool = FXPool.seeded(10000, 0)
        minted = pool.add_liquidity(1000, 1000, 1)
        self.assertAlmostEqual(minted, 999.99, places=7)  # 0.1 bp noise fee
        before = pool.balances[:]
        quote, stable = pool.recoverable(minted)
        self.assertEqual(pool.withdraw(minted, 2), (quote, stable))
        self.assertAlmostEqual(pool.balances[0] + quote, before[0])
        self.assertAlmostEqual(pool.balances[1] + stable, before[1])
        self.assertAlmostEqual(pool.user_supply, 10000)

    def test_quote_does_not_mutate_and_swap_retains_fees(self):
        pool = FXPool.seeded(10000, 0)
        before = pool.clone()
        quoted = pool.quote(1, 100)
        self.assertEqual(pool.__dict__, before.__dict__)
        self.assertEqual(pool.swap(1, 100, 1), quoted)
        self.assertGreater(pool.virtual_price, 1)
        self.assertGreater(pool.fees_paid[0], 0)
        self.assertAlmostEqual(pool.balances[0], 10000 - quoted)
        self.assertEqual(pool.balances[1], 10100)

    def test_donations_are_separate_from_user_ownership_and_unlock_linearly(self):
        pool = FXPool.seeded(10000, 0)
        minted = pool.add_liquidity(100, 100, 0, donation=True)
        self.assertAlmostEqual(pool.user_supply, 10000)
        self.assertAlmostEqual(pool.donation_shares, minted)
        self.assertAlmostEqual(pool.total_supply, 10000 + minted)
        self.assertEqual(pool.available_donation_shares(0), 0)
        self.assertAlmostEqual(pool.available_donation_shares(302400), minted / 2)
        self.assertAlmostEqual(pool.available_donation_shares(604800), minted)
        withdrawn = pool.withdraw(pool.user_supply, 604800)
        self.assertLess(withdrawn[0], 10100)
        self.assertGreater(pool.leftover_donations_to_admin[0], 0)
        self.assertEqual(pool.total_supply, 0)

    def test_overlapping_refuels_preserve_already_unlocked_shares(self):
        pool = FXPool.seeded(10000, 0)
        pool.add_liquidity(100, 100, 0, donation=True)
        unlocked = pool.available_donation_shares(302400)
        pool.add_liquidity(100, 100, 302400, donation=True)
        after = pool.available_donation_shares(302400)
        # Source stores the virtual release timestamp in whole seconds.
        self.assertLessEqual(abs(after - unlocked), pool.donation_shares / 604800)

    def test_normal_lp_entry_temporarily_throttles_released_refuel(self):
        pool = FXPool.seeded(10000, 0)
        pool.add_liquidity(100, 100, 0, donation=True)
        ts = 604800
        available = pool.available_donation_shares(ts)
        pool.add_liquidity(10000, 10000, ts)
        self.assertLess(pool.available_donation_shares(ts), available * .02)
        self.assertGreater(pool.available_donation_shares(ts + 30), available * .45)
        self.assertAlmostEqual(pool.available_donation_shares(ts + 60), available)

    def test_small_lp_add_does_not_invent_fractional_second_protection(self):
        pool = FXPool.seeded(10000, 0)
        pool.add_liquidity(100, 100, 0, donation=True)
        available = pool.available_donation_shares(604800)
        pool.add_liquidity(1, 1, 604800)
        self.assertAlmostEqual(pool.available_donation_shares(604800), available)

    def test_donation_cap_rejection_is_atomic(self):
        pool = FXPool.seeded(10000, 0)
        before = pool.clone()
        with self.assertRaises(ValueError):
            pool.add_liquidity(2000, 2000, 1, donation=True)
        self.assertEqual(pool.__dict__, before.__dict__)

    def test_ema_uses_previous_pool_spot_and_internal_5193_seconds(self):
        pool = FXPool.seeded(10000, 0)
        pool.swap(1, 3000, 0)
        prior_spot = pool.last_prices
        expected = 1 * math.exp(-1) + prior_spot * (1 - math.exp(-1))
        self.assertAlmostEqual(pool.price_oracle(5193), expected, places=12)
        pool.swap(0, 1, 5193)
        self.assertAlmostEqual(pool.cached_price_oracle, expected, places=12)
        self.assertNotAlmostEqual(pool.last_prices, prior_spot, places=8)

    def test_live_refuel_is_insufficient_for_illustrative_recenter(self):
        pool = self.fixture_pool()
        ts = 1792587275
        self.assertAlmostEqual(pool.available_donation_shares(ts), 101.85729515046059)
        scale = pool.price_scale
        pool.swap(0, .000001, ts)
        self.assertEqual(pool.price_scale, scale)
        self.assertEqual(pool.refuel_shares_burned, 0)
        self.assertGreater(pool.recenter_rejections, 0)

    def test_released_refuel_can_burn_without_creating_user_shares(self):
        pool = FXPool.seeded(10000, 0)
        pool.add_liquidity(500, 500, 0, donation=True)
        pool.swap(1, 5000, 1)
        users = pool.user_supply
        for day in range(1, 15):
            pool.swap(1, 1, day * 86400)
        self.assertGreater(pool.refuel_shares_burned, 0)
        self.assertLess(pool.price_scale, 1)
        self.assertAlmostEqual(pool.user_supply, users)
        self.assertAlmostEqual(pool.total_supply, pool.user_supply + pool.donation_shares)
        self.assertGreaterEqual(pool.virtual_price, max(1, (pool.xcp_profit + 1) / 2) - 1e-11)

    def test_exhausted_refuel_cannot_burn_or_recenter_past_profit_guard(self):
        pool = FXPool.seeded(10000, 0)
        minted = pool.add_liquidity(25, 25, 0, donation=True)
        pool.swap(1, 2000, 0)
        for day in range(1, 30):
            pool.swap(1, 1, day * 86400)
        self.assertAlmostEqual(pool.donation_shares, 0, places=9)
        self.assertAlmostEqual(pool.refuel_shares_burned, minted, places=9)
        rejected = pool.recenter_rejections
        scale = pool.price_scale
        pool.swap(1, 1, 30 * 86400)
        self.assertEqual(pool.price_scale, scale)
        self.assertGreater(pool.recenter_rejections, rejected)
        self.assertAlmostEqual(pool.user_supply, 10000, places=9)

    def test_nonparity_seed_and_fivefold_scale_preserve_prices(self):
        small = FXPool.seeded(10000, 0, price=1.2)
        large = FXPool.seeded(50000, 0, price=1.2)
        self.assertAlmostEqual(small.balances[1], 10000 / 1.2)
        self.assertAlmostEqual(small.spot_price(), 1.2)
        self.assertAlmostEqual(large.quote(1, 5000), small.quote(1, 1000) * 5, places=7)
        small.swap(1, 1000, 1)
        large.swap(1, 5000, 1)
        self.assertAlmostEqual(small.spot_price(), large.spot_price(), places=12)

    def test_admin_claim_removes_quarter_profit_without_minting_user_shares(self):
        pool = FXPool.seeded(10000, 0)
        pool.swap(1, 1000, 0)
        vp = pool.virtual_price
        profit = pool.xcp_profit
        self.assertEqual(pool.claim_admin_fees(1), (0, 0))
        paid = pool.claim_admin_fees(86400)
        self.assertGreater(sum(paid), 0)
        self.assertAlmostEqual(pool.virtual_price, vp - (profit - 1) / 4, places=12)
        self.assertEqual(pool.user_supply, 10000)
        self.assertEqual(pool.claim_admin_fees(86401), (0, 0))


if __name__ == "__main__":
    unittest.main()
