import unittest

from model.sandbox.state import Sandbox, Rejected


class SandboxChecks(unittest.TestCase):
    def system(self,reserve=2500):
        s=Sandbox.seeded(10000,reserve,2000,0,gas_gwei=1 if reserve else 0)
        s.add_actor('lp',quote=30000,eth=1)
        s.add_actor('eth',quote=10000,eth=10)
        s.report(1,2000,0,0,1)
        return s

    def test_seed_liability_and_finite_ownership(self):
        s=self.system();s.assert_invariants()
        self.assertAlmostEqual(s.bootstrap_debt,10000)
        self.assertAlmostEqual(s.wallets['keeper'].lp,s.pool.user_supply)
        self.assertAlmostEqual(s.protocol_equity(),12500)

    def test_unfunded_swap_reverts_pool_but_still_pays_gas(self):
        s=self.system();before=s.pool.balances[:];gas=s.gas_eth
        with self.assertRaises(Rejected):s.swap('lp',0,40000,0)
        self.assertEqual(s.pool.balances,before)
        self.assertGreater(s.gas_eth,gas);s.assert_invariants()

    def test_bundle_has_real_backing_and_96_4_issuance(self):
        s=self.system();lp,eth=s.open_bundle('lp','eth',1000,0)
        self.assertAlmostEqual(s.vaults[lp].debt,960)
        self.assertAlmostEqual(s.vaults[eth].debt,40)
        self.assertAlmostEqual(s.vaults[eth].collateral*2000,40/.75)
        self.assertLessEqual(s.vault_ltv(lp),.95)
        s.assert_invariants()

    def test_stale_report_stops_borrowing_but_not_owner_close(self):
        s=self.system();lp,_=s.open_bundle('lp','eth',1000,0)
        with self.assertRaises(Rejected):s.open_bundle('lp','eth',100,1000)
        s.close('lp',lp,1000)
        self.assertEqual(s.vaults[lp].debt,0);s.assert_invariants()

    def test_future_or_replayed_report_is_rejected(self):
        s=self.system()
        with self.assertRaises(Rejected):s.report(.9,2000,1,0,2)
        with self.assertRaises(Rejected):s.report(.9,2000,0,0,1)
        with self.assertRaises(Rejected):s.report(.9,2000,0,0,2,authorized=False)
        self.assertEqual(s.reference,1)

    def test_stale_eth_report_cannot_set_the_mock_venue_execution_price(self):
        s=self.system();_,v=s.open_bundle('lp','eth',1000,0)
        collateral=s.vaults[v].collateral
        s.observe_market(1,1000,60)
        before=s.venue_quote
        s.report(1,2000,60,60,2,eth_timestamp=0)
        s.close('eth',v,60)
        self.assertAlmostEqual(before-s.venue_quote,collateral*1000)
        s.assert_invariants()

    def test_last_user_exit_preserves_refuel_admin_sink(self):
        s=self.system();s.refuel('keeper',100,0)
        s.withdraw('keeper',s.wallets['keeper'].lp,60)
        self.assertGreater(sum(s.pool.leftover_donations_to_admin),0)
        s.assert_invariants()

    def test_planning_fork_cannot_change_economic_state_or_events(self):
        s=self.system();trial=s.fork();trial.swap('lp',0,100,0)
        self.assertEqual(s.pool.balances,[10000,10000])
        self.assertEqual(len(s.events),0)
        self.assertIsNone(trial.audit)

    def test_keeper_rotation_cannot_spend_borrower_lp(self):
        s=self.system();lp,_=s.open_bundle('lp','eth',1000,0)
        locked=s.vaults[lp].collateral
        with self.assertRaises(Rejected):s.rotate('keeper',s.wallets['keeper'].lp+1,1,0)
        s.rotate('keeper',1000,1,0)
        self.assertEqual(s.vaults[lp].collateral,locked)
        self.assertGreater(s.wallets['keeper'].quote,2400)
        s.assert_invariants()

    def test_funded_liquidation_burns_debt_and_preserves_conservation(self):
        s=self.system();_,v=s.open_bundle('lp','eth',1000,0)
        s.observe_market(1,1000,60)
        s.report(1,1000,60,60,2)
        self.assertGreater(s.vault_ltv(v),1)
        r=s.liquidate('keeper',v,60)
        self.assertEqual(s.vaults[v].debt,0)
        self.assertGreater(r['backstop_quote'],0)
        self.assertEqual(s.bad_debt,0);s.assert_invariants()

    def test_unfunded_credit_loss_stays_a_liability(self):
        s=self.system(reserve=0);_,v=s.open_bundle('lp','eth',1000,0)
        s.observe_market(1,1000,60)
        s.report(1,1000,60,60,2)
        r=s.liquidate('keeper',v,60)
        self.assertGreater(r['bad_debt'],0)
        self.assertGreater(s.bad_debt,0)
        s.assert_invariants()

    def test_lp_close_nets_only_controlled_tokens(self):
        s=self.system();v,_=s.open_bundle('lp','eth',1000,0)
        minted=s.token_liabilities()
        s.close('lp',v,12)
        self.assertAlmostEqual(s.token_liabilities(),minted-960)
        self.assertEqual(s.vaults[v].debt,0)
        self.assertGreater(s.wallets['lp'].quote,0);s.assert_invariants()

    def test_unhealthy_queue_blocks_new_loans_without_new_borrower_dependency(self):
        s=self.system();_,v=s.open_bundle('lp','eth',1000,0)
        s.observe_market(1,1000,60)
        s.report(1,1000,60,60,2)
        s.mark_liquidations(60)
        with self.assertRaises(Rejected):s.open_bundle('lp','eth',100,60)
        s.liquidate('keeper',v,60)
        self.assertEqual(s.pending_count(),0)
        s.assert_invariants()

    def test_keeper_repairs_a_funded_downward_reference_move_without_minting(self):
        from model.sandbox.policies import Keeper
        s=self.system();s.open_bundle('lp','eth',5000,0)
        debt=s.debt();s.report(.9,2000,60,60,2)
        result=Keeper({'target':.01}).run(s,60)
        self.assertLessEqual(abs(s.pool.spot_price()/.9-1),.01001)
        self.assertAlmostEqual(s.debt(),debt)
        self.assertTrue(result['actions']);s.assert_invariants()

    def test_keeper_does_not_claim_success_with_stale_input(self):
        from model.sandbox.policies import Keeper
        s=self.system();r=Keeper({}).run(s,1000)
        self.assertEqual(r['status'],'stale')
        self.assertEqual(s.counters,{})

    def test_recovered_vault_leaves_liquidation_queue(self):
        s=self.system();s.open_bundle('lp','eth',1000,0)
        s.report(1,1000,60,60,2);s.mark_liquidations(60)
        self.assertEqual(s.pending_count(),1)
        s.report(1,2000,120,120,3);s.mark_liquidations(120)
        self.assertEqual(s.pending_count(),0)
        s.open_bundle('lp','eth',100,120)

    def test_bookkeeping_one_ulp_does_not_create_or_redeem_extra_lp(self):
        import math
        s=self.system();shares=math.nextafter(s.pool.user_supply,math.inf)
        self.assertEqual(s.recoverable(shares),s.pool.recoverable(s.pool.user_supply))
        with self.assertRaises(ValueError):s.recoverable(s.pool.user_supply+1e-7)

    def test_new_loan_cannot_leave_pool_outside_3_percent(self):
        from model.fxswap import FXParams
        s=Sandbox.seeded(10000,1000,2000,0,FXParams(raw_a=200000))
        s.add_actor('lp',30000,1);s.add_actor('eth',5000,10);s.report(1,2000,0,0,1)
        before=s.pool.balances[:]
        with self.assertRaisesRegex(Rejected,'origination peg guard'):s.open_bundle('lp','eth',20000,0)
        self.assertEqual(s.pool.balances,before);self.assertEqual(s.debt(),0)

    def test_active_credit_loss_is_visible_before_liquidation(self):
        s=self.system();s.open_bundle('lp','eth',1000,0)
        loss=s.active_shortfall(1,1000)
        self.assertAlmostEqual(loss,40-40/.75*.5)
        w=s.wallets['keeper'];q,st=s.recoverable(w.lp)
        unimpaired=w.quote+q+(w.stable+st-s.bootstrap_debt)*1+w.eth*1000
        self.assertAlmostEqual(s.protocol_equity(1,1000),unimpaired-loss)


if __name__=='__main__':unittest.main()
