"""Opt-in exact-bytecode checks; default tests never fetch/install anything.

TOMAX_EVM_TESTS=1 /tmp/tomax-evm/bin/python -m unittest tests.test_fxswap_evm
Run tools/check_fxswap_evm.py --fetch once to populate the pinned artifact cache.
"""
import copy
import importlib.util
import os
import unittest


@unittest.skipUnless(os.environ.get("TOMAX_EVM_TESTS") == "1" and importlib.util.find_spec("boa"),
                     "optional local EVM: install requirements-evm.txt and set TOMAX_EVM_TESTS=1")
class FXSwapEVMChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from evm.artifacts import DEFAULT_CACHE, load_artifacts
        cls.artifacts = load_artifacts(os.environ.get("TOMAX_EVM_CACHE", DEFAULT_CACHE))

    def test_full_smoke_and_float_differential(self):
        from tools.check_fxswap_evm import check
        report = check(self.artifacts)
        self.assertEqual(report["status"], "passed")
        self.assertGreater(report["refuel_shares_burned_tokens"], 0)

    def test_pinned_bytecode_and_abi_reject_tampering(self):
        from evm.artifacts import validate_artifacts
        changed = copy.deepcopy(self.artifacts)
        changed["pool"]["bytecode"] = "0x00"
        with self.assertRaisesRegex(ValueError, "creation bytecode"):
            validate_artifacts(changed)
        changed = copy.deepcopy(self.artifacts)
        changed["math"]["abi"] = []
        with self.assertRaisesRegex(ValueError, "ABI"):
            validate_artifacts(changed)

    def test_nested_commit_and_outer_revert_restore_tokens_clock_and_gas(self):
        from evm import FXEVMPool
        p = FXEVMPool(timestamp=1700000000, artifacts=self.artifacts)
        p.add_liquidity(10000, 10000, 1700000000)
        before, gas = p.state_wei(), p.gas_used
        outer = p.begin_snapshot()
        p.swap(0, 100, 1700000010)
        inner = p.begin_snapshot()
        p.withdraw_one_coin(10, 1, 1700000011)
        with self.assertRaisesRegex(ValueError, "LIFO"):
            p.revert_snapshot(outer)
        p.commit_snapshot(inner)
        p.revert_snapshot(outer)
        self.assertEqual(p.state_wei(), before)
        self.assertEqual(p.env.timestamp, 1700000000)
        self.assertEqual(p.gas_used, gas)
        with p.atomic():
            p.swap(0, 100, 1700000010)
        self.assertGreater(p.balances[0], 10000)
        self.assertGreater(p.gas_used, gas)
        with self.assertRaises(ValueError):
            p.revert_snapshot(outer)
        p.assert_conservation()

    def test_one_coin_both_directions_and_independent_environments(self):
        from evm import FXEVMPool
        a = FXEVMPool(artifacts=self.artifacts)
        b = FXEVMPool(artifacts=self.artifacts)
        a.add_liquidity(10000, 10000, 0)
        b.add_liquidity(5000, 5000, 0)
        other_before = b.state_wei()
        for i in (0, 1):
            wallet = a.wallet_balances_wei()
            amount = a.quote_withdraw_one_coin(10, i, 1)
            a.withdraw_one_coin(10, i, 1)
            after = a.wallet_balances_wei()
            self.assertGreater(amount, 0)
            self.assertGreater(after[i], wallet[i])
            self.assertEqual(after[1-i], wallet[1-i])
        self.assertEqual(b.state_wei(), other_before)
        a.assert_conservation()

    def test_journal_replay_commits_real_state_and_rejects_mismatch_atomically(self):
        from evm import EVMDivergence, EVMJournalAudit
        from model.fxswap import FXPool
        p = FXPool.seeded(10000, 1700000000)
        audit = EVMJournalAudit.seeded(10000, 1700000000, artifacts=self.artifacts)
        output = p.swap(0, 100, 1700000001)
        audit.execute([("swap", (0, 100, 1700000001), output)], p)
        self.assertEqual(audit.operations, 1)
        before, gas = audit.pool.state_wei(), audit.pool.gas_used
        with self.assertRaises(EVMDivergence):
            audit.execute([("swap", (0, 100, 1700000002), -1)], p)
        self.assertEqual(audit.pool.state_wei(), before)
        self.assertEqual(audit.pool.gas_used, gas)
        self.assertEqual(audit.operations, 1)
        self.assertEqual(audit.failures, 1)


if __name__ == "__main__":
    unittest.main()
