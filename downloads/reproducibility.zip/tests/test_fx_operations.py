import unittest
from model.fx_operations import backtest


def bar(t,q):
    return dict(timestamp=t,open=q,close=q,high=q,low=q,volume_usdt=1)


class FXChecks(unittest.TestCase):
    def test_constant_series_never_resets(self):
        result=backtest([bar(0,100),bar(3600,100)],['1970-01-01'],threshold=.02)
        self.assertEqual(result['updates'],0)

    def test_no_lookahead_reset_uses_last_trigger_not_previous_candle(self):
        result=backtest([bar(0,100),bar(3600,101),bar(7200,102.1),bar(10800,103)],['1970-01-01'],threshold=.02)
        self.assertEqual(result['updates'],1)
        self.assertEqual(result['events'][0]['new_quote'],102.1)

    def test_full_band_asymmetric_guard(self):
        result=backtest([bar(0,100),bar(3600,97.9)],['1970-01-01'],whole_band_tolerance=.05)
        self.assertEqual(result['updates'],1)
        result=backtest([bar(0,100),bar(3600,104.9)],['1970-01-01'],whole_band_tolerance=.05)
        self.assertEqual(result['updates'],0)

    def test_two_percent_total_tolerance_is_infeasible(self):
        result=backtest([bar(0,100)],['1970-01-01'],whole_band_tolerance=.02)
        self.assertFalse(result['feasible'])

    def test_gap_is_reported_not_filled(self):
        result=backtest([bar(0,100),bar(7200,103)],['1970-01-01'],threshold=.02)
        self.assertEqual(result['gap_resumptions'],1)
        self.assertEqual(result['updates'],1)

    def test_intrahour_excursion_is_visible_when_close_does_not_reset(self):
        spike=bar(3600,100);spike['high']=106
        result=backtest([bar(0,100),spike],['1970-01-01'],threshold=.02)
        self.assertEqual(result['updates'],0)
        self.assertEqual(result['intrahour_breaches_without_close_reset'],1)
        self.assertAlmostEqual(result['max_observed_intrahour_anchor_error'],.06)


if __name__=='__main__':unittest.main()
