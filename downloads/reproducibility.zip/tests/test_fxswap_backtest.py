import unittest

from model.fxswap_backtest import Book, arbitrage, mint_cohort, replay, _maximize


def candle(t, q=100):
    return dict(timestamp=t, candle_end_timestamp=t+60, open=q, close=q,
                high=q, low=q, volume_usdt=100)


class BacktestChecks(unittest.TestCase):
    def test_small_receipt_solve_allows_pool_scale_float_precision(self):
        flow=mint_cohort(Book.seeded(10000,0),.01,.95,0,2000)
        self.assertAlmostEqual(flow['actual_lp_ltv'],.874,places=6)

    def test_arbitrage_finds_dynamic_fee_second_profit_peak(self):
        book=Book.seeded(10000,0)
        book.pool.swap(1,1850,0)
        # Fee falls sharply as the pool crosses balance: profit is not concave.
        def profit(dx):return book.pool.quote(0,dx)*.99815*(1-.0005)-dx
        dx,value=_maximize(profit,60000)
        self.assertGreater(value,1.07)
        self.assertGreater(dx,1700)

    def test_bootstrap_token_leg_is_a_liability(self):
        book=Book.seeded(10000,0)
        mark=book.mark(1,2000)
        self.assertAlmostEqual(mark['treasury_lp_nav'],20000)
        self.assertAlmostEqual(mark['bootstrap_debt_usdt'],10000)
        self.assertAlmostEqual(mark['treasury_equity_before_refuels'],10000)

    def test_new_debt_preserves_mix_and_receipt_ltv(self):
        book=Book.seeded(10000,0)
        flow=mint_cohort(book,1000,1,0,2000)
        self.assertAlmostEqual(book.lp_debt,960,places=6)
        self.assertAlmostEqual(book.eth_debt,40,places=6)
        self.assertAlmostEqual(flow['lp_debt']/flow['receipt_value'],.874,places=7)
        self.assertAlmostEqual(book.issued_tokens,11000,places=6)
        self.assertAlmostEqual(book.pool.balances[1],book.issued_tokens,places=6)

    def test_arbitrage_cannot_sell_tokens_that_do_not_exist_outside_pool(self):
        book=Book.seeded(10000,0)
        result=arbitrage(book,.8,60,external_cost=0,min_profit=0,finite_inventory=True)
        self.assertEqual(result['trades'],0)
        self.assertAlmostEqual(book.outside_tokens,0)
        self.assertTrue(result['inventory_limited'])

    def test_buy_then_sell_arbitrage_conserves_issued_supply(self):
        book=Book.seeded(10000,0)
        arbitrage(book,1.2,60,external_cost=0,min_profit=0,finite_inventory=True)
        self.assertGreater(book.outside_tokens,0)
        arbitrage(book,.8,120,external_cost=0,min_profit=0,finite_inventory=True)
        self.assertGreaterEqual(book.outside_tokens,-1e-6)
        self.assertLessEqual(book.pool.balances[1],book.issued_tokens+1e-6)

    def test_currency_mark_loss_is_separate_from_own_debt_mark(self):
        book=Book.seeded(10000,0)
        mark=book.mark(.5,2000)
        self.assertAlmostEqual(mark['treasury_lp_nav'],15000)
        self.assertAlmostEqual(mark['treasury_equity_before_refuels'],10000)

    def test_constant_series_without_debt_needs_no_refuels(self):
        result=replay([candle(0),candle(60),candle(120)],external_seed=10000,
                      additional_debt=0,daily_refuel=0,eth_marks=[(0,2000)],
                      external_cost=0,min_profit=0)
        self.assertEqual(result['summary']['refuel_spent'],0)
        self.assertEqual(result['summary']['arbitrage_trades'],0)
        self.assertAlmostEqual(result['summary']['seed_lp_return_pct'],0)

    def test_recording_does_not_change_summary_or_daily_pnl(self):
        bars=[candle(0,100),candle(60,95),candle(120,105)]
        kwargs=dict(external_seed=10000,additional_debt=10000,daily_refuel=10,
                    eth_marks=[(0,2000)])
        a=replay(bars,record=True,**kwargs)
        b=replay(bars,record=False,**kwargs)
        self.assertEqual(a['summary'],b['summary'])
        self.assertAlmostEqual(a['summary']['treasury_equity_pnl_after_refuels'],
            sum(row['treasury_equity_pnl_after_refuels'] for row in a['daily'].values()))
        self.assertGreater(a['summary']['initial_total_pool_value_after_issuance'],20000)

    def test_above_peg_expansion_requires_new_loans_with_bounded_daily_debt(self):
        bars=[candle(0,100),candle(60,130),candle(120,130)]
        r=replay(bars,10000,10000,0,[(0,2000)],daily_new_debt_cap=1000)
        s=r['summary']
        self.assertGreater(s['controller_added_debt'],0)
        self.assertLessEqual(s['controller_added_debt'],1000+1e-5)
        self.assertAlmostEqual(s['final_additional_debt'],10000+s['controller_added_debt'])
        self.assertGreater(s['controller_lp_net_quote_cash'],0)
        self.assertGreater(s['controller_eth_collateral_posted_usdt'],0)
        self.assertAlmostEqual(s['treasury_equity_pnl_after_refuels'],
            sum(row['treasury_equity_pnl_after_refuels'] for row in r['daily'].values()))

    def test_eth_shortfalls_do_not_net_unrelated_borrower_surpluses(self):
        book=Book.seeded(10000,0)
        mint_cohort(book,1000,1,0,2000)
        mint_cohort(book,1000,1,1,1000)
        mark=book.mark(1,1000)
        self.assertGreater(mark['eth_collateral_usdt'],mark['eth_debt_usdt'])
        self.assertAlmostEqual(mark['eth_gross_credit_shortfall'],40-40/.67/2)
        self.assertAlmostEqual(mark['max_eth_cohort_ltv'],1.34)


if __name__=='__main__':unittest.main()
