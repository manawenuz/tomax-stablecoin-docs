"""Historical FX anchor backtest and explicitly assumed Ethereum gas budgets."""
from __future__ import annotations

import csv
import datetime as dt
import json
import math
import statistics
from collections import Counter
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT=Path(__file__).resolve().parents[1]
ZONE=ZoneInfo('Asia/Tbilisi')
UTC=dt.timezone.utc


def quantile(values,p):
    s=sorted(values)
    if not s:return 0.0
    pos=(len(s)-1)*p
    lower=int(pos);upper=min(lower+1,len(s)-1)
    return s[lower]+(s[upper]-s[lower])*(pos-lower)


def load_candles(path):
    with path.open() as handle:
        data=[{k:(int(v) if k=='timestamp' else float(v) if k in ('open','high','low','close','volume_usdt') else v)
               for k,v in row.items()} for row in csv.DictReader(handle)]
    return sorted(data,key=lambda row:row['timestamp'])


def backtest(candles,day_labels,threshold=None,whole_band_tolerance=None):
    """Act at hourly CLOSE, not at an unobserved threshold crossing.

    q is native currency per USDT. R=1/q is USDT per native currency.
    R_anchor / R_current = q_current / q_anchor.
    Fixed band relative to current parity is [0.97*ratio, ratio].
    """
    if not candles:raise ValueError('Empty candle input')
    if whole_band_tolerance is not None and whole_band_tolerance < .03-1e-12:
        return dict(feasible=False,reason='The intrinsic 3% discount already exceeds total-price tolerance')
    anchor=candles[0]['open']
    events=[];daily=Counter();pre_reset_errors=[];gap_resumptions=0
    intrahour_breach_hours=0;intrahour_breaches_without_close_reset=0
    intrahour_errors=[]
    prev=None
    for row in candles:
        if prev is not None and row['timestamp']-prev!=3600:gap_resumptions+=1
        ratio=row['close']/anchor
        pre_reset_errors.append(abs(ratio-1))
        low_ratio=row['low']/anchor;high_ratio=row['high']/anchor
        intrahour_errors.append(max(abs(low_ratio-1),abs(high_ratio-1)))
        if whole_band_tolerance is None:
            trigger=abs(ratio-1)>threshold
            intrahour_breach=low_ratio < 1-threshold or high_ratio > 1+threshold
        else:
            trigger=.97*ratio < 1-whole_band_tolerance or ratio > 1+whole_band_tolerance
            intrahour_breach=.97*low_ratio < 1-whole_band_tolerance or high_ratio > 1+whole_band_tolerance
        intrahour_breach_hours+=int(intrahour_breach)
        intrahour_breaches_without_close_reset+=int(intrahour_breach and not trigger)
        if trigger:
            # Candle-close events are assigned to the completed candle's local day.
            day=dt.datetime.fromtimestamp(row['timestamp']+3599,ZONE).date().isoformat()
            daily[day]+=1
            events.append(dict(timestamp_close=row['timestamp']+3600,local_day=day,
                               anchor_quote=anchor,new_quote=row['close'],pre_reset_anchor_error=ratio-1))
            anchor=row['close']
        prev=row['timestamp']
    daily_values=[daily[day] for day in day_labels]
    return dict(feasible=True,updates=len(events),days=len(day_labels),
                mean_updates_per_day=len(events)/len(day_labels),median_daily_updates=statistics.median(daily_values),
                p95_daily_updates=quantile(daily_values,.95),peak_daily_updates=max(daily_values),
                peak_dates=[day for day in day_labels if daily[day]==max(daily_values)] if max(daily_values) else [],
                gap_resumptions=gap_resumptions,max_observed_pre_reset_anchor_error=max(pre_reset_errors),
                intrahour_breach_hours=intrahour_breach_hours,
                intrahour_breaches_without_close_reset=intrahour_breaches_without_close_reset,
                max_observed_intrahour_anchor_error=max(intrahour_errors),
                daily_updates={day:daily[day] for day in day_labels},events=events)


def main():
    (ROOT/'results').mkdir(exist_ok=True)
    manifest=json.loads((ROOT/'research/fx_inputs/manifest.json').read_text())
    first=dt.datetime.fromisoformat(manifest['sources'][0]['requested_from_utc_inclusive'].replace('Z','+00:00'))
    last=dt.datetime.fromisoformat(manifest['sources'][0]['requested_to_utc_exclusive'].replace('Z','+00:00'))
    # Restrict daily statistics to complete local days across the common sample.
    start=first.astimezone(ZONE).replace(hour=0,minute=0,second=0,microsecond=0)
    if start<first:start+=dt.timedelta(days=1)
    end=last.astimezone(ZONE).replace(hour=0,minute=0,second=0,microsecond=0)
    day_labels=[(start+dt.timedelta(days=i)).date().isoformat() for i in range((end-start).days)]
    reports=[]
    for source in manifest['sources']:
        rows=[r for r in load_candles(ROOT/source['csv_file']) if r['timestamp']>=start.timestamp() and r['timestamp']+3600<=end.timestamp()]
        returns=[math.log(b['close']/a['close']) for a,b in zip(rows,rows[1:]) if b['timestamp']-a['timestamp']==3600]
        byday={}
        for row in rows:
            day=dt.datetime.fromtimestamp(row['timestamp']+3599,ZONE).date().isoformat()
            byday.setdefault(day,[]).append(row)
        daily_returns=[]
        for day,bars in byday.items():
            if len(bars)==24:daily_returns.append(math.log(bars[-1]['close']/bars[0]['open']))
        policies={
            'anchor_2pct':backtest(rows,day_labels,threshold=.02),
            'anchor_5pct':backtest(rows,day_labels,threshold=.05),
            'whole_band_5pct':backtest(rows,day_labels,whole_band_tolerance=.05),
            'whole_band_2pct':backtest(rows,day_labels,whole_band_tolerance=.02),
        }
        reports.append(dict(currency=source['currency'],exchange=source['exchange'],symbol=source['symbol'],
                            bars=len(rows),expected_bars=len(day_labels)*24,
                            missing_bars=len(day_labels)*24-len(rows),
                            zero_volume_bars=sum(r['volume_usdt']==0 for r in rows),
                            local_per_usdt_change=rows[-1]['close']/rows[0]['open']-1,
                            native_usdt_value_change=rows[0]['open']/rows[-1]['close']-1,
                            hourly_log_return_std=statistics.stdev(returns),
                            daily_log_return_std=statistics.stdev(daily_returns),
                            daily_log_return_count=len(daily_returns),
                            largest_abs_complete_day_move=max(abs(math.expm1(x)) for x in daily_returns),
                            largest_intrahour_high_low= max(r['high']/r['low']-1 for r in rows),policies=policies))
    totals={}
    for policy in ('anchor_2pct','anchor_5pct','whole_band_5pct'):
        daily=[sum(r['policies'][policy]['daily_updates'][day] for r in reports) for day in day_labels]
        totals[policy]=dict(updates=sum(daily),mean_updates_per_day=statistics.mean(daily),
                            p95_daily_updates=quantile(daily,.95),peak_daily_updates=max(daily),
                            daily_updates=dict(zip(day_labels,daily)))
    output=dict(method='Hourly-close no-lookahead reset; not continuous-price or executable-spread guarantee',
                raw_days=manifest['requested_days'],local_timezone='Asia/Tbilisi',
                start_local_inclusive=start.isoformat(),end_local_exclusive=end.isoformat(),
                complete_local_days=len(day_labels),source_manifest='research/fx_inputs/manifest.json',
                reports=reports,aggregate=totals)
    (ROOT/'results/fx_operations.json').write_text(json.dumps(output,indent=2)+'\n')
    # One shared position per market, fresh-report verification included in each reset.
    gas_scenarios=[]
    for policy,aggregate in totals.items():
        for positions in (1,10):
            gas_per_reset=150000+450000*positions
            for gas_price in (1,5,20):
                gas_scenarios.append(dict(policy=policy,positions_per_currency=positions,
                                         assumed_gas_per_reset=gas_per_reset,effective_gwei=gas_price,
                                         mean_range_eth_per_day=aggregate['mean_updates_per_day']*gas_per_reset*gas_price*1e-9,
                                         p95_range_eth_per_day=aggregate['p95_daily_updates']*gas_per_reset*gas_price*1e-9,
                                         historical_peak_range_eth_per_day=aggregate['peak_daily_updates']*gas_per_reset*gas_price*1e-9))
    gas_output=dict(chain='Ethereum mainnet',gas_costs_measured=False,
                    assumptions=dict(fixed_gas_per_reset=150000,gas_per_managed_position=450000,
                                     standalone_report_gas=100000,funded_settlement_gas=250000,
                                     user_loan_action_gas=400000),range_costs=gas_scenarios,
                    treasury_note='Users pay their own loan/report calls by default; no fixed heartbeat required for pull oracle',
                    exclusions=['L2 fees','bridging','inventory trading and slippage','exchange costs','oracle data services','keeper infrastructure','collateral and liquidation capital'])
    (ROOT/'results/gas_budget.json').write_text(json.dumps(gas_output,indent=2)+'\n')
    for report in reports:
        print(json.dumps({k:report[k] for k in ('currency','bars','missing_bars','daily_log_return_std','largest_abs_complete_day_move')}))
        print(json.dumps({p:{k:v for k,v in result.items() if k in ('updates','mean_updates_per_day','p95_daily_updates','peak_daily_updates')}
                          for p,result in report['policies'].items() if result.get('feasible')}))
    print(json.dumps({'aggregate':{p:{k:v for k,v in r.items() if k!='daily_updates'} for p,r in totals.items()},'local_days':len(day_labels)}))


if __name__=='__main__':main()
