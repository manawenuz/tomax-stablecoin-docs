"""Research, float-unit port of the deployed FXSwap v2.1.0d pool.

The pinned Vyper and live quote observations are in research/fxswap_source.
Coin 0 is external quote (crvUSD in that pool); coin 1 is own stable (ZCHF).
Amounts and shares use whole-token units, prices are coin0 / coin1. This is
not an EVM emulator: integer truncation, parameter ramps, token transfer
behaviour, and one-coin/fixed-output withdrawals are outside this port.
The six pinned get_dy observations agree within 2e-12 relative / 2e-9 token.
That is quote evidence, not parity evidence for all state transitions.

The deployed MATH is StableSwap, with raw A=600000, multiplier=10000 and N=2
(whitepaper A=30). Gamma is accepted by that MATH interface but unused.
EMA inputs are prior pool spot prices, never an external market feed.
Admin claims are explicit: these are not called by source swaps, deposits,
or proportional withdrawals. Assume a configured nonzero fee receiver.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime
import math
from typing import Mapping


@dataclass(frozen=True)
class FXParams:
    raw_a: int = 600000
    gamma: int = 10**15  # unused by the deployed StableSwap math
    mid_fee: float = .00025
    out_fee: float = .0025
    fee_gamma: float = .003
    adjustment_step: float = 1e-7
    allowed_extra_profit: float = 1e-12
    ma_time: float = 5193.0  # internal exp time; getter returns floor(5193*.694)=3603
    donation_duration: float = 7 * 86400
    donation_shares_max_ratio: float = .1
    donation_protection_period: float = 60
    donation_protection_lp_threshold: float = .5
    noise_fee: float = 1e-5
    admin_fee: float = .5
    admin_claim_interval: float = 86400

    def __post_init__(self):
        if self.raw_a <= 5000 or not 0 <= self.mid_fee <= self.out_fee < 1:
            raise ValueError("invalid amplification or swap fees")
        if not 0 < self.fee_gamma <= 1 or not 0 <= self.admin_fee <= 1:
            raise ValueError("invalid fee parameters")
        if min(self.ma_time, self.donation_duration, self.donation_protection_period,
               self.donation_protection_lp_threshold) <= 0:
            raise ValueError("time and protection parameters must be positive")
        if not 0 < self.donation_shares_max_ratio < 1:
            raise ValueError("invalid donation cap")


def _invariant(xp: list[float], raw_a: int) -> float:
    """StableswapMath.newton_D, normalized from 18 decimals."""
    total = sum(xp)
    if total == 0:
        return 0.0
    if min(xp) <= 0:
        raise ValueError("both reserves must be positive")
    ann = raw_a * 2 / 10000
    d = total
    for _ in range(255):
        dp = d * (d / xp[0]) * (d / xp[1]) / 4
        previous = d
        d = (ann * total + 2 * dp) * d / ((ann - 1) * d + 3 * dp)
        if abs(d - previous) <= max(1e-13, abs(d) * 2e-15):
            return d
    raise ArithmeticError("StableSwap invariant did not converge")


def _get_y(other: float, d: float, raw_a: int) -> float:
    """StableswapMath.get_y with two coins."""
    ann = raw_a * 2 / 10000
    c = d * d / (other * 2) * d / (ann * 2)
    b = other + d / ann
    y = d
    for _ in range(255):
        previous = y
        y = (y * y + c) / (2 * y + b - d)
        # Cancellation in b-d is limited by D's precision, even when y is
        # much smaller. A tolerance based only on y can oscillate forever.
        if abs(y - previous) <= max(1e-13, abs(d) * 2e-15):
            return y
    raise ArithmeticError("StableSwap output balance did not converge")


class FXPool:
    def __init__(self, params: FXParams = FXParams(), price: float = 1.0,
                 timestamp: int = 0):
        if not math.isfinite(price) or price <= 0:
            raise ValueError("price must be positive and finite")
        self.params = params
        self.balances = [0.0, 0.0]
        self.price_scale = float(price)
        self.cached_price_oracle = float(price)
        self.last_prices = float(price)
        self.last_timestamp = timestamp
        self.D = 0.0
        self.total_supply = 0.0
        self.donation_shares = 0.0
        self.virtual_price = 1.0
        self.xcp_profit = 1.0
        self.xcp_profit_a = 1.0
        self.last_donation_release_ts = float(timestamp)
        self.donation_protection_expiry_ts = 0.0
        self.last_admin_fee_claim_timestamp = 0
        self.fees_paid = [0.0, 0.0]  # retained swap fees, denominated in output coin
        self.deposit_fee_shares = 0.0
        self.refuel_shares_minted = 0.0
        self.refuel_shares_burned = 0.0
        self.recenter_count = 0
        self.recenter_rejections = 0
        self.admin_tokens_paid = [0.0, 0.0]
        self.leftover_donations_to_admin = [0.0, 0.0]

    @classmethod
    def seeded(cls, external_seed: float, timestamp: int,
               params: FXParams = FXParams(), price: float = 1.0) -> FXPool:
        if not math.isfinite(external_seed) or external_seed <= 0:
            raise ValueError("seed must be positive and finite")
        pool = cls(params, price, timestamp)
        pool.add_liquidity(external_seed, external_seed / price, timestamp)
        return pool

    @classmethod
    def from_snapshot(cls, snapshot: Mapping) -> FXPool:
        """Load the pinned getter snapshot, reconstructing its cached EMA.

        The snapshot price_oracle is a live getter, not cached storage. Undo
        its known elapsed EMA step so subsequent calls don't age it twice.
        Last admin-claim timestamp was not observed and defaults to zero.
        """
        state = snapshot["state"]
        p = FXParams(
            raw_a=state["A()"], gamma=state["gamma()"],
            mid_fee=state["mid_fee()"] / 1e10, out_fee=state["out_fee()"] / 1e10,
            fee_gamma=state["fee_gamma()"] / 1e18,
            adjustment_step=state["adjustment_step()"] / 1e18,
            allowed_extra_profit=state["allowed_extra_profit()"] / 1e18,
            ma_time=float(state["packed_rebalancing_params()"] & (2**64 - 1)),
            donation_duration=state["donation_duration()"],
            donation_shares_max_ratio=state["donation_shares_max_ratio()"] / 1e18,
            donation_protection_period=state["donation_protection_period()"],
            donation_protection_lp_threshold=state["donation_protection_lp_threshold()"] / 1e18,
            admin_fee=state["admin_fee()"] / 1e10,
        )
        pool = cls(p, state["price_scale()"] / 1e18, state["last_timestamp()"])
        for name in ("D", "total_supply", "donation_shares", "virtual_price",
                     "xcp_profit", "xcp_profit_a", "last_prices"):
            key = "totalSupply()" if name == "total_supply" else name + "()"
            setattr(pool, name, state[key] / 1e18)
        pool.balances = [state[f"balances({i})"] / 1e18 for i in range(2)]
        pool.last_donation_release_ts = state["last_donation_release_ts()"]
        pool.donation_protection_expiry_ts = state["donation_protection_expiry_ts()"]
        now = int(datetime.fromisoformat(snapshot["metadata"]["block_timestamp_utc"]).timestamp())
        alpha = math.exp(-(now - pool.last_timestamp) / p.ma_time)
        incoming = min(pool.last_prices, 2 * pool.price_scale)
        pool.cached_price_oracle = (state["price_oracle()"] / 1e18 - incoming * (1-alpha)) / alpha
        return pool

    @property
    def user_supply(self) -> float:
        return self.total_supply - self.donation_shares

    def clone(self) -> FXPool:
        return deepcopy(self)

    def _check_time(self, timestamp: int):
        if not math.isfinite(timestamp) or timestamp < self.last_timestamp:
            raise ValueError("timestamp predates cached pool state")

    def _xp(self, balances=None, price=None) -> list[float]:
        balances = self.balances if balances is None else balances
        price = self.price_scale if price is None else price
        return [balances[0], balances[1] * price]

    @staticmethod
    def _xcp(d: float, price: float) -> float:
        return d / (2 * math.sqrt(price))

    def _fee(self, xp: list[float]) -> float:
        if sum(xp) <= 0:
            return self.params.mid_fee
        balance = min(1.0, max(0.0, 4 * (xp[0] / sum(xp)) * (xp[1] / sum(xp))))
        weight = self.params.fee_gamma * balance / (self.params.fee_gamma * balance + 1 - balance)
        fee = self.params.mid_fee * weight + self.params.out_fee * (1 - weight)
        # The fee itself has only 1e10 precision in Vyper. Keeping this
        # truncation matters much more to quotes than sub-wei reserve floors.
        return math.floor(fee * 1e10) / 1e10

    def fee(self) -> float:
        return self._fee(self._xp())

    def spot_price(self) -> float:
        if self.D == 0:
            return self.price_scale
        xp = self._xp()
        dr = self.D / 4 * (self.D / xp[0]) * (self.D / xp[1])
        xp0_a = self.params.raw_a * 2 / 10000 * xp[0]
        return (xp0_a + dr * xp[0] / xp[1]) / (xp0_a + dr) * self.price_scale

    def price_oracle(self, timestamp: int) -> float:
        self._check_time(timestamp)
        alpha = math.exp(-(timestamp - self.last_timestamp) / self.params.ma_time)
        return min(self.last_prices, 2 * self.price_scale) * (1-alpha) + self.cached_price_oracle * alpha

    def available_donation_shares(self, timestamp: int, protection: bool = True) -> float:
        self._check_time(timestamp)
        elapsed = max(0.0, timestamp - self.last_donation_release_ts)
        unlocked = self.donation_shares * min(1.0, elapsed / self.params.donation_duration)
        if not protection:
            return unlocked
        factor = min(1.0, max(0.0, self.donation_protection_expiry_ts - timestamp)
                     / self.params.donation_protection_period)
        return unlocked * (1-factor)

    def _quote_details(self, i: int, dx: float) -> tuple[float, float]:
        if i not in (0, 1) or not math.isfinite(dx) or dx <= 0:
            raise ValueError("swap needs coin index 0 or 1 and a positive finite input")
        if self.D <= 0:
            raise ValueError("empty pool")
        j = 1-i
        xp = self._xp()
        xp[i] += dx * (self.price_scale if i else 1)
        y = _get_y(xp[i], self.D, self.params.raw_a)
        gross = (xp[j] - y) / (self.price_scale if j else 1)
        if gross <= 0:
            raise ValueError("input is below floating-unit resolution")
        xp[j] = y  # dynamic fee is measured before retaining the output fee
        charged = gross * self._fee(xp)
        return gross - charged, charged

    def quote(self, i: int, dx: float) -> float:
        return self._quote_details(i, dx)[0]

    def swap(self, i: int, dx: float, timestamp: int) -> float:
        self._check_time(timestamp)
        dy, charged = self._quote_details(i, dx)
        self.balances[i] += dx
        self.balances[1-i] -= dy
        self.fees_paid[1-i] += charged
        self._tweak_price(timestamp, _invariant(self._xp(), self.params.raw_a))
        return dy

    def _token_fee(self, amounts: list[float], xp: list[float], timestamp: int,
                   donation: bool) -> float:
        if donation:
            return self.params.noise_fee
        # Source measures the deposit imbalance against the OLD raw balances.
        scaled = [amounts[0], amounts[1] * self.balances[0] / self.balances[1]]
        half_fee = self._fee(xp) / 2
        imbalance = abs(scaled[0] - scaled[1]) / sum(scaled)
        protection = min(1.0, max(0.0, self.donation_protection_expiry_ts - timestamp)
                         / self.params.donation_protection_period)
        penalty = min(half_fee, protection * half_fee * self.donation_shares
                      / self.total_supply / self.params.donation_shares_max_ratio)
        return half_fee * imbalance + self.params.noise_fee + penalty

    def add_liquidity(self, amount0: float, amount1: float, timestamp: int,
                      donation: bool = False) -> float:
        self._check_time(timestamp)
        amounts = [float(amount0), float(amount1)]
        if any(not math.isfinite(x) or x < 0 for x in amounts) or sum(amounts) <= 0:
            raise ValueError("deposit must contain nonnegative finite amounts")
        new_balances = [self.balances[i] + amounts[i] for i in range(2)]
        xp = self._xp(new_balances)
        d = _invariant(xp, self.params.raw_a)
        if self.D == 0:
            if donation:
                raise ValueError("initial liquidity must have a user owner")
            minted = self._xcp(d, self.price_scale)
            self.balances = new_balances
            self.D = d
            self.total_supply = minted
            self.virtual_price = self.xcp_profit = self.xcp_profit_a = 1.0
            return minted
        gross = self.total_supply * (d / self.D - 1)
        fee = gross * self._token_fee(amounts, xp, timestamp, donation)
        minted = gross - fee
        if minted <= 0:
            raise ValueError("nothing minted")
        if donation and ((self.donation_shares + minted) / (self.total_supply + minted)
                         > self.params.donation_shares_max_ratio):
            raise ValueError("donation above cap")
        if donation:
            unlocked = self.available_donation_shares(timestamp, protection=False)
            self.donation_shares += minted
            self.refuel_shares_minted += minted
            elapsed = math.floor(unlocked * self.params.donation_duration / self.donation_shares)
            self.last_donation_release_ts = timestamp - elapsed
        elif self.donation_shares > 0:
            relative = minted / (self.total_supply + minted)
            extension = min(self.params.donation_protection_period,
                            math.floor(relative * self.params.donation_protection_period
                                       / self.params.donation_protection_lp_threshold))
            self.donation_protection_expiry_ts = min(
                max(self.donation_protection_expiry_ts, timestamp) + extension,
                timestamp + self.params.donation_protection_period)
        self.balances = new_balances
        self.total_supply += minted
        self.deposit_fee_shares += fee
        self._tweak_price(timestamp, d)
        return minted

    def _tweak_price(self, timestamp: int, d: float):
        old_timestamp = self.last_timestamp
        if timestamp > old_timestamp:
            self.cached_price_oracle = self.price_oracle(timestamp)
            self.last_timestamp = timestamp
        # Spot at the OLD scale, after the balance-changing operation.
        xp = self._xp()
        dr = d / 4 * (d / xp[0]) * (d / xp[1])
        xp0_a = self.params.raw_a * 2 / 10000 * xp[0]
        self.last_prices = (xp0_a + dr * xp[0] / xp[1]) / (xp0_a + dr) * self.price_scale
        available = self.available_donation_shares(timestamp)
        xcp = self._xcp(d, self.price_scale)
        vp = xcp / self.total_supply
        if vp < self.virtual_price - 5e-12:
            raise ArithmeticError("virtual price decreased outside parameter ramp")
        # Absorb float roundoff at a scale much smaller than the fee budget.
        vp = max(vp, self.virtual_price)
        self.xcp_profit += vp - self.virtual_price
        threshold = max(1.0, (self.xcp_profit + 1) / 2)
        boosted = xcp / (self.total_supply - available)
        if boosted > threshold + self.params.allowed_extra_profit and timestamp > old_timestamp:
            norm = abs(self.cached_price_oracle / self.price_scale - 1)
            step = max(self.params.adjustment_step, norm / 5)
            if norm > step:
                new_price = (self.price_scale * (norm-step) + step * self.cached_price_oracle) / norm
                new_d = _invariant(self._xp(price=new_price), self.params.raw_a)
                new_xcp = self._xcp(new_d, new_price)
                goal = max(threshold, vp)
                burn = min(max(0.0, self.total_supply - new_xcp / goal), available)
                new_vp = new_xcp / (self.total_supply - burn)
                if new_vp > 1 and new_vp >= threshold:
                    if burn > 0:
                        unlocked = self.available_donation_shares(timestamp, protection=False)
                        remaining_unlocked = max(0.0, unlocked - burn * unlocked / available)
                        self.donation_shares = max(0.0, self.donation_shares - burn)
                        self.total_supply -= burn
                        elapsed = (math.floor(remaining_unlocked * self.params.donation_duration / self.donation_shares)
                                   if self.donation_shares > 0 and remaining_unlocked > 0 else 0.0)
                        self.last_donation_release_ts = timestamp - elapsed
                        self.refuel_shares_burned += burn
                    self.price_scale = new_price
                    self.D = new_d
                    self.virtual_price = new_vp
                    self.recenter_count += 1
                    return
                self.recenter_rejections += 1
        self.D = d
        self.virtual_price = vp

    def recoverable(self, shares: float) -> tuple[float, float]:
        if not math.isfinite(shares) or shares < 0 or shares > self.user_supply:
            raise ValueError("shares exceed user-owned supply")
        if self.total_supply == 0:
            return 0.0, 0.0
        return tuple(x * shares / self.total_supply for x in self.balances)

    def withdraw(self, shares: float, timestamp: int) -> tuple[float, float]:
        self._check_time(timestamp)
        amounts = self.recoverable(shares)
        if shares == 0:
            return amounts
        all_users = shares == self.user_supply
        self.D *= 1 - shares / self.total_supply
        self.total_supply -= shares
        self.balances = [x-y for x, y in zip(self.balances, amounts)]
        # Source sends refuel-only leftovers to the fee receiver, never the
        # last user; donation shares cannot be redeemed by a researcher.
        if all_users:
            for i in range(2):
                self.leftover_donations_to_admin[i] += self.balances[i]
            self.balances = [0.0, 0.0]
            self.total_supply = self.donation_shares = self.D = 0.0
            self.donation_protection_expiry_ts = 0.0
        return amounts

    def claim_admin_fees(self, timestamp: int) -> tuple[float, float]:
        """Source _claim_admin_fees assuming a configured fee receiver.

        This is explicit because its source caller (fixed-output withdrawal)
        is not implemented. Proportional withdrawal and swapping do not call
        it. The effective share is admin_fee / 2 of accrued xcp_profit.
        """
        self._check_time(timestamp)
        if (timestamp - self.last_admin_fee_claim_timestamp < self.params.admin_claim_interval
                or self.xcp_profit <= self.xcp_profit_a or self.total_supply < 1):
            return 0.0, 0.0
        fees = (self.xcp_profit - self.xcp_profit_a) * self.params.admin_fee / 2
        admin_shares = self.total_supply * (self.virtual_price / (self.virtual_price - fees) - 1)
        denominator = self.total_supply + admin_shares
        new_vp = self._xcp(self.D, self.price_scale) / denominator
        if new_vp < 1:
            return 0.0, 0.0
        self.xcp_profit -= 2 * fees
        self.virtual_price = new_vp
        self.last_admin_fee_claim_timestamp = timestamp
        self.D *= 1 - admin_shares / denominator
        if self.xcp_profit > self.xcp_profit_a:
            self.xcp_profit_a = self.xcp_profit
        amounts = tuple(x * admin_shares / denominator for x in self.balances)
        for i in range(2):
            self.balances[i] -= amounts[i]
            self.admin_tokens_paid[i] += amounts[i]
        return amounts
