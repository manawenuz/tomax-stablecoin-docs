"""Research model, not smart-contract or production risk-engine code."""
