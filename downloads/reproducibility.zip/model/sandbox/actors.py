"""Bounded myopic adversaries with explicit wallets and no future price access.

Search is a small disclosed action grid, not a claim of optimal adversarial
behavior. Only chosen, profitable attempts execute and pay transaction gas.
"""
from .state import Rejected


def _attempt(call):
    try:return call()
    except Rejected:return None


def sandwich(s,keeper,now):
    """Choose a funded front/keeper/back round trip by realized quote gain."""
    name='searcher';w=s.wallets[name];best=None
    for i,available in ((0,w.quote),(1,w.stable)):
        for fraction in (.025,.1,.3,.7):
            amount=available*fraction
            if amount*s.reference<s.seed*1e-6:continue
            t=s.fork();before=t.wallets[name].quote;eth_before=t.wallets[name].eth
            try:
                out=t.swap(name,i,amount,now)
                keeper.run(t,now+1)
                if i==0:t.swap(name,1,out,now+2)
                else:
                    required=t.quote_to_buy(amount)
                    t.swap(name,0,required,now+2)
                profit=t.wallets[name].quote-before+(t.wallets[name].eth-eth_before)*s.eth_price
                if best is None or profit>best[0]:best=(profit,i,amount)
            except (Rejected,ArithmeticError):continue
    if best is None or best[0]<=max(.1,s.seed*1e-6):return None
    _,i,amount=best;before=s.wallets[name].quote;eth_before=s.wallets[name].eth
    out=s.swap(name,i,amount,now);result=keeper.run(s,now+1)
    if i==0:s.swap(name,1,out,now+2)
    else:s.swap(name,0,s.quote_to_buy(amount),now+2)
    return dict(type='sandwich',coin=i,front_amount=amount,
                quote_profit=s.wallets[name].quote-before,
                net_profit=s.wallets[name].quote-before+(s.wallets[name].eth-eth_before)*s.eth_price,
                keeper_actions=len(result['actions']))


def borrow_search(s,keeper,now,ceiling_multiple=2,expected_reference=None):
    """Choose hold or immediate repay from bounded funded 96/4 borrow bundles.

Both borrower accounts coordinate. Hold profit is a marked collateral/debt
change, while a repay loop uses actual quote after repaying both vaults.
"""
    names=('lp','eth');before=sum(s.actor_equity(n) for n in names);best=None
    expected_reference=s.reference if expected_reference is None else expected_reference
    forecast_before=sum(s.actor_equity(n,expected_reference) for n in names)
    capacity=max(0,s.seed*ceiling_multiple-s.debt())
    for amount in (s.seed*.1,s.seed*.5,min(s.seed,capacity)):
        if amount<=0 or amount>capacity+1e-8:continue
        t=s.fork()
        try:
            ids=t.open_bundle(*names,amount,now);keeper.run(t,now+1)
            profit=sum(t.actor_equity(n,expected_reference) for n in names)-forecast_before
            if best is None or profit>best[0]:best=(profit,amount,False)
            for n,j in zip(names,ids):t.close(n,j,now+2)
            profit=sum(t.actor_equity(n) for n in names)-before
            if best is None or profit>best[0]:best=(profit,amount,True)
        except (Rejected,ArithmeticError):continue
    if best is None or best[0]<=max(.1,s.seed*1e-6):return None
    _,amount,close=best;ids=s.open_bundle(*names,amount,now);keeper.run(s,now+1)
    if close:
        for n,j in zip(names,ids):s.close(n,j,now+2)
    return dict(type='borrow_repay' if close else 'borrow_hold',debt=amount,expected_reference=expected_reference,
                marked_profit=sum(s.actor_equity(n) for n in names)-before)


def farmer_search(s,keeper,now):
    """Try a funded LP deposit/keeper/exit or exit existing unlocked LP."""
    name='farmer';w=s.wallets[name];before=s.actor_equity(name);best=None;stable_before=w.stable
    for fraction in (.1,.5,1):
        if w.quote<=0:continue
        t=s.fork();q=w.quote*fraction
        try:
            out=t.swap(name,0,q*.5,now)
            shares=t.deposit(name,q*.5,out,now)
            keeper.run(t,now+1);t.withdraw(name,shares,now+2)
            stable=t.wallets[name].stable-w.stable
            if stable>0:t.swap(name,1,stable,now+2)
            profit=t.actor_equity(name)-before
            if best is None or profit>best[0]:best=(profit,q)
        except (Rejected,ArithmeticError):continue
    if best is None or best[0]<=max(.1,s.seed*1e-6):return None
    _,q=best;out=s.swap(name,0,q*.5,now);shares=s.deposit(name,q*.5,out,now)
    keeper.run(s,now+1);s.withdraw(name,shares,now+2)
    to_sell=max(0,s.wallets[name].stable-stable_before)
    if to_sell>0:s.swap(name,1,to_sell,now+2)
    return dict(type='lp_roundtrip',marked_profit=s.actor_equity(name)-before)


def close_profitable(s,now):
    """Owners may voluntarily close risky or cheaply repayable vaults."""
    actions=[]
    for i,v in list(s.vaults.items()):
        if v.debt<=1e-8:continue
        name=v.owner;before=s.actor_equity(name);t=s.fork()
        try:
            t.close(name,i,now)
            profit=t.actor_equity(name)-before
            if profit>max(.5,s.seed*1e-5):
                s.close(name,i,now);actions.append(dict(type='owner_close',id=i,profit=profit))
        except (Rejected,ArithmeticError):continue
    return actions
