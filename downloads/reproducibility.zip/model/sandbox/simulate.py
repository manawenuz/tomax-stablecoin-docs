"""Causal sampled-market replay and transparent accounting metrics."""
from __future__ import annotations

import csv
from dataclasses import asdict
from pathlib import Path
import math

from model.fxswap import FXParams
from .state import Sandbox,Rejected
from .policies import Keeper
from . import actors
from .clock import CurrentTimeSandbox,CurrentTimeKeeper

ROOT=Path(__file__).resolve().parents[2]
DATA=ROOT/'research/sandbox_data'


def load_window(name,minutes=False):
    def read(path):
        with path.open() as f:return list(csv.DictReader(f))
    fx=read(DATA/f'IRR_1h_{name}.csv');eth=read(DATA/f'ETH_USDT_1h_{name}.csv')
    q0=float(fx[0]['close']);ticks={int(r['candle_end_timestamp']):dict(q=float(r['close']),native=False) for r in fx}
    if minutes:
        for r in read(DATA/f'IRR_1m_{name}.csv'):
            t=int(r['candle_end_timestamp'])
            if min(ticks)<t<=max(ticks):ticks[t]=dict(q=float(r['close']),native=True)
    eth={int(r['candle_end_timestamp']):float(r['close']) for r in eth}
    last_eth=eth[min(eth)];eth_time=min(eth);out=[]
    for t,r in sorted(ticks.items()):
        if t in eth:last_eth=eth[t];eth_time=t
        out.append(dict(t=t,reference=q0/r['q'],eth=last_eth,eth_time=eth_time,native=r['native']))
    return out


def setup(seed,reserve,eth_price,timestamp,raw_a=200000,initial_debt_multiple=.5,gas_gwei=1,audit=False,origination_band=.03):
    s=Sandbox.seeded(seed,reserve,eth_price,timestamp,FXParams(raw_a=raw_a),gas_gwei)
    s.origination_band=origination_band
    # Actor wealth is additional external capital, never counted as the seed.
    for name,q,e in [('lp',3*seed,.02*seed/eth_price),('eth',.5*seed,seed/eth_price),
                     ('searcher',2*seed,.03*seed/eth_price),('holder',.5*seed,.01*seed/eth_price),
                     ('farmer',seed,.02*seed/eth_price)]:s.add_actor(name,q,e)
    if audit:
        from evm import EVMJournalAudit
        s.audit=EVMJournalAudit.seeded(seed,timestamp,params=s.pool.params)
    s.report(1,eth_price,timestamp,timestamp,1)
    initial={n:dict(quote=w.quote,eth=w.eth) for n,w in s.wallets.items() if n!='keeper'}
    if initial_debt_multiple>0:s.open_bundle('lp','eth',seed*initial_debt_multiple,timestamp)
    # A real buyer provides finite circulating token inventory. Buying is paid
    # for, rather than treating treasury-held tokens as free adversary float.
    for name,fraction in [('holder',.25),('searcher',.1)]:
        s.swap(name,0,s.wallets[name].quote*fraction,timestamp)
    s.assert_invariants();return s,initial


def mark(s,t,phase):
    p=s.pool;ref=s.market_reference;spot=p.spot_price();fee=p.fee();size=s.seed*.01
    ask=size/p.quote(0,size) if p.quote(0,size)>0 else math.inf
    stable=size/ref;bid=p.quote(1,stable)/stable
    w=s.wallets['keeper'];q,st=s.recoverable(w.lp)
    return dict(t=t,phase=phase,reference=ref,spot=spot,error=spot/ref-1,
                marginal_bid_error=spot*(1-fee)/ref-1,marginal_ask_error=spot/(1-fee)/ref-1,
                finite_bid_error=bid/ref-1,finite_ask_error=ask/ref-1,
                protocol_equity=s.protocol_equity(ref,s.market_eth),active_credit_shortfall=s.active_shortfall(ref,s.market_eth),quote_reserve=w.quote,
                treasury_lp_nav=q+st*ref,treasury_stable=w.stable,
                pool_quote=p.balances[0],pool_stable=p.balances[1],center=p.price_scale,
                debt=s.debt(),eth_debt_share=s.debt('eth')/s.debt() if s.debt()>0 else 0,
                bad_debt=s.bad_debt,pending=s.pending_count(),gas_eth=s.gas_eth,
                refuel_quote=s.refuel_quote,fx_age=max(0,t-s.fx_time))


def replay(window,config,seed=10000,minutes=False,audit=False,attack=True,stress=None):
    ticks=load_window(window,minutes);first=ticks[0];keeper=Keeper(config.get('keeper',{}))
    s,initial=setup(seed,seed*config.get('reserve_multiple',.25),first['eth'],first['t'],
                    config.get('raw_a',200000),config.get('initial_debt_multiple',.5),config.get('gas_gwei',1),audit,
                    config.get('origination_band',.03))
    trace=[];attack_events=[];keeper_results=[];seq=1;last_actor=first['t']-86400
    start=first['t'];pre_worst=0.;all_trade_worst=0.;history=[]
    for index,tick in enumerate(ticks):
        t=tick['t'];r=tick['reference'];eth=tick['eth']
        if stress in ('down_jump','devaluation_outage') and t>=start+3*86400:r*=.8
        if stress=='up_jump' and t>=start+3*86400:r*=1.2
        if stress=='eth_crash' and t>=start+3*86400:eth*=.5
        s.observe_market(r,eth,t)
        feed_out=stress in ('feed_outage','devaluation_outage') and start+3*86400<=t<start+4*86400
        keeper_out=stress=='keeper_outage' and start+3*86400<=t<start+4*86400
        class OfflineKeeper:
            def run(self,system,now):return dict(status='keeper_offline',actions=[],errors=[])
        available_keeper=OfflineKeeper() if keeper_out else keeper
        if not feed_out:
            seq+=1;s.report(r,eth,t,t,seq,eth_timestamp=tick['eth_time'])
        else:s.now=t
        pre=mark(s,t,'observed_before_keeper');trace.append(pre);pre_worst=max(pre_worst,abs(pre['error']))
        old=next((x[1] for x in reversed(history) if x[0]<=t-86400),r)
        forecast=r*max(.95,min(1.05,r/old))
        history.append((t,r))
        if attack and t-last_actor>=6*3600 and not feed_out:
            bounded=CurrentTimeSandbox(s,t);controller=CurrentTimeKeeper(available_keeper,t)
            functions=[lambda:actors.sandwich(bounded,controller,t),
                       lambda:actors.borrow_search(bounded,controller,t,config.get('debt_ceiling_multiple',2),forecast),
                       lambda:actors.farmer_search(bounded,controller,t)]
            for fn in functions:
                try:
                    result=fn()
                    if result:attack_events.append(dict(t=t,**result))
                except Rejected as exc:attack_events.append(dict(t=t,type='execution_revert',reason=str(exc)))
            attack_events.extend(dict(t=t,**r) for r in actors.close_profitable(bounded,t))
            last_actor=t
        if stress=='bank_run' and index==len(ticks)//2:
            w=s.wallets['holder']
            try:s.swap('holder',1,w.stable*.99,t)
            except Rejected:pass
        # The permissionless AMM may trade before keeper response; this sample
        # explicitly retains that state instead of only showing repaired prices.
        pre_action=mark(s,t,'after_actors');trace.append(pre_action)
        all_trade_worst=max(all_trade_worst,abs(pre_action['error']))
        result=available_keeper.run(s,t)
        keeper_results.append(result)
        post=mark(s,t,'after_keeper');trace.append(post);s.assert_invariants()
    last=ticks[-1];actor_results={}
    for name,b in initial.items():
        holding=b['quote']+b['eth']*s.market_eth
        final=s.actor_equity(name,s.market_reference,s.market_eth)
        actor_results[name]=dict(final_marked_equity=final,holding_benchmark=holding,
                                 pnl_vs_holding=final-holding,quote_wallet=s.wallets[name].quote,
                                 own_token_wallet=s.wallets[name].stable,eth_wallet=s.wallets[name].eth,
                                 locked_debt=sum(v.debt for v in s.vaults.values() if v.owner==name))
    post=[x for x in trace if x['phase']=='after_keeper'];pre=[x for x in trace if x['phase']=='observed_before_keeper']
    active_lp=0.;active_holding=0.
    for v in s.vaults.values():
        if v.kind=='lp' and v.debt>0:
            q,st=s.pool.recoverable(v.collateral);active_lp+=q+st*s.market_reference
            active_holding+=v.initial_quote+v.initial_stable*s.market_reference
    keeper_gas=sum(s.GAS[e['op']] for e in s.events if e['actor']=='keeper')*s.gas_gwei*1e-9
    pull_reports=len({e['report_at'] for e in s.events if 'report_at' in e and
                     (e['actor']=='keeper' or e['op']=='open_bundle')})
    summary=dict(window=window,stress=stress,seed=seed,additional_protocol_reserve=s.reserve,
        initial_total_lp_value=2*seed,bootstrap_liability=seed,config=config,
        actor_external_quote_endowment=sum(x['quote'] for x in initial.values()),
        actor_external_eth_endowment=sum(x['eth'] for x in initial.values()),
        observations=len(ticks),native_minute_observations=sum(x['native'] for x in ticks),days=14,
        max_pre_keeper_error=max(abs(x['error']) for x in pre),
        max_after_actor_error=all_trade_worst,max_post_keeper_error=max(abs(x['error']) for x in post),
        max_committed_transaction_error=max(abs(e['spot']/e['market_reference']-1) for e in s.events if 'spot' in e),
        post_keeper_breaches=sum(abs(x['error'])>.030001 for x in post),
        pre_keeper_breaches=sum(abs(x['error'])>.030001 for x in pre),
        finite_quote_breaches=sum(max(abs(x['finite_bid_error']),abs(x['finite_ask_error']))>.03 for x in post),
        final_protocol_equity=post[-1]['protocol_equity'],protocol_equity_change=post[-1]['protocol_equity']-seed-s.reserve,
        final_debt=s.debt(),peak_debt=max(x['debt'] for x in trace),gross_lp_originated=s.minted_lp_debt,
        gross_eth_originated=s.minted_eth_debt,final_eth_debt_share=post[-1]['eth_debt_share'],
        final_quote_reserve=s.wallets['keeper'].quote,final_treasury_lp_nav=post[-1]['treasury_lp_nav'],
        bad_debt=s.bad_debt,insurance_quote=s.insurance_quote,pending=s.pending_count(),
        max_active_credit_shortfall=max(x['active_credit_shortfall'] for x in trace),
        max_pending=max(x['pending'] for x in post),stale_observations=sum(r['status']=='stale' for r in keeper_results),
        refuel_quote=s.refuel_quote,gas_eth=s.gas_eth,gas_quote_mark=s.gas_quote_mark,
        keeper_gas_eth=keeper_gas,keeper_gas_eth_per_day=keeper_gas/14,
        successful_risk_action_report_batches=pull_reports,
        oracle_publication_gas_assumption=90000,
        keeper_plus_pull_reports_eth_per_day=(keeper_gas+pull_reports*90000*s.gas_gwei*1e-9)/14,
        active_borrower_lp_nav=active_lp,active_borrower_lp_holding=active_holding,
        active_borrower_lp_difference_vs_holding=active_lp-active_holding,
        exited_borrower_lp_difference_vs_holding=sum(e.get('result',{}).get('passive_lp_difference_vs_holding',0)
            for e in s.events if isinstance(e.get('result'),dict)),
        assumed_gas_gwei=s.gas_gwei,gas_scope='all actors and keeper; configured gas units, not measured lending contracts',
        operations=s.counters,actors=actor_results,adversarial_actions=len(attack_events),
        keeper_errors=sorted({e for r in keeper_results for e in r['errors']}),
        sample_note='actual hourly closes; optional partial native minutes; no intra-observation guarantee')
    if s.audit:summary['evm']=s.audit.summary()
    return summary,trace,s.events,attack_events
