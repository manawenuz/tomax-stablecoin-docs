"""Finite-wallet research sandbox. No production contracts or live orders."""
