"""Finite-wallet paper experiment, with actual public observations and no orders.

JSON snapshots contain only the sandbox's economic/configuration state. EVM
adapters, audits and pool journals are neither imported nor retained. A step is
one current decision; missed wall time never creates catch-up prices/actions.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from copy import deepcopy
from dataclasses import asdict, dataclass
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import urllib.parse

from model.fxswap import FXParams
from model.sandbox.state import JournalPool, Rejected, Sandbox, Vault, Wallet

FORTNIGHT = 14 * 86400
SCHEMA = 1
ORACLE_FIELDS = ("reference", "eth_price", "fx_time", "eth_time", "sequence", "now",
                 "market_reference", "market_eth", "market_time")
CONFIG_FIELDS = ("seed", "reserve", "gas_gwei", "max_fx_age", "max_eth_age", "lp_threshold",
                 "eth_threshold", "bonus", "max_vaults", "origination_band")
HTTP_WORKER = r'''
import hashlib,json,sys,time,urllib.request
try:
    req=urllib.request.Request(sys.argv[1],headers={"User-Agent":"Tomax-Paper-Observations/1.0"})
    with urllib.request.urlopen(req,timeout=float(sys.argv[2])) as response:
        raw=response.read(1000001)
        if len(raw)>1000000:raise ValueError("Oversized public feed response")
        meta={"http_status":response.status,"http_date":response.headers.get("Date"),
              "raw_sha256":hashlib.sha256(raw).hexdigest()}
    print(json.dumps({"ok":True,"payload":json.loads(raw),"received_at":int(time.time()),"metadata":meta},allow_nan=False))
except Exception as error:
    print(json.dumps({"ok":False,"error":type(error).__name__+": "+str(error)}))
'''


@dataclass(frozen=True)
class Quote:
    asset: str
    value: float
    observed_at: int
    received_at: int
    source: str
    metadata: dict | None = None


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def normalize_config(config):
    out = {"seed": 10000., "reserve": 2500., "raw_a": 200000, "initial_debt_multiple": .5,
           "gas_gwei": 1., "max_fx_age": 180, "max_eth_age": 120,
           "origination_band": .03,
           "actors_enabled": True, "actor_cadence_seconds": 21600, "debt_ceiling_multiple": 2.,
           "initial_inventory_purchases": {"holder": .25, "searcher": .1},
           "keeper": {"mode": "inventory", "target": .01, "trigger": .015,
                      "max_steps": 4, "min_pool_value_multiple": .25, "preflight_liquidations": True}}
    unknown = set(config) - (set(out) | {"actors"})
    if unknown:
        raise ValueError(f"Unknown paper configuration: {sorted(unknown)}")
    keeper_defaults = out["keeper"].copy()
    out.update(deepcopy(config))
    for key in ("seed", "reserve", "initial_debt_multiple", "gas_gwei", "max_fx_age", "max_eth_age", "debt_ceiling_multiple"):
        if not isinstance(out[key], (float, int)) or not math.isfinite(out[key]) or out[key] < 0:
            raise ValueError(f"Invalid {key}")
    if out["seed"] <= 0 or min(out["max_fx_age"], out["max_eth_age"]) <= 0:
        raise ValueError("Positive seed and quote-age limits required")
    FXParams(raw_a=out["raw_a"])
    if not isinstance(out["keeper"], dict):
        raise ValueError("keeper must be a configuration object")
    out["keeper"] = {**keeper_defaults, **out["keeper"]}
    if out["origination_band"] is not None and (not isinstance(out["origination_band"], (int, float))
                                               or not math.isfinite(out["origination_band"])
                                               or not 0 < out["origination_band"] < 1):
        raise ValueError("Origination band must be positive and finite, or explicitly None for legacy research")
    if not isinstance(out["actors_enabled"], bool) or not isinstance(out["actor_cadence_seconds"], int) or out["actor_cadence_seconds"] < 1:
        raise ValueError("Boolean actors_enabled and positive integer actor cadence required")
    seed = out["seed"]
    # Same external endowments as historical setup. ETH quote notionals are
    # converted once at the FIRST actual ETH observation, never a placeholder.
    out.setdefault("actors", {"lp": {"quote": 3 * seed, "eth_quote": .02 * seed},
                              "eth": {"quote": .5 * seed, "eth_quote": seed},
                              "searcher": {"quote": 2 * seed, "eth_quote": .03 * seed},
                              "holder": {"quote": .5 * seed, "eth_quote": .01 * seed},
                              "farmer": {"quote": seed, "eth_quote": .02 * seed}})
    if not {"lp", "eth", "searcher", "holder", "farmer"} <= set(out["actors"]) or "keeper" in out["actors"]:
        raise ValueError("Fund lp/eth/searcher/holder/farmer actors; keeper is funded by reserve")
    for name, assets in out["actors"].items():
        if (not isinstance(name, str) or not isinstance(assets, dict) or set(assets) - {"quote", "eth", "eth_quote"}
                or {"eth", "eth_quote"} <= set(assets)):
            raise ValueError("Actor funding supports quote and either ETH units or initial ETH quote notional")
        if any(not isinstance(v, (int, float)) or not math.isfinite(v) or v < 0 for v in assets.values()):
            raise ValueError("Actor funding must be finite and nonnegative")
    if not isinstance(out["initial_inventory_purchases"], dict):
        raise ValueError("Initial paid inventory purchases must name funded actors")
    for name, fraction in out["initial_inventory_purchases"].items():
        if name not in out["actors"] or not isinstance(fraction, (int, float)) or not 0 <= fraction <= 1:
            raise ValueError("Initial purchase fractions must be between zero and one")
    canonical(out)
    return out


def config_hash(config):
    """Hash the entire normalized paper configuration, including finite funding."""
    return hashlib.sha256(canonical(normalize_config(config)).encode()).hexdigest()


def snapshot_system(system):
    system.assert_invariants()
    core = {}
    for key in Sandbox.CORE:
        value = getattr(system, key)
        if key == "pool":
            core[key] = {"params": asdict(value.params),
                         "state": {k: deepcopy(v) for k, v in vars(value).items() if k not in ("params", "journal")}}
        elif key == "wallets":
            core[key] = {name: asdict(w) for name, w in value.items()}
        elif key == "vaults":
            core[key] = {str(index): asdict(v) for index, v in value.items()}
        else:
            core[key] = deepcopy(value)
    result = {"schema_version": SCHEMA, "core": core,
              "config": {key: getattr(system, key) for key in CONFIG_FIELDS},
              "oracle": {key: getattr(system, key) for key in ORACLE_FIELDS if hasattr(system, key)},
              "events": deepcopy(system.events)}
    # Enforce JSON-only, finite values; no arbitrary class paths or executable data.
    return json.loads(canonical(result))


def restore_system(snapshot):
    if snapshot.get("schema_version") != SCHEMA or set(snapshot["core"]) != set(Sandbox.CORE):
        raise ValueError("Incompatible sandbox snapshot schema")
    canonical(snapshot)
    pool_data = snapshot["core"]["pool"]
    pool = JournalPool(FXParams(**pool_data["params"]))
    expected_pool_fields = set(vars(pool)) - {"params", "journal"}
    if set(pool_data["state"]) != expected_pool_fields:
        raise ValueError("Incompatible pool snapshot fields")
    for key, value in pool_data["state"].items():
        setattr(pool, key, deepcopy(value))
    pool.journal = []
    system = Sandbox.__new__(Sandbox)
    for key in Sandbox.CORE:
        value = snapshot["core"][key]
        if key == "pool":
            value = pool
        elif key == "wallets":
            value = {name: Wallet(**assets) for name, assets in value.items()}
        elif key == "vaults":
            value = {int(index): Vault(**vault) for index, vault in value.items()}
        setattr(system, key, deepcopy(value) if key != "pool" else value)
    if set(snapshot["config"]) != set(CONFIG_FIELDS) or set(snapshot["oracle"]) - set(ORACLE_FIELDS):
        raise ValueError("Incompatible sandbox configuration fields")
    for key, value in {**snapshot["config"], **snapshot["oracle"]}.items():
        setattr(system, key, value)
    system.market_reference = getattr(system, "market_reference", system.reference)
    system.market_eth = getattr(system, "market_eth", system.eth_price)
    system.market_time = getattr(system, "market_time", system.now)
    system.events = deepcopy(snapshot.get("events", []))
    system.audit = None
    system.assert_invariants()
    return system


def new_checkpoint(config, now):
    config = normalize_config(config)
    return {"schema_version": SCHEMA, "kind": "finite_wallet_mock_paper", "config": config,
            "policy_config_sha256": config_hash(config), "created_at": int(now),
            "started_at": None, "ends_at": None, "status": "paused", "system": None,
            "baseline_fx_irr_per_usdt": None, "gate_evidence": None, "last_quotes": {},
            "last_checked_at": None, "last_decision_at": None, "decision_count": 0,
            "last_actor_at": None, "reference_history": [],
            "history": [], "last_result": {"reason": "awaiting_gate_controller_and_fresh_actual_quotes"},
            "limitations": ["Mock balances and settlement only; no blockchain, keys or orders.",
                            "Public exchange candles/tickers do not prove executable prices or continuous parity.",
                            "Missed wall time causes no catch-up decisions; failed feeds pause new decisions."]}


def _result(data, now, status, reason, **details):
    data["status"] = status
    data["last_result"] = {"checked_at": now, "reason": reason, **details}
    data["history"].append(deepcopy(data["last_result"]))
    return data["last_result"]


def _validate_quote(quote, asset, now, max_age):
    if not isinstance(quote, Quote) or quote.asset != asset:
        raise ValueError(f"Missing {asset} quote")
    if not isinstance(quote.value, (float, int)) or not math.isfinite(quote.value) or quote.value <= 0:
        raise ValueError(f"Invalid {asset} price")
    if not all(isinstance(t, int) and not isinstance(t, bool) for t in (quote.observed_at, quote.received_at)):
        raise ValueError("Integer observation and receipt timestamps required")
    if quote.observed_at > quote.received_at or quote.received_at > now:
        raise ValueError("Future observation or receipt timestamp")
    if now - quote.observed_at > max_age:
        raise TimeoutError(f"Stale {asset} observation")


from .clock import CurrentTimeSandbox, CurrentTimeKeeper


def actor_cycle(system, keeper, now, forecast, config):
    from model.sandbox import actors
    bounded = CurrentTimeSandbox(system, now)
    controller = CurrentTimeKeeper(keeper, now)
    results = []
    for name, call in (
        ("sandwich", lambda: actors.sandwich(bounded, controller, now)),
        ("borrow_search", lambda: actors.borrow_search(bounded, controller, now, config["debt_ceiling_multiple"], forecast)),
        ("farmer_search", lambda: actors.farmer_search(bounded, controller, now))):
        try:
            result = call()
            if result:
                results.append(result)
        except (Rejected, ArithmeticError, ValueError) as error:
            results.append({"type": name, "error": f"{type(error).__name__}: {error}"})
    try:
        results.extend(actors.close_profitable(bounded, now))
    except (Rejected, ArithmeticError, ValueError) as error:
        results.append({"type": "close_profitable", "error": f"{type(error).__name__}: {error}"})
    return results


def advance(data, now, fx, eth, *, keeper=None, activate=False, gate_passed=False, feed_errors=None):
    """Mutate one checkpoint using one actual observation pair; no network I/O.

    A passed gate authorizes only the initial transition. Once started, the
    exact configuration hash and stored evidence bind subsequent invocations.
    Policy errors retain funded reverted-action gas when invariants still hold.
    """
    now = int(now)
    if data.get("schema_version") != SCHEMA or data["policy_config_sha256"] != config_hash(data["config"]):
        raise ValueError("Checkpoint configuration hash/schema mismatch")
    if data["ends_at"] is not None and now >= data["ends_at"]:
        data["last_checked_at"] = max(now, data["last_checked_at"] or now)
        return _result(data, now, "complete", "fourteen_day_hard_stop")
    if data.get("fatal_error"):
        return _result(data, now, "halted", "manual_review_required", error=data["fatal_error"])
    if data["last_checked_at"] is not None and now < data["last_checked_at"]:
        return _result(data, now, "paused", "wall_clock_moved_backwards")
    data["last_checked_at"] = now
    if data["started_at"] is None and not (activate and gate_passed and keeper is not None):
        return _result(data, now, "paused", "awaiting_gate_controller_and_fresh_actual_quotes")
    if keeper is None:
        return _result(data, now, "paused", "controller_unavailable")
    if feed_errors:
        return _result(data, now, "stale", "feed_unavailable", feed_errors=deepcopy(feed_errors),
                       available_quotes={q.asset: asdict(q) for q in (fx, eth) if isinstance(q, Quote)})
    try:
        _validate_quote(fx, "IRR_USDT", now, data["config"]["max_fx_age"])
        _validate_quote(eth, "ETH_USDT", now, data["config"]["max_eth_age"])
    except TimeoutError as error:
        return _result(data, now, "stale", "stale_actual_quote", error=str(error))
    except ValueError as error:
        return _result(data, now, "paused", "invalid_actual_quote", error=str(error))
    for quote in (fx, eth):
        previous = data["last_quotes"].get(quote.asset)
        if previous and quote.observed_at <= previous["observed_at"]:
            return _result(data, now, "waiting", "duplicate_or_out_of_order_quote")
    config = data["config"]
    first = data["system"] is None
    if first:
        data["baseline_fx_irr_per_usdt"] = fx.value
        data["started_at"] = now
        data["ends_at"] = now + FORTNIGHT
        data["gate_evidence"] = data.get("gate_evidence") or {"historical_gate_passed": True,
                                    "policy_config_sha256": data["policy_config_sha256"]}
        system = Sandbox.seeded(config["seed"], config["reserve"], eth.value, now,
                                params=FXParams(raw_a=config["raw_a"]), gas_gwei=config["gas_gwei"])
        system.max_fx_age = config["max_fx_age"]
        system.max_eth_age = config["max_eth_age"]
        system.origination_band = config["origination_band"]
        for name, funding in config["actors"].items():
            system.add_actor(name, quote=funding.get("quote", 0),
                             eth=funding.get("eth", funding.get("eth_quote", 0) / eth.value))
    else:
        system = restore_system(data["system"])
    reference = data["baseline_fx_irr_per_usdt"] / fx.value
    system.report(reference, eth.value, fx.observed_at, now, system.sequence + 1,
                  eth_timestamp=eth.observed_at)
    system.observe_market(reference, eth.value, now)
    previous_snapshot = snapshot_system(system)
    from model.sandbox.simulate import mark
    before_metrics=mark(system,now,'observed_before_keeper')
    policy_result = None
    policy_error = None
    actor_result = []
    old_reference = next((r["reference"] for r in reversed(data["reference_history"])
                          if r["observed_at"] <= fx.observed_at - 86400), reference)
    forecast = reference * max(.95, min(1.05, reference / old_reference))
    try:
        if first and config["initial_debt_multiple"] > 0:
            system.open_bundle("lp", "eth", config["seed"] * config["initial_debt_multiple"], now)
        if first:
            for name, fraction in config["initial_inventory_purchases"].items():
                amount = system.wallets[name].quote * fraction
                if amount > 0:
                    system.swap(name, 0, amount, now)
        if (config["actors_enabled"] and
                (data["last_actor_at"] is None or now - data["last_actor_at"] >= config["actor_cadence_seconds"])):
            data["last_actor_at"] = now
            actor_result = actor_cycle(system, keeper, now, forecast, config)
        actor_metrics=mark(system,now,'after_actors')
        policy_result = keeper.run(system, now)
    except Exception as error:
        policy_error = f"{type(error).__name__}: {error}"
    try:
        data["system"] = snapshot_system(system)
    except (AssertionError, ValueError, TypeError) as error:
        data["system"] = previous_snapshot
        data["fatal_error"] = f"Uncommitted invalid decision state: {type(error).__name__}: {error}"
        return _result(data, now, "halted", "conservation_failure_decision_not_committed", error=data["fatal_error"])
    data["last_quotes"] = {q.asset: asdict(q) for q in (fx, eth)}
    gap = None if data["last_decision_at"] is None else now - data["last_decision_at"]
    data["last_decision_at"] = now
    data["reference_history"].append({"observed_at": fx.observed_at, "decision_at": now, "reference": reference})
    data["decision_count"] += 1
    # Policy return values must also be JSON-only; a malformed diagnostic cannot
    # undo already funded mock actions or their gas.
    try:
        canonical(policy_result)
    except (TypeError, ValueError):
        policy_result = {"unserializable_result_type": type(policy_result).__name__}
    return _result(data, now, "policy_error" if policy_error else "running",
                   "controller_error" if policy_error else "current_observation_decision",
                   decision=data["decision_count"], gap_seconds=gap,
                   quotes={q.asset: asdict(q) for q in (fx, eth)},
                   policy_result=policy_result, actor_result=actor_result, actor_forecast=forecast, error=policy_error,
                   metrics=dict(before=before_metrics,after_actors=locals().get('actor_metrics'),
                                after=mark(system,now,'after_keeper')))


@contextmanager
def checkpoint_lock(path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with Path(str(path) + ".lock").open("a+") as stream:
        fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            yield
        finally:
            fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def save_checkpoint(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = canonical(data) + "\n"
    temporary = None
    try:
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent,
                                         prefix=f".{path.name}.", suffix=".tmp", delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        temporary = None
        descriptor = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def load_checkpoint(path):
    def reject_constant(value):
        raise ValueError(f"Nonfinite JSON value: {value}")
    data = json.loads(Path(path).read_text(), parse_constant=reject_constant)
    if data.get("schema_version") != SCHEMA or data.get("kind") != "finite_wallet_mock_paper":
        raise ValueError("Unsupported paper checkpoint")
    if data["policy_config_sha256"] != config_hash(data["config"]):
        raise ValueError("Checkpoint configuration hash mismatch")
    if data["started_at"] is not None and data["ends_at"] != data["started_at"] + FORTNIGHT:
        raise ValueError("Paper hard end does not equal start plus fourteen days")
    if data["system"] is not None:
        restore_system(data["system"])
    return data


def gate_matches(evidence, data):
    return (isinstance(evidence, dict) and evidence.get("historical_gate_passed") is True
            and evidence.get("policy_config_sha256") == data["policy_config_sha256"])


def load_keeper(config):
    # Keep EVM work out of the live harness. Missing policy is a paused state.
    from model.sandbox.policies import Keeper
    return Keeper(config["keeper"])


def controller_status(config):
    try:
        keeper = load_keeper(config)
        return {"available": callable(getattr(keeper, "run", None)), "adapter": "Keeper(config).run(system, now)"}
    except Exception as error:
        return {"available": False, "error": f"{type(error).__name__}: {error}"}


def wallex_quote(payload, received_at, url, metadata=None):
    if not isinstance(payload, dict) or payload.get("s") != "ok":
        raise ValueError("Wallex minute history unavailable")
    keys = ("t", "o", "h", "l", "c", "v")
    if not all(isinstance(payload.get(k), list) for k in keys) or len({len(payload[k]) for k in keys}) != 1:
        raise ValueError("Invalid Wallex parallel candle arrays")
    closed = [i for i, stamp in enumerate(payload["t"]) if int(stamp) % 60 == 0 and int(stamp) + 60 <= received_at]
    if not closed:
        raise ValueError("No actual closed Wallex minute available")
    index = max(closed, key=lambda i: int(payload["t"][i]))
    stamp = int(payload["t"][index])
    price = float(payload["c"][index]) * 10
    details = {"url": url, "native_symbol": "USDTTMN", "native_price_units": "TMN per USDT",
               "normalized_price_units": "IRR per USDT", "price_multiplier": 10,
               "candle_open_timestamp": stamp, "candle_end_timestamp": stamp + 60,
               "volume_usdt": str(payload["v"][index]), "observation_kind": "latest_closed_native_minute",
               **(metadata or {})}
    quote = Quote("IRR_USDT", price, stamp + 60, int(received_at), "Wallex", details)
    _validate_quote(quote, "IRR_USDT", received_at, float("inf"))
    return quote


def binance_quote(payload, received_at, url, metadata=None):
    if not isinstance(payload, dict) or payload.get("symbol") != "ETHUSDT" or "closeTime" not in payload:
        raise ValueError("Binance ticker with exchange closeTime required")
    quote = Quote("ETH_USDT", float(payload["lastPrice"]), int(payload["closeTime"]) // 1000,
                  int(received_at), "Binance", {"url": url, "price_units": "USDT per ETH",
                    "exchange_close_time_ms": int(payload["closeTime"]),
                    "observation_kind": "exchange_24hr_ticker_last_price", **(metadata or {})})
    _validate_quote(quote, "ETH_USDT", received_at, float("inf"))
    return quote


class PublicFeeds:
    """Bounded, keyless GET adapters; failed source never supplies a price."""
    def __init__(self, timeout=3., attempts=2):
        if not 0 < timeout <= 15 or not 1 <= attempts <= 3:
            raise ValueError("Use timeout <=15 seconds and at most three attempts")
        self.timeout = timeout
        self.attempts = attempts

    def _get(self, url):
        for attempt in range(self.attempts):
            try:
                # A killable subprocess bounds DNS, TLS and response transfer as
                # a whole; urllib's socket timeout alone does not bound DNS.
                response = subprocess.run([sys.executable, "-c", HTTP_WORKER, url, str(self.timeout)],
                                          stdin=subprocess.DEVNULL, capture_output=True, text=True,
                                          timeout=self.timeout + 1, check=False)
                if response.returncode:
                    raise OSError(f"Public feed worker exited {response.returncode}")
                result = json.loads(response.stdout)
                if not result.get("ok"):
                    raise OSError(result.get("error", "Public feed response unavailable"))
                metadata = {**result["metadata"], "attempt": attempt + 1,
                            "hard_attempt_deadline_seconds": self.timeout + 1}
                return result["payload"], int(result["received_at"]), metadata
            except subprocess.TimeoutExpired as error:
                if attempt + 1 == self.attempts:
                    raise TimeoutError("Public feed worker hard deadline exceeded") from error
            except (OSError, ValueError):
                if attempt + 1 == self.attempts:
                    raise
        raise RuntimeError("No feed attempt made")

    def fx(self):
        closed_boundary = int(time.time()) // 60 * 60
        url = "https://api.wallex.ir/v1/udf/history?" + urllib.parse.urlencode(
            {"symbol": "USDTTMN", "resolution": "1", "from": closed_boundary - 5 * 60, "to": closed_boundary - 1})
        payload, received, metadata = self._get(url)
        return wallex_quote(payload, received, url, metadata)

    def eth(self):
        url = "https://api.binance.com/api/v3/ticker/24hr?symbol=ETHUSDT"
        payload, received, metadata = self._get(url)
        return binance_quote(payload, received, url, metadata)

    def collect(self):
        quotes = {}
        errors = {}
        with ThreadPoolExecutor(max_workers=2) as pool:
            futures = {"IRR_USDT": pool.submit(self.fx), "ETH_USDT": pool.submit(self.eth)}
            for name, future in futures.items():
                try:
                    quotes[name] = future.result()
                except Exception as error:
                    errors[name] = f"{type(error).__name__}: {error}"
        return {"quotes": quotes, "errors": errors, "checked_at": int(time.time())}


def status(data, now=None):
    now = int(time.time()) if now is None else int(now)
    result = {key: data[key] for key in ("status", "created_at", "started_at", "ends_at", "decision_count",
                                        "last_checked_at", "last_decision_at", "last_result", "policy_config_sha256")}
    if data["ends_at"] is not None and now >= data["ends_at"]:
        result["status"] = "complete"
    result["controller"] = controller_status(data["config"])
    result["clock_running"] = data["started_at"] is not None and now < data["ends_at"]
    result["mock_only"] = True
    result["feed_ages_seconds"] = {asset: now - q["observed_at"] for asset, q in data["last_quotes"].items()}
    if data["system"] is not None:
        system = restore_system(data["system"])
        result["economic_state"] = {"wallets": {k: asdict(v) for k, v in system.wallets.items()},
                                    "gas_eth": system.gas_eth, "gas_quote_mark": system.gas_quote_mark,
                                    "debt": system.debt(), "bad_debt": system.bad_debt,
                                    "protocol_equity": system.protocol_equity(), "conservation_checked": True}
    return result
