"""Trusted observed-block clock adapters for ordered local research calls."""
class CurrentTimeSandbox:
    """Known actor helpers may order mock calls at +1/+2; execute at wall time.

    This is an adapter for trusted research helpers, not a Python security
    sandbox. Planning forks retain isolated economic state and the same time.
    """
    TRANSACTIONS = {"swap", "deposit", "withdraw", "rotate", "refuel", "open_bundle", "close", "liquidate"}

    def __init__(self, system, now):
        self._system = system
        self._current_time = now

    def __getattr__(self, name):
        value = getattr(self._system, name)
        if name not in self.TRANSACTIONS:
            return value
        def current_call(*args, **kwargs):
            if "now" in kwargs:
                kwargs["now"] = self._current_time
            else:
                args = (*args[:-1], self._current_time)
            return value(*args, **kwargs)
        return current_call

    def fork(self):
        return CurrentTimeSandbox(self._system.fork(), self._current_time)


class CurrentTimeKeeper:
    def __init__(self, keeper, now):
        self.keeper = keeper
        self.now = now

    def run(self, system, requested_time):
        return self.keeper.run(system, self.now)
