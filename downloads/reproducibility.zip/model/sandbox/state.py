"""Custody, conservation and funded settlement around source-based FXSwap.

Strategies cannot create wallet balances. Every committed pool operation is
journaled for optional differential execution against pinned actual bytecode.
"""
from __future__ import annotations

from copy import deepcopy, copy
from dataclasses import dataclass
import math

from model.fxswap import FXParams, FXPool
from model.fxswap_backtest import _lp_deposit


class Rejected(ValueError):pass


@dataclass
class Wallet:
    quote: float=0
    stable: float=0
    eth: float=0
    lp: float=0


@dataclass
class Vault:
    owner: str
    kind: str
    collateral: float
    debt: float
    opened: int
    pending_since: int|None=None
    initial_quote: float=0.
    initial_stable: float=0.
    initial_eth: float=0.


class JournalPool(FXPool):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.journal=[]

    def swap(self,i,dx,timestamp):
        out=super().swap(i,dx,timestamp)
        self.journal.append(('swap',(i,dx,timestamp),out));return out

    def add_liquidity(self,q,s,timestamp,donation=False):
        out=super().add_liquidity(q,s,timestamp,donation)
        self.journal.append(('add_liquidity',(q,s,timestamp,donation),out));return out

    def withdraw(self,shares,timestamp):
        out=super().withdraw(shares,timestamp)
        self.journal.append(('withdraw',(shares,timestamp),out));return out


class Sandbox:
    GAS={'swap':150000,'open_bundle':600000,'close':350000,'liquidate':450000,
         'rotate':280000,'deposit':180000,'withdraw':130000,'refuel':200000}
    CORE=('pool','wallets','vaults','bootstrap_debt','bad_debt','gas_eth','gas_quote_mark',
          'fee_quote','insurance_quote','venue_quote','venue_eth','initial_quote','initial_eth',
          'minted_lp_debt','minted_eth_debt','refuel_quote','next_vault','counters')

    @classmethod
    def seeded(cls,seed,reserve,eth_price,timestamp,params=FXParams(),gas_gwei=1):
        if seed<=0 or reserve<0 or eth_price<=0:raise ValueError('Invalid funding')
        self=cls();self.seed=seed;self.reserve=reserve;self.gas_gwei=gas_gwei
        self.pool=JournalPool.seeded(seed,timestamp,params)
        self.pool.journal.clear()
        gas_cash=min(200,reserve*.1)
        self.wallets={'keeper':Wallet(reserve-gas_cash,0,gas_cash/eth_price,self.pool.user_supply)}
        self.vaults={};self.next_vault=0;self.bootstrap_debt=seed;self.bad_debt=0.
        self.reference=1.;self.eth_price=eth_price;self.fx_time=timestamp;self.eth_time=timestamp
        self.market_reference=1.;self.market_eth=eth_price;self.market_time=timestamp
        self.sequence=0;self.now=timestamp;self.max_fx_age=300;self.max_eth_age=3700
        self.lp_threshold=.95;self.eth_threshold=.85;self.bonus=.01;self.max_vaults=128
        self.origination_band=.03
        self.gas_eth=0.;self.gas_quote_mark=0.;self.fee_quote=0.;self.insurance_quote=0.
        self.minted_lp_debt=0.;self.minted_eth_debt=0.;self.refuel_quote=0.
        self.venue_quote=100*seed;self.venue_eth=100*seed/eth_price
        self.initial_quote=seed+reserve-gas_cash+self.venue_quote
        self.initial_eth=gas_cash/eth_price+self.venue_eth
        self.events=[];self.counters={};self.audit=None
        self.assert_invariants();return self

    def add_actor(self,name,quote=0,eth=0):
        if name in self.wallets or min(quote,eth)<0:raise ValueError('Invalid actor')
        self.wallets[name]=Wallet(quote=quote,eth=eth)
        self.initial_quote+=quote;self.initial_eth+=eth

    def report(self,reference,eth_price,observed_at,now,sequence,authorized=True,eth_timestamp=None):
        eth_timestamp=observed_at if eth_timestamp is None else eth_timestamp
        if not authorized or min(reference,eth_price)<=0 or not all(map(math.isfinite,(reference,eth_price))):
            raise Rejected('unauthenticated/invalid mock report')
        if observed_at>now or eth_timestamp>now or sequence<=self.sequence or now<self.now:
            raise Rejected('future/replayed report')
        self.reference=reference;self.eth_price=eth_price;self.fx_time=observed_at
        self.eth_time=eth_timestamp;self.sequence=sequence;self.now=now

    def observe_market(self,reference,eth_price,now):
        if min(reference,eth_price)<=0 or not all(map(math.isfinite,(reference,eth_price))) or now<self.market_time:
            raise Rejected('invalid market observation')
        self.market_reference=reference;self.market_eth=eth_price;self.market_time=now

    def fresh(self,now):
        if self.sequence<=0 or now-self.fx_time>self.max_fx_age or now-self.eth_time>self.max_eth_age:
            raise Rejected('stale report')

    def _snapshot(self):return deepcopy(tuple(getattr(self,k) for k in self.CORE))

    def _restore(self,snapshot):
        for k,value in zip(self.CORE,snapshot):setattr(self,k,value)

    def fork(self):
        out=copy(self);out._restore(self._snapshot());out.events=[];out.audit=None
        return out

    def _gas(self,payer,operation):
        cost=self.GAS[operation]*self.gas_gwei*1e-9
        w=self.wallets[payer]
        if w.eth+1e-12<cost:raise Rejected('gas wallet exhausted')
        w.eth-=cost;self.gas_eth+=cost;self.gas_quote_mark+=cost*self.market_eth

    def _act(self,operation,actor,now,*args):
        if now<self.now:raise Rejected('action time predates current observation')
        self.now=now;self._gas(actor,operation)
        snapshot=self._snapshot()
        try:
            result=getattr(self,'_'+operation)(actor,now,*args)
            self.assert_invariants()
            if self.audit is not None:self.audit.execute(self.pool.journal,self.pool)
            self.pool.journal.clear()
        except (Rejected,ValueError,ArithmeticError,AssertionError) as exc:
            self._restore(snapshot)
            if isinstance(exc,AssertionError):raise
            self.counters['reverts']=self.counters.get('reverts',0)+1
            self.events.append(dict(t=now,actor=actor,op=operation,rejected=str(exc)))
            raise Rejected(str(exc)) from exc
        self.counters[operation]=self.counters.get(operation,0)+1
        self.events.append(dict(t=now,actor=actor,op=operation,result=result,
                                spot=self.pool.spot_price(),market_reference=self.market_reference,report_at=self.fx_time))
        return result

    def swap(self,actor,i,amount,now):return self._act('swap',actor,now,i,amount)
    def deposit(self,actor,q,s,now):return self._act('deposit',actor,now,q,s)
    def withdraw(self,actor,shares,now):return self._act('withdraw',actor,now,shares)
    def rotate(self,actor,shares,sell_coin,now):return self._act('rotate',actor,now,shares,sell_coin)
    def refuel(self,actor,q,now):return self._act('refuel',actor,now,q)
    def open_bundle(self,lp_actor,eth_actor,debt,now):return self._act('open_bundle',lp_actor,now,eth_actor,debt)
    def close(self,actor,vault,now):return self._act('close',actor,now,vault)
    def liquidate(self,actor,vault,now):return self._act('liquidate',actor,now,vault)

    @staticmethod
    def _positive(value):
        if not math.isfinite(value) or value<=0:raise Rejected('positive finite amount required')

    @staticmethod
    def _spend(w,asset,amount):
        if amount<0 or getattr(w,asset)+1e-8<amount:raise Rejected(f'insufficient {asset}')
        setattr(w,asset,getattr(w,asset)-amount)

    def _swap(self,actor,now,i,amount):
        self._positive(amount)
        if i not in (0,1):raise Rejected('coin index')
        w=self.wallets[actor];a,b=('quote','stable') if i==0 else ('stable','quote')
        self._spend(w,a,amount);out=self.pool.swap(i,amount,now)
        setattr(w,b,getattr(w,b)+out);return out

    def _deposit(self,actor,now,q,s):
        if q<0 or s<0 or q+s<=0:raise Rejected('deposit amount')
        w=self.wallets[actor];self._spend(w,'quote',q);self._spend(w,'stable',s)
        shares=self.pool.add_liquidity(q,s,now);w.lp+=shares;return shares

    def _withdraw(self,actor,now,shares):
        self._positive(shares);w=self.wallets[actor];self._spend(w,'lp',shares)
        shares=self._lp_rounding(self.pool,shares)
        q,s=self.pool.withdraw(shares,now);w.quote+=q;w.stable+=s
        return dict(quote=q,stable=s)

    def _rotate(self,actor,now,shares,sell_coin):
        if actor!='keeper':raise Rejected('only treasury-owned LP management')
        out=self._withdraw(actor,now,shares)
        amount=out['quote'] if sell_coin==0 else out['stable']
        received=self._swap(actor,now,sell_coin,amount)
        return dict(shares=shares,sell_coin=sell_coin,received=received)

    def _refuel(self,actor,now,q):
        self._positive(q);self._spend(self.wallets[actor],'quote',q)
        shares=self.pool.add_liquidity(q,0,now,donation=True);self.refuel_quote+=q
        return dict(spent=q,unowned_shares=shares)

    def debt(self,kind=None):return sum(v.debt for v in self.vaults.values() if kind is None or v.kind==kind)
    def token_liabilities(self):return self.bootstrap_debt+self.debt()+self.bad_debt

    @staticmethod
    def _lp_rounding(pool,shares):
        # Bound independent wallet/supply additions to eight IEEE-754 ulps.
        # This is bookkeeping only: never mint shares or relax source checks.
        if shares>pool.user_supply and shares-pool.user_supply<=8*math.ulp(pool.user_supply):return pool.user_supply
        return shares

    def recoverable(self,shares,pool=None):
        pool=self.pool if pool is None else pool
        return pool.recoverable(self._lp_rounding(pool,shares))

    def vault_nav(self,v):
        if v.kind=='eth':return v.collateral*self.eth_price
        q,s=self.recoverable(v.collateral)
        return q+s*self.reference

    def vault_ltv(self,index):
        v=self.vaults[index]
        return v.debt*self.reference/self.vault_nav(v) if v.debt>1e-8 else 0.

    def unhealthy(self):
        return [i for i,v in self.vaults.items() if v.debt>1e-8 and
                self.vault_ltv(i)>=(self.lp_threshold if v.kind=='lp' else self.eth_threshold)]

    def pending_count(self):
        return sum(v.debt>1e-8 and v.pending_since is not None for v in self.vaults.values())

    def mark_liquidations(self,now):
        self.fresh(now)
        unhealthy=set(self.unhealthy())
        for i,v in self.vaults.items():
            if i not in unhealthy:v.pending_since=None
        for i in unhealthy:
            if self.vaults[i].pending_since is None:self.vaults[i].pending_since=now
        return self.pending_count()

    def _open_bundle(self,lp_actor,now,eth_actor,debt):
        self.fresh(now);self._positive(debt)
        if self.pending_count() or self.unhealthy():raise Rejected('pending liquidation must settle first')
        if sum(v.debt>1e-8 for v in self.vaults.values())+2>self.max_vaults:raise Rejected('vault ceiling')
        if self.debt()>1e-8 and self.debt('eth')/self.debt()>.04+1e-8:raise Rejected('ETH mix guard')
        initial_ltv={i:self.vault_ltv(i) for i in self.vaults if self.vaults[i].debt>1e-8}
        lp_debt=.96*debt;eth_debt=.04*debt;target=lp_debt*self.reference/.874
        deposit=target
        for _ in range(8):
            trial=self.pool.clone()
            shares,value,cash=_lp_deposit(trial,deposit,self.reference,now)
            if abs(value-target)<=max(target*1e-9,sum(self.pool.balances)*2e-14):break
            deposit*=target/value
        else:raise Rejected('LP receipt solve')
        self._spend(self.wallets[lp_actor],'quote',cash)
        ether=eth_debt*self.reference/.75/self.eth_price
        self._spend(self.wallets[eth_actor],'eth',ether)
        self.pool=trial
        self.wallets[lp_actor].quote+=self.pool.swap(1,lp_debt,now)
        self.wallets[eth_actor].quote+=self.pool.swap(1,eth_debt,now)
        lp_id=self.next_vault;eth_id=lp_id+1;self.next_vault+=2
        initial_q,initial_s=self.pool.recoverable(shares)
        self.vaults[lp_id]=Vault(lp_actor,'lp',shares,lp_debt,now,initial_quote=initial_q,initial_stable=initial_s)
        self.vaults[eth_id]=Vault(eth_actor,'eth',ether,eth_debt,now,initial_eth=ether)
        self.minted_lp_debt+=lp_debt;self.minted_eth_debt+=eth_debt
        if self.vault_ltv(lp_id)>self.lp_threshold:raise Rejected('post-sale LP health')
        for i,old in initial_ltv.items():
            limit=self.lp_threshold if self.vaults[i].kind=='lp' else self.eth_threshold
            if old<limit and self.vault_ltv(i)>=limit:raise Rejected('new loan damages existing health')
        if self.origination_band is not None and abs(self.pool.spot_price()/self.reference-1)>self.origination_band:
            raise Rejected('origination peg guard')
        return lp_id,eth_id

    def quote_to_buy(self,stable):
        if stable<=0:return 0.
        if stable>=self.pool.balances[1]*(1-1e-10):raise Rejected('insufficient pool own tokens')
        left=0.;right=max(stable*self.pool.spot_price()*2,1)
        for _ in range(60):
            if self.pool.quote(0,right)>=stable:break
            right*=2
        else:raise Rejected('buy has no finite quote')
        for _ in range(44):
            m=(left+right)/2
            if self.pool.quote(0,m)<stable:left=m
            else:right=m
        return right*(1+1e-11)

    def _unwind(self,actor,now,index,liquidation):
        if index not in self.vaults:raise Rejected('vault absent')
        v=self.vaults[index]
        if v.debt<=1e-8:raise Rejected('vault closed')
        if liquidation:
            self.fresh(now)
            limit=self.lp_threshold if v.kind=='lp' else self.eth_threshold
            if self.vault_ltv(index)<limit:raise Rejected('healthy vault')
        elif actor!=v.owner:raise Rejected('not vault owner')
        old_debt=v.debt;owner=self.wallets[v.owner]
        if v.kind=='lp':q,s=self.pool.withdraw(v.collateral,now)
        else:
            # Explicit finite mock ETH/quote venue, with 5bp execution cost.
            gross=v.collateral*self.market_eth;q=gross*(1-.0005);s=0.
            if self.venue_quote+1e-8<gross:raise Rejected('ETH venue quote exhausted')
            self.venue_quote-=gross;self.venue_eth+=v.collateral;self.fee_quote+=gross-q
        collateral_out_q=q;collateral_out_s=s
        passive_lp_difference=(q+s*self.market_reference-v.initial_quote-v.initial_stable*self.market_reference) if v.kind=='lp' else 0.
        v.collateral=0.
        canceled=min(s,v.debt);s-=canceled;v.debt-=canceled;self_netted=canceled
        # Controlled owner tokens can repay without an FX oracle.
        if not liquidation:
            canceled=min(owner.stable,v.debt);owner.stable-=canceled;v.debt-=canceled
        backstop=0.
        if v.debt>1e-8:
            needed=self.quote_to_buy(v.debt*(1+1e-10))
            if liquidation and needed>v.debt*self.reference*1.031:raise Rejected('liquidation execution outside 3% cap')
            if needed>q:
                payer=self.wallets['keeper'] if liquidation else owner
                backstop=min(needed-q,payer.quote)
                payer.quote-=backstop;q+=backstop
                if liquidation:self.insurance_quote+=backstop
            if not liquidation and q+1e-7<needed:raise Rejected('owner must fund remaining debt')
            spend=min(q,needed)
            got=self.pool.swap(0,spend,now) if spend>1e-10 else 0.
            q-=spend;canceled=min(got,v.debt);v.debt-=canceled;s+=got-canceled
        loss=v.debt
        if not liquidation and loss>1e-7:raise Rejected('repayment incomplete')
        self.bad_debt+=loss;v.debt=0.;v.pending_since=None
        bonus=min(q,old_debt*self.reference*self.bonus) if liquidation and backstop<=1e-8 else 0.
        self.wallets[actor].quote+=bonus;owner.quote+=q-bonus;owner.stable+=s
        return dict(debt_closed=old_debt,own_tokens_netted=self_netted,tokens_burned=old_debt-loss,
                    backstop_quote=backstop,bad_debt=loss,borrower_surplus_quote=q-bonus,bonus=bonus,
                    collateral_out_quote=collateral_out_q,collateral_out_stable=collateral_out_s,
                    passive_lp_difference_vs_holding=passive_lp_difference)

    def _close(self,actor,now,index):return self._unwind(actor,now,index,False)
    def _liquidate(self,actor,now,index):return self._unwind(actor,now,index,True)

    def active_shortfall(self,reference=None,eth_price=None):
        reference=self.reference if reference is None else reference
        eth_price=self.eth_price if eth_price is None else eth_price
        loss=0.
        for v in self.vaults.values():
            if v.debt<=0:continue
            if v.kind=='lp':q,s=self.recoverable(v.collateral);nav=q+s*reference
            else:nav=v.collateral*eth_price
            loss+=max(0,v.debt*reference-nav)
        return loss

    def protocol_equity(self,reference=None,eth_price=None):
        reference=self.reference if reference is None else reference
        eth_price=self.eth_price if eth_price is None else eth_price
        w=self.wallets['keeper'];q,s=self.recoverable(w.lp)
        return (w.quote+q+(w.stable+s-self.bootstrap_debt-self.bad_debt)*reference+w.eth*eth_price
                -self.active_shortfall(reference,eth_price))

    def actor_equity(self,name,reference=None,eth_price=None):
        reference=self.reference if reference is None else reference
        eth_price=self.eth_price if eth_price is None else eth_price
        w=self.wallets[name];q,s=self.recoverable(w.lp)
        value=w.quote+q+(w.stable+s)*reference+w.eth*eth_price
        for v in self.vaults.values():
            if v.owner!=name or v.debt<=0:continue
            if v.kind=='lp':q,s=self.recoverable(v.collateral);value+=q+s*reference
            else:value+=v.collateral*eth_price
            value-=v.debt*reference
        return value

    def assert_invariants(self):
        tol=max(1e-6,self.seed*1e-9)
        for name,w in self.wallets.items():
            for field in ('quote','stable','eth','lp'):
                value=getattr(w,field)
                if not math.isfinite(value) or value < -tol:raise AssertionError((name,field,value))
        for i,v in self.vaults.items():
            if min(v.collateral,v.debt)<-tol:raise AssertionError(('vault',i))
        admin=[self.pool.admin_tokens_paid[i]+self.pool.leftover_donations_to_admin[i] for i in (0,1)]
        stable=self.pool.balances[1]+sum(w.stable for w in self.wallets.values())+admin[1]
        if abs(stable-self.token_liabilities())>tol:raise AssertionError(('own supply',stable,self.token_liabilities()))
        lp=sum(w.lp for w in self.wallets.values())+sum(v.collateral for v in self.vaults.values() if v.kind=='lp')
        if abs(lp-self.pool.user_supply)>tol:raise AssertionError(('LP custody',lp,self.pool.user_supply))
        quote=self.pool.balances[0]+sum(w.quote for w in self.wallets.values())+self.venue_quote+self.fee_quote+admin[0]
        if abs(quote-self.initial_quote)>tol:raise AssertionError(('quote conservation',quote,self.initial_quote))
        eth=sum(w.eth for w in self.wallets.values())+sum(v.collateral for v in self.vaults.values() if v.kind=='eth')+self.venue_eth+self.gas_eth
        if abs(eth-self.initial_eth)>max(1e-8,tol/self.eth_price):raise AssertionError(('ETH conservation',eth,self.initial_eth))
