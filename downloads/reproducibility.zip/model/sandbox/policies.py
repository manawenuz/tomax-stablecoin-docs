"""Finite treasury controller. Planning sees reported prices, never future bars.

This policy is a research mock, not an audited onchain peg guarantee. All
actions go through the custody ledger; candidate searches cannot spend money.
"""
from dataclasses import dataclass, fields

from .state import Rejected


@dataclass(frozen=True)
class KeeperConfig:
    mode: str='inventory'
    target: float=.01
    trigger: float=.015
    max_steps: int=4
    min_pool_value_multiple: float=.25
    preflight_liquidations: bool=True


class Keeper:
    def __init__(self,config=None):
        self.config=config if isinstance(config,KeeperConfig) else KeeperConfig(**(config or {}))
        if self.config.mode not in ('inventory','issuance'):raise ValueError('keeper mode')
        if not 0<=self.config.target<self.config.trigger<.03:raise ValueError('keeper bands')

    @staticmethod
    def _preview(s,method,args,now):
        pool=s.pool.clone();w=s.wallets['keeper'];q=w.quote;stable=w.stable;lp=w.lp
        if method=='rotate':
            amount,i=args;a,b=pool.withdraw(amount,now);lp-=amount;q+=a;stable+=b
            if i==0:q-=a;stable+=pool.swap(0,a,now)
            else:stable-=b;q+=pool.swap(1,b,now)
        elif method=='swap':
            i,amount=args;out=pool.swap(i,amount,now)
            if i==0:q-=amount;stable+=out
            else:stable-=amount;q+=out
        elif method=='deposit':
            a,b=args;lp+=pool.add_liquidity(a,b,now);q-=a;stable-=b
        a,b=s.recoverable(lp,pool)
        equity=q+a+(stable+b)*s.reference
        return pool.spot_price()/s.reference-1,equity,pool.balances[0]+pool.balances[1]*s.reference

    def plan(self,s,now):
        c=self.config;error=s.pool.spot_price()/s.reference-1
        if abs(error)<=c.trigger:return None
        down=error>0;w=s.wallets['keeper'];options=[]
        # Selling quote raises price; selling own token lowers it. Normal LP
        # additions retain a user claim, unlike an unowned Curve refuel.
        inventory=w.stable if down else w.quote
        if inventory>s.seed*1e-9:
            options += [('swap',inventory,lambda x:(1 if down else 0,x)),
                        ('deposit',inventory,lambda x:(0,x) if down else (x,0))]
        if w.lp>s.seed*1e-9:
            options.append(('rotate',min(w.lp*.999,s.pool.user_supply*.9),lambda x:(x,1 if down else 0)))
        candidates=[];goal=c.target if down else -c.target
        for method,cap,args in options:
            # Sample before bisection: a recenter can make a large operation
            # nonmonotonic. A failed or depleted candidate is never committed.
            left=0.;best=None
            for f in (.0625,.125,.25,.5,.75,1):
                right=cap*f
                try:r=self._preview(s,method,args(right),now)
                except (ValueError,ArithmeticError):continue
                if r[2]<s.seed*c.min_pool_value_multiple:break
                if best is None or abs(r[0])<abs(best[1][0]):best=(right,r)
                crossed=r[0]<=goal if down else r[0]>=goal
                if crossed:
                    for _ in range(25):
                        m=(left+right)/2
                        try:z=self._preview(s,method,args(m),now)
                        except (ValueError,ArithmeticError):right=m;continue
                        if (z[0]<=goal if down else z[0]>=goal):right=m;r=z
                        else:left=m
                    best=(right,r);break
                left=right
            if best and abs(best[1][0])<abs(error)-1e-7:
                amount,(e,equity,nav)=best
                # First restore the inner band; then minimize marked treasury
                # loss among feasible routes. Finite resources remain visible.
                equity-=s.GAS[method]*s.gas_gwei*1e-9*s.eth_price
                score=(max(0,abs(e)-c.target-1e-7),-equity)
                candidates.append((score,method,args(amount)))
        if not candidates:return None
        _,method,args=min(candidates,key=lambda x:x[0])
        return method,args

    def _issuance(self,s,now):
        if s.pool.spot_price()/s.reference<=1.025:return None
        day=now//86400;key=f'issuance_day_{day}'
        used=s.counters.get(key,0);amount=min(s.seed*.5,max(0,2*s.seed-used),
                                             max(0,100*s.seed-s.minted_lp_debt-s.minted_eth_debt))
        if amount<=0:return None
        s.open_bundle('lp','eth',amount,now);s.counters[key]=used+amount
        return ('open_bundle',amount)

    def run(self,s,now):
        actions=[];errors=[]
        try:s.fresh(now)
        except Rejected:return dict(status='stale',actions=[],errors=['stale report'])
        for _ in range(self.config.max_steps):
            try:
                if self.config.mode=='issuance':
                    action=self._issuance(s,now)
                    if action:actions.append(action);continue
                else:
                    action=self.plan(s,now)
                    if action:
                        method,args=action;getattr(s,method)('keeper',*args,now)
                        actions.append((method,args));continue
                break
            except Rejected as exc:errors.append(str(exc));break
        s.mark_liquidations(now)
        for i in list(s.unhealthy())[:2]:
            try:
                if self.config.preflight_liquidations:s.fork().liquidate('keeper',i,now)
                s.liquidate('keeper',i,now);actions.append(('liquidate',i))
            except Rejected as exc:errors.append(str(exc))
        # A funded liquidation can move reserves; repair its resulting price.
        if self.config.mode=='inventory' and actions:
            action=self.plan(s,now)
            if action:
                method,args=action
                try:getattr(s,method)('keeper',*args,now);actions.append((method,args))
                except Rejected as exc:errors.append(str(exc))
        error=s.pool.spot_price()/s.reference-1
        return dict(status='within_band' if abs(error)<=.03 else 'outside_band',
                    actions=actions,errors=errors,reported_error=error)
