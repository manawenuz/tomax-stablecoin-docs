"""LP-debt issuance and explicitly assumed arbitrage against historical FX.

Coin 0 is USDT-equivalent quote, coin 1 is a normalized local-currency token
worth one quote unit at launch. Historic IRR per USDT q gives parity q0/q.
This is a conditional research replay, not observed Tomax trading volume.
"""
from __future__ import annotations

import bisect
import csv
import datetime as dt
import json
import math
from copy import deepcopy
from dataclasses import dataclass, field
from pathlib import Path
from zoneinfo import ZoneInfo

from model.fxswap import FXParams, FXPool

ROOT=Path(__file__).resolve().parents[1]
ZONE=ZoneInfo('Asia/Tbilisi')
LP_SHARE=.96
LP_LTV=.874
ETH_LTV=.75


@dataclass
class Book:
    pool: FXPool
    external_seed: float
    treasury_shares: float
    bootstrap_tokens: float
    lp_debt: float=0
    eth_debt: float=0
    lp_shares: float=0
    eth_collateral: float=0
    refuel_spent: float=0
    refuel_unspent: float=0
    lp_lots: list=field(default_factory=list)
    eth_lots: list=field(default_factory=list)

    @classmethod
    def seeded(cls,external_seed,timestamp,params=FXParams()):
        pool=FXPool.seeded(external_seed,timestamp,params)
        return cls(pool,external_seed,pool.user_supply,external_seed)

    @property
    def additional_debt(self):return self.lp_debt+self.eth_debt

    @property
    def issued_tokens(self):return self.bootstrap_tokens+self.additional_debt

    @property
    def outside_tokens(self):return self.issued_tokens-self.pool.balances[1]

    def clone(self):return deepcopy(self)

    def mark(self,reference,eth_price):
        tq,ts=self.pool.recoverable(self.treasury_shares)
        lq,ls=self.pool.recoverable(self.lp_shares)
        treasury=tq+ts*reference;lpnav=lq+ls*reference
        lp_shortfall=0;max_ltv=0
        for shares,debt in self.lp_lots:
            q,s=self.pool.recoverable(shares);nav=q+s*reference
            lp_shortfall+=max(0,debt*reference-nav)
            max_ltv=max(max_ltv,debt*reference/nav if nav else math.inf)
        eth_value=self.eth_collateral*eth_price
        eth_shortfall=0;max_eth_ltv=0
        for collateral,debt in self.eth_lots:
            nav=collateral*eth_price
            eth_shortfall+=max(0,debt*reference-nav)
            max_eth_ltv=max(max_eth_ltv,debt*reference/nav if nav else math.inf)
        return dict(treasury_lp_nav=treasury,bootstrap_debt_usdt=self.bootstrap_tokens*reference,
                    treasury_equity_before_refuels=treasury-self.bootstrap_tokens*reference,
                    treasury_equity_after_refuels=treasury-self.bootstrap_tokens*reference-self.refuel_spent,
                    lp_collateral_nav=lpnav,lp_debt_usdt=self.lp_debt*reference,
                    lp_borrower_equity=lpnav-self.lp_debt*reference,
                    max_lp_ltv=max_ltv,lp_gross_credit_shortfall=lp_shortfall,
                    eth_collateral_usdt=eth_value,eth_debt_usdt=self.eth_debt*reference,
                    eth_borrower_equity=eth_value-self.eth_debt*reference,
                    eth_ltv=self.eth_debt*reference/eth_value if eth_value else 0,
                    max_eth_cohort_ltv=max_eth_ltv,eth_gross_credit_shortfall=eth_shortfall,
                    quote_in_lp_collateral=lq,own_tokens_in_lp_collateral=ls)


def _lp_deposit(pool,collateral_value,reference,timestamp):
    """Buy the entire stable leg and deposit at the post-buy reserve ratio."""
    left,right=0.0,collateral_value*2
    def gap(quote_in):
        bought=pool.quote(0,quote_in) if quote_in>0 else 0
        q=pool.balances[0]+quote_in;s=pool.balances[1]-bought
        return bought-collateral_value*s/(q+s*reference)
    while gap(right)<0:right*=2
    for _ in range(38):
        mid=(left+right)/2
        if gap(mid)<0:left=mid
        else:right=mid
    quote_buy=(left+right)/2
    stable=pool.swap(0,quote_buy,timestamp)
    quote_deposit=collateral_value-stable*reference
    shares=pool.add_liquidity(quote_deposit,stable,timestamp)
    q,s=pool.recoverable(shares)
    return shares,q+s*reference,quote_buy+quote_deposit


def mint_cohort(book,debt,reference,timestamp,eth_price,eth_ltv=ETH_LTV):
    if debt<=0 or reference<=0 or eth_price<=0 or not 0<eth_ltv<1:
        raise ValueError('Positive debt, prices and ETH LTV in (0,1) required')
    target=LP_SHARE*debt*reference/LP_LTV
    deposit=target
    # Use the received LP claim's recoverable external-peg mark, not input TVL.
    for _ in range(5):
        trial=book.pool.clone()
        shares,value,cash=_lp_deposit(trial,deposit,reference,timestamp)
        tolerance=max(target*1e-10,sum(book.pool.balances)*2e-14)
        if abs(value-target)<=tolerance:break
        deposit*=target/value
    else:raise ArithmeticError('Receipt collateral solve did not converge')
    lp_debt=LP_SHARE*debt;eth_debt=(1-LP_SHARE)*debt
    lp_proceeds=trial.swap(1,lp_debt,timestamp)
    eth_proceeds=trial.swap(1,eth_debt,timestamp)
    book.pool=trial;book.lp_debt+=lp_debt;book.eth_debt+=eth_debt
    book.lp_shares+=shares;book.lp_lots.append((shares,lp_debt))
    book.eth_collateral+=eth_debt*reference/eth_ltv/eth_price
    book.eth_lots.append((eth_debt*reference/eth_ltv/eth_price,eth_debt))
    return dict(lp_debt=lp_debt,eth_debt=eth_debt,receipt_value=value,
                lp_shares=shares,lp_borrower_cash=cash-lp_proceeds,
                eth_borrower_proceeds=eth_proceeds,
                spot_after=trial.spot_price(),actual_lp_ltv=lp_debt*reference/value)


def issue(book,debt,timestamp,reference=1,eth_price=2000,eth_ltv=ETH_LTV,steps=100):
    cash=0
    step=book.external_seed/steps
    while debt>book.external_seed*1e-10:
        amount=min(step,debt)
        flow=mint_cohort(book,amount,reference,timestamp,eth_price,eth_ltv)
        cash+=flow['lp_borrower_cash'];debt-=amount
    return cash


def static_capacity(seed=10000,floor=.97,steps=100,max_multiple=100,fee_inclusive=False,eth_ltv=ETH_LTV):
    book=Book.seeded(seed,0);step=seed/steps;prior=book.clone();cash=0
    def price(pool):return pool.spot_price()*(1-pool.fee()) if fee_inclusive else pool.spot_price()
    while book.additional_debt<seed*max_multiple:
        prior=book.clone();flow=mint_cohort(book,step,1,0,2000,eth_ltv)
        if price(book.pool)<floor:break
        cash+=flow['lp_borrower_cash']
    else:return dict(finite=False,horizon=book.additional_debt)
    low,high=0,step
    for _ in range(32):
        part=(low+high)/2;trial=prior.clone()
        mint_cohort(trial,part,1,0,2000,eth_ltv)
        if price(trial.pool)>=floor:low=part
        else:high=part
    flow=mint_cohort(prior,low,1,0,2000,eth_ltv);cash+=flow['lp_borrower_cash']
    return dict(finite=True,external_seed=seed,initial_lp_value=2*seed,
                bootstrap_liability=seed,additional_debt=prior.additional_debt,
                all_issued_tokens=prior.issued_tokens,lp_debt=prior.lp_debt,
                eth_debt=prior.eth_debt,lp_collateral=prior.mark(1,2000)['lp_collateral_nav'],
                spot=prior.pool.spot_price(),fee_inclusive_bid=prior.pool.spot_price()*(1-prior.pool.fee()),
                marginal_fee=prior.pool.fee(),lp_borrowers_net_quote_cash=cash,
                eth_opening_ltv=eth_ltv,eth_collateral_value_at_opening_ltv=prior.eth_debt/eth_ltv,
                steps_per_seed=steps,fee_inclusive_boundary=fee_inclusive)


def _maximize(profit,upper,grid=192):
    if upper<=0:return 0.0,0.0
    # Dynamic fees can create several profit peaks. Bracket them first;
    # include geometric points so small trades are not lost in a wide grid.
    xs=sorted({upper*i/grid for i in range(grid+1)} |
              {upper*10**(-8+8*i/64) for i in range(65)})
    ys=[profit(x) if x>0 else 0.0 for x in xs]
    best=max(zip(xs,ys),key=lambda p:p[1])
    ratio=(math.sqrt(5)-1)/2
    for j in range(1,len(xs)-1):
        if ys[j]<ys[j-1] or ys[j]<ys[j+1]:continue
        left,right=xs[j-1],xs[j+1]
        a=right-ratio*(right-left);b=left+ratio*(right-left)
        fa=profit(a);fb=profit(b)
        for _ in range(30):
            if fa<fb:
                left=a;a=b;fa=fb;b=left+ratio*(right-left);fb=profit(b)
            else:
                right=b;b=a;fb=fa;a=right-ratio*(right-left);fa=profit(a)
        dx=(left+right)/2;value=profit(dx)
        if value>best[1]:best=(dx,value)
    return best


def arbitrage(book,reference,timestamp,external_cost=.0005,min_profit=.5,
              finite_inventory=True,max_trades=3):
    result=dict(trades=0,quote_volume=0,net_quote_to_pool=0,profit_before_fixed_cost=0,
                inventory_limited=False,unbacked_external_tokens_required=0)
    pool=book.pool
    for _ in range(max_trades):
        nav=pool.balances[0]+pool.balances[1]*reference
        # Same-token sales are limited by actual issued tokens outside the pool.
        outside=max(0,book.outside_tokens)
        sale_cap=outside if finite_inventory else 3*nav/reference
        bid=pool.spot_price()*(1-pool.fee())
        if finite_inventory and outside<book.external_seed*1e-10 and bid>reference*(1+external_cost):
            result['inventory_limited']=True
        candidates=[]
        for i,upper in ((0,3*nav),(1,sale_cap)):
            if upper<=book.external_seed*1e-11:continue
            def profit(dx):
                out=pool.quote(i,dx)
                return out*reference*(1-external_cost)-dx if i==0 else out-dx*reference*(1+external_cost)
            dx,value=_maximize(profit,upper)
            candidates.append((value,i,dx))
        if not candidates:break
        value,i,dx=max(candidates)
        if value<=min_profit:break
        if i==1 and finite_inventory and dx>=outside*(1-1e-7):result['inventory_limited']=True
        out=pool.swap(i,dx,timestamp)
        quote=dx if i==0 else out
        result['trades']+=1;result['quote_volume']+=quote
        result['net_quote_to_pool']+=quote if i==0 else -quote
        result['profit_before_fixed_cost']+=value
        result['unbacked_external_tokens_required']=max(result['unbacked_external_tokens_required'],
                                                        max(0,-book.outside_tokens))
    if finite_inventory and book.outside_tokens < -max(1e-6,book.issued_tokens*1e-10):
        raise ArithmeticError('Arbitrage sold more own tokens than exist outside pool')
    return result


def add_refuel(book,amount,timestamp):
    if amount<=0:return 0.0
    trial=book.pool.clone()
    try:trial.add_liquidity(amount,0,timestamp,donation=True)
    except ValueError as exc:
        if 'donation above cap' not in str(exc):raise
        left,right=0.0,amount
        for _ in range(30):
            mid=(left+right)/2;candidate=book.pool.clone()
            try:candidate.add_liquidity(mid,0,timestamp,donation=True);left=mid
            except ValueError:right=mid
        amount=left
        if amount<book.external_seed*1e-9:return 0.0
        trial=book.pool.clone();trial.add_liquidity(amount,0,timestamp,donation=True)
    book.pool=trial;book.refuel_spent+=amount
    return amount


def expand_above_peg(book,reference,timestamp,eth_price,eth_ltv,available,
                     trigger=1.025,target=1.01):
    """Conditional NEW external borrowers; not free or unbacked stabilizer minting."""
    out=dict(debt=0.,lp_net_quote_cash=0.,eth_collateral_posted_usdt=0.,
             lp_entry_equity=0.,lp_hodl_quote=0.,lp_hodl_stable=0.)
    if available<=0 or book.pool.spot_price()<=reference*trigger:return out
    step=book.external_seed*.05
    while available>book.external_seed*1e-9 and book.pool.spot_price()>reference*target:
        amount=min(step,available);trial=book.clone()
        flow=mint_cohort(trial,amount,reference,timestamp,eth_price,eth_ltv)
        if trial.pool.spot_price()<reference*target:
            left,right=0.,amount
            for _ in range(26):
                middle=(left+right)/2;candidate=book.clone()
                mint_cohort(candidate,middle,reference,timestamp,eth_price,eth_ltv)
                if candidate.pool.spot_price()>reference*target:left=middle
                else:right=middle
            amount=(left+right)/2;trial=book.clone()
            flow=mint_cohort(trial,amount,reference,timestamp,eth_price,eth_ltv)
        q,s=trial.pool.recoverable(flow['lp_shares'])
        out['debt']+=amount;out['lp_net_quote_cash']+=flow['lp_borrower_cash']
        out['eth_collateral_posted_usdt']+=flow['eth_debt']*reference/eth_ltv
        out['lp_entry_equity']+=q+s*reference-flow['lp_debt']*reference
        out['lp_hodl_quote']+=q;out['lp_hodl_stable']+=s
        book.__dict__.update(trial.__dict__);available-=amount
    return out


def load_csv(path):
    with Path(path).open() as handle:
        return [{k:int(v) if k in ('timestamp','candle_end_timestamp') else
                 float(v) if k in ('open','high','low','close','volume_usdt') else v
                 for k,v in row.items()} for row in csv.DictReader(handle)]


def eth_history():
    rows=load_csv(ROOT/'research/fxswap_data/ETH_USDT_1h.csv')
    return [(rows[0]['timestamp'],rows[0]['open'])]+[(r['candle_end_timestamp'],r['close']) for r in rows]


def replay(candles,external_seed,additional_debt,daily_refuel,eth_marks,
           eth_ltv=ETH_LTV,external_cost=.0005,min_profit=.5,finite_inventory=True,
           path='close',record=True,params=FXParams(),daily_new_debt_cap=0,
           total_new_debt_cap=None):
    if not candles:raise ValueError('Empty replay')
    start=candles[0]['timestamp'];q0=candles[0]['open']
    eth_times=[x[0] for x in eth_marks]
    def eth_at(t):return eth_marks[max(0,bisect.bisect_right(eth_times,t)-1)][1]
    book=Book.seeded(external_seed,start,params)
    issue(book,additional_debt,start,eth_price=eth_at(start),eth_ltv=eth_ltv)
    initial=book.mark(1,eth_at(start));initial_tq,initial_ts=book.pool.recoverable(book.treasury_shares)
    initial_lp_q,initial_lp_s=book.pool.recoverable(book.lp_shares)
    initial_pool_nav=sum(book.pool.balances)
    daily={};series=[];previous=start;max_token_deficit=0;max_ltv=0;max_credit=0
    max_eth_ltv=0;max_lp_credit=max_eth_credit=0
    max_spot=max_center=0;pre_max_spot=0;bad_spot=bad_center=points=0
    total_arb=total_volume=total_arb_profit=0;inventory_limited_points=0
    refuel_day=None;previous_fee=list(book.pool.fees_paid);gross_fee_mark=0.0
    issuance_fee_mark=sum(previous_fee);refuel_eth=0
    bootstrap_outside=None;previous_reference=1.0;previous_mark=initial
    controller_debt=controller_cash=controller_eth=controller_equity=0.
    if total_new_debt_cap is None:total_new_debt_cap=external_seed*100
    for row in candles:
        interval=row.get('candle_end_timestamp',row['timestamp']+3600)-row['timestamp']
        if path=='close':events=[(row['timestamp']+interval,row['close'])]
        elif path in ('ohlc','olhc'):
            prices=[row['open'],row['high'],row['low'],row['close']] if path=='ohlc' else [row['open'],row['low'],row['high'],row['close']]
            events=[(row['timestamp']+max(1,interval*(i+1)//4),p) for i,p in enumerate(prices)]
        else:raise ValueError('Unknown within-candle assumption')
        for timestamp,q in events:
            reference=q0/q
            day=dt.datetime.fromtimestamp(timestamp-1,ZONE).date().isoformat()
            stats=daily.setdefault(day,dict(refuel_spent=0.0,arbitrage_trades=0,quote_volume=0.0,
                                           max_spot_error=0.0,max_center_error=0.0,observations=0,
                                           spot_breaches=0,center_breaches=0))
            if refuel_day!=day:
                tq,ts=book.pool.recoverable(book.treasury_shares)
                stats.update(start_reference=previous_reference,start_treasury_quote=tq,
                             start_treasury_stable=ts,
                             start_treasury_lp_nav=previous_mark['treasury_lp_nav'],
                             start_treasury_equity=previous_mark['treasury_equity_after_refuels'],
                             start_lp_borrower_equity=previous_mark['lp_borrower_equity'],
                             controller_added_debt=0.,controller_lp_entry_equity=0.)
                spent=add_refuel(book,daily_refuel,timestamp)
                refuel_eth+=spent/eth_at(timestamp);stats['refuel_eth_equivalent']=spent/eth_at(timestamp)
                book.refuel_unspent+=daily_refuel-spent;stats['refuel_spent']+=spent;refuel_day=day
            pre_error=abs(book.pool.spot_price()/reference-1);pre_max_spot=max(pre_max_spot,pre_error)
            arb=arbitrage(book,reference,timestamp,external_cost,min_profit,finite_inventory)
            if daily_new_debt_cap>0:
                growth=expand_above_peg(book,reference,timestamp,eth_at(timestamp),eth_ltv,
                    min(daily_new_debt_cap-stats['controller_added_debt'],total_new_debt_cap-controller_debt))
                controller_debt+=growth['debt'];controller_cash+=growth['lp_net_quote_cash']
                controller_eth+=growth['eth_collateral_posted_usdt'];controller_equity+=growth['lp_entry_equity']
                initial_lp_q+=growth['lp_hodl_quote'];initial_lp_s+=growth['lp_hodl_stable']
                stats['controller_added_debt']+=growth['debt']
                stats['controller_lp_entry_equity']+=growth['lp_entry_equity']
            if bootstrap_outside is None:bootstrap_outside=book.outside_tokens
            stats['arbitrage_trades']+=arb['trades'];stats['quote_volume']+=arb['quote_volume']
            total_arb+=arb['trades'];total_volume+=arb['quote_volume'];total_arb_profit+=arb['profit_before_fixed_cost']
            inventory_limited_points+=int(arb['inventory_limited'])
            max_token_deficit=max(max_token_deficit,arb['unbacked_external_tokens_required'])
            spot_error=abs(book.pool.spot_price()/reference-1);center_error=abs(book.pool.price_scale/reference-1)
            max_spot=max(max_spot,spot_error);max_center=max(max_center,center_error)
            bad_spot+=int(spot_error>.03);bad_center+=int(center_error>.03);points+=1
            stats['max_spot_error']=max(stats['max_spot_error'],spot_error)
            stats['max_center_error']=max(stats['max_center_error'],center_error)
            stats['observations']+=1;stats['spot_breaches']+=int(spot_error>.03);stats['center_breaches']+=int(center_error>.03)
            mark=book.mark(reference,eth_at(timestamp))
            max_ltv=max(max_ltv,mark['max_lp_ltv'])
            max_eth_ltv=max(max_eth_ltv,mark['max_eth_cohort_ltv'])
            max_lp_credit=max(max_lp_credit,mark['lp_gross_credit_shortfall'])
            max_eth_credit=max(max_eth_credit,mark['eth_gross_credit_shortfall'])
            max_credit=max(max_credit,mark['lp_gross_credit_shortfall']+mark['eth_gross_credit_shortfall'])
            day_hodl=stats['start_treasury_quote']+stats['start_treasury_stable']*reference
            stats.update(end_reference=reference,seed_lp_final_nav=mark['treasury_lp_nav'],
                         seed_lp_pnl=mark['treasury_lp_nav']-stats['start_treasury_lp_nav'],
                         seed_lp_vs_hodl=mark['treasury_lp_nav']-day_hodl,
                         seed_lp_vs_hodl_pct=100*(mark['treasury_lp_nav']/day_hodl-1),
                         treasury_equity_pnl_after_refuels=mark['treasury_equity_after_refuels']-stats['start_treasury_equity'],
                         lp_borrower_equity_pnl=mark['lp_borrower_equity']-stats['start_lp_borrower_equity']-stats['controller_lp_entry_equity'],
                         max_lp_ltv_pct=max(stats.get('max_lp_ltv_pct',0),100*mark['max_lp_ltv']),
                         max_eth_ltv_pct=max(stats.get('max_eth_ltv_pct',0),100*mark['max_eth_cohort_ltv']),
                         max_gross_credit_shortfall=max(stats.get('max_gross_credit_shortfall',0),
                              mark['lp_gross_credit_shortfall']+mark['eth_gross_credit_shortfall']))
            newfees=book.pool.fees_paid
            gross_fee_mark+=(newfees[0]-previous_fee[0])+(newfees[1]-previous_fee[1])*reference
            previous_fee=list(newfees)
            if record:
                series.append(dict(timestamp=timestamp,reference=reference,spot=book.pool.spot_price(),
                                   center=book.pool.price_scale,refuel_spent=book.refuel_spent,
                                   treasury_lp_nav=mark['treasury_lp_nav'],
                                   seed_hodl=initial_tq+initial_ts*reference,
                                   treasury_equity_after_refuels=mark['treasury_equity_after_refuels'],
                                   lp_borrower_equity=mark['lp_borrower_equity'],
                                   max_lp_ltv=mark['max_lp_ltv'],outside_tokens=book.outside_tokens,
                                   refuel_shares=book.pool.donation_shares,
                                   credit_shortfall=mark['lp_gross_credit_shortfall']+mark['eth_gross_credit_shortfall']))
            previous=timestamp;previous_mark=mark;previous_reference=reference
    final=book.mark(reference,eth_at(timestamp));final_nav=final['treasury_lp_nav']
    hodl=initial_tq+initial_ts*reference;borrower_hodl=initial_lp_q+initial_lp_s*reference
    summary=dict(external_seed=external_seed,additional_debt=additional_debt,
                 bootstrap_liability_tokens=external_seed,initial_pool_value=2*external_seed,
                 initial_total_pool_value_after_issuance=initial_pool_nav,
                 start_timestamp=start,end_timestamp=timestamp,days=len(daily),observations=points,
                 reference_return_pct=100*(reference-1),daily_refuel_budget=daily_refuel,
                 refuel_spent=book.refuel_spent,refuel_unspent=book.refuel_unspent,
                 refuel_eth_equivalent=refuel_eth,
                 mean_refuel_per_day=book.refuel_spent/len(daily),
                 refuel_shares_burned=book.pool.refuel_shares_burned,
                 remaining_refuel_shares=book.pool.donation_shares,
                 max_spot_error_pct=100*max_spot,pre_arbitrage_max_spot_error_pct=100*pre_max_spot,
                 max_center_error_pct=100*max_center,spot_breach_observations=bad_spot,
                 center_breach_observations=bad_center,
                 seed_lp_initial_nav=initial['treasury_lp_nav'],seed_lp_final_nav=final_nav,
                 seed_lp_pnl=final_nav-initial['treasury_lp_nav'],
                 seed_lp_return_pct=100*(final_nav/initial['treasury_lp_nav']-1),
                 seed_lp_pnl_from_bootstrap=final_nav-2*external_seed,
                 seed_hodl_final_nav=hodl,seed_lp_vs_hodl=final_nav-hodl,
                 seed_lp_vs_hodl_pct=100*(final_nav/hodl-1),
                 treasury_equity_initial=initial['treasury_equity_before_refuels'],
                 treasury_equity_final_after_refuels=final['treasury_equity_after_refuels'],
                 treasury_equity_pnl_after_refuels=final['treasury_equity_after_refuels']-initial['treasury_equity_before_refuels'],
                 lp_borrower_initial_equity=initial['lp_borrower_equity'],
                 lp_borrower_final_equity=final['lp_borrower_equity'],
                 lp_borrower_equity_pnl=final['lp_borrower_equity']-initial['lp_borrower_equity']-controller_equity,
                 lp_borrower_nav_vs_hodl=final['lp_collateral_nav']-borrower_hodl,
                 max_lp_ltv_pct=100*max_ltv,max_gross_credit_shortfall=max_credit,
                 max_eth_ltv_pct=100*max_eth_ltv,max_lp_gross_credit_shortfall=max_lp_credit,
                 max_eth_gross_credit_shortfall=max_eth_credit,
                 final_gross_credit_shortfall=final['lp_gross_credit_shortfall']+final['eth_gross_credit_shortfall'],
                 eth_opening_ltv=eth_ltv,eth_final_ltv=final['eth_ltv'],
                 eth_final_max_cohort_ltv=final['max_eth_cohort_ltv'],
                 arbitrage_trades=total_arb,arbitrage_quote_volume=total_volume,
                 arbitrage_profit_before_fixed_cost=total_arb_profit,
                 gross_replay_swap_fee_mark=gross_fee_mark,issuance_swap_fee_mark=issuance_fee_mark,
                 recenter_count=book.pool.recenter_count,recenter_rejections=book.pool.recenter_rejections,
                 inventory_limited_observations=inventory_limited_points,
                 max_unbacked_external_tokens_required=max_token_deficit,
                 initial_outside_tokens_after_first_arb=bootstrap_outside,
                 final_outside_tokens=book.outside_tokens,finite_inventory=finite_inventory,
                 final_pool_quote=book.pool.balances[0],final_pool_stable=book.pool.balances[1],
                 final_price_scale=book.pool.price_scale,final_reference=reference,
                 final_spot=book.pool.spot_price(),
                 external_cost=external_cost,min_arbitrage_profit=min_profit,path=path,
                 admin_claims_simulated=False,interest_income_simulated=False,
                 eth_final_equity=final['eth_borrower_equity'],
                 final_additional_debt=book.additional_debt,controller_added_debt=controller_debt,
                 controller_lp_net_quote_cash=controller_cash,
                 controller_eth_collateral_posted_usdt=controller_eth,
                 daily_new_debt_cap=daily_new_debt_cap,total_new_debt_cap=total_new_debt_cap)
    return dict(summary=summary,daily=daily,series=series)


if __name__=='__main__':
    print(json.dumps(static_capacity(),indent=2))
