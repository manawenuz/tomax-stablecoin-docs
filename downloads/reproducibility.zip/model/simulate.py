"""Deterministic, single-range V3 issuance model. All amounts at initial FX peg.

Run: python3 -m model.simulate --output results
Only LP principal earns active liquidity; swap fees accrue separately and are
not reinvested. Continuous prices omit tick rounding, gas, and token rounding.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import dataclass
from pathlib import Path


class RangeExhausted(ValueError):
    pass


@dataclass
class Pool:
    liquidity: float
    sqrt_price: float = 1.0
    lower: float = 0.97
    upper: float = 1.0
    fee: float = 0.0
    stable_fees: float = 0.0
    quote_fees: float = 0.0

    @classmethod
    def seeded(cls, value: float, **kwargs) -> Pool:
        pool = cls(1.0, **kwargs)
        if value <= 0 or not 0 <= pool.fee < 1:
            raise ValueError("Positive seed and fee in [0,1) required")
        if not pool.lower < pool.sqrt_price**2 <= pool.upper:
            raise ValueError("Starting price must be above lower bound and at or below upper bound")
        pool.liquidity = value / sum(pool.unit_reserves())
        return pool

    @property
    def price(self) -> float:
        return self.sqrt_price**2

    def unit_reserves(self) -> tuple[float, float]:
        return (1 / self.sqrt_price - 1 / math.sqrt(self.upper),
                self.sqrt_price - math.sqrt(self.lower))

    def reserves(self) -> tuple[float, float]:
        x, y = self.unit_reserves()
        return self.liquidity * x, self.liquidity * y

    def buy(self, stable_out: float) -> float:
        """Buy exact stable output; return gross quote input including fees."""
        if stable_out < 0:
            raise ValueError("Negative trade")
        if stable_out == 0:
            return 0.0
        x, _ = self.reserves()
        if stable_out >= x:
            raise RangeExhausted("Upper range boundary")
        after = 1 / (1 / self.sqrt_price - stable_out / self.liquidity)
        effective = self.liquidity * (after - self.sqrt_price)
        gross = effective / (1 - self.fee)
        self.quote_fees += gross - effective
        self.sqrt_price = after
        return gross

    def sell_capacity(self) -> float:
        return max(0.0, self.liquidity * (
            1 / math.sqrt(self.lower) - 1 / self.sqrt_price)) / (1 - self.fee)

    def sell(self, stable_in: float) -> float:
        """Sell gross stable input; return quote output excluding any gas."""
        if stable_in < 0:
            raise ValueError("Negative trade")
        if stable_in > self.sell_capacity() * (1 + 1e-10):
            raise RangeExhausted("Lower range boundary")
        effective = stable_in * (1 - self.fee)
        after = 1 / (1 / self.sqrt_price + effective / self.liquidity)
        output = self.liquidity * (self.sqrt_price - after)
        self.stable_fees += stable_in - effective
        self.sqrt_price = after
        return output

    def lp_entry(self, collateral_value: float, actual_ltv: float) -> dict:
        """Buy all stable leg, add the same range, mint debt, sell all debt.

        LP collateral_value is valued using an EXTERNAL peg for the stable leg
        and $1 for quote, at the post-purchase inventory, before borrowing.
        This accounting assumption is not a recommendation to trust spot LP NAV.
        """
        if collateral_value <= 0 or not 0 < actual_ltv < 1:
            raise ValueError("Positive collateral and LTV strictly below one required")
        x0, _ = self.reserves()
        left, right = 0.0, min(collateral_value, x0 * (1 - 1e-12))
        for _ in range(55):
            bought = (left + right) / 2
            s = 1 / (1 / self.sqrt_price - bought / self.liquidity)
            x = self.liquidity * (1 / s - 1 / math.sqrt(self.upper))
            y = self.liquidity * (s - math.sqrt(self.lower))
            required = collateral_value * x / (x + y)
            if bought < required:
                left = bought
            else:
                right = bought
        bought = (left + right) / 2
        quote_buy = self.buy(bought)
        unit_x, unit_y = self.unit_reserves()
        added_liquidity = collateral_value / (unit_x + unit_y)
        quote_deposit = unit_y * added_liquidity
        self.liquidity += added_liquidity
        debt = actual_ltv * collateral_value
        proceeds = self.sell(debt)
        return dict(collateral_value=collateral_value, debt=debt,
                    stable_bought=bought, quote_buy=quote_buy,
                    quote_deposit=quote_deposit, quote_proceeds=proceeds,
                    borrower_net_cash=quote_buy + quote_deposit - proceeds)


def price_at_stable_share(share: float, lower=.97, upper=1.0) -> float:
    """Inventory share at the EXTERNAL peg, not at AMM spot."""
    if not 0 < share < 1:
        raise ValueError("Share must be between zero and one")
    b = (1 - share) / math.sqrt(upper) - share * math.sqrt(lower)
    s = (-b + math.sqrt(b*b + 4*share*(1-share))) / (2*share)
    return s*s


def asymptote(lp_share=.9, actual_ltv=.874, fee=0.0, lower=.97, upper=1.0) -> float | None:
    equilibrium_share = actual_ltv * (1-fee) / lp_share
    if equilibrium_share >= 1:
        return None
    return price_at_stable_share(equilibrium_share,lower,upper)


def simulate(seed=10000.0, lp_share=.9, actual_ltv=.874, fee=0.0,
             max_multiple=1000.0, steps_per_seed=100,
             checkpoint_multiples=(0, 1, 5, 10, 25, 50, 100, 1000),
             lower=.97,upper=1.0,starting_price=1.0) -> list[dict]:
    if not 0 < lp_share <= 1:
        raise ValueError("LP debt share must be in (0,1]")
    pool = Pool.seeded(seed, fee=fee,lower=lower,upper=upper,sqrt_price=math.sqrt(starting_price))
    total = lp_collateral = external_cash = 0.0
    rows = []

    def snapshot(boundary=False):
        x, y = pool.reserves()
        capacity = pool.sell_capacity()
        rows.append(dict(seed_usd=seed, lp_debt_share=lp_share, actual_lp_ltv=actual_ltv,
                         range_lower=lower,range_upper=upper,starting_price=starting_price,
                         swap_fee=fee, total_debt=total, lp_debt=total*lp_share,
                         eth_debt=total*(1-lp_share), lp_collateral_added=lp_collateral,
                         lp_borrower_net_cash=external_cash, pool_spot=pool.price,
                         discount_pct=100*(1-pool.price), active_stables=x, active_quote=y,
                         extra_sell_to_edge=capacity,
                         extra_sell_pct_of_debt=100*capacity/total if total else None,
                         pool_principal_peg_value=x+y, accrued_stable_fees=pool.stable_fees,
                         accrued_quote_fees=pool.quote_fees, boundary_reached=boundary))

    snapshot()
    step = seed / steps_per_seed
    for multiple in checkpoint_multiples:
        target = min(seed * multiple, seed * max_multiple)
        while total < target - seed*1e-10:
            debt = min(step, target-total)
            collateral = debt*lp_share/actual_ltv
            # Commit a proportional cohort only if BOTH loan types can complete.
            trial = Pool(**vars(pool))
            try:
                flow = trial.lp_entry(collateral, actual_ltv)
                trial.sell(debt*(1-lp_share))
            except RangeExhausted:
                # Find the largest feasible fractional cohort at the boundary.
                low, high = 0.0, debt
                for _ in range(45):
                    part = (low+high)/2
                    check = Pool(**vars(pool))
                    try:
                        check.lp_entry(part*lp_share/actual_ltv, actual_ltv)
                        check.sell(part*(1-lp_share))
                        low = part
                    except RangeExhausted:
                        high = part
                if low > seed*1e-10:
                    flow = pool.lp_entry(low*lp_share/actual_ltv, actual_ltv)
                    pool.sell(low*(1-lp_share))
                    total += low
                    lp_collateral += low*lp_share/actual_ltv
                    external_cash += flow['borrower_net_cash']
                snapshot(True)
                return rows
            pool = trial
            total += debt
            lp_collateral += collateral
            external_cash += flow['borrower_net_cash']
        if target > 0:
            snapshot()
        if multiple >= max_multiple:
            break
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=Path('results'))
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    # Model is scale invariant; reuse normalized $10k path for $20k/$50k.
    normalized = simulate()
    dollar_fields = {'seed_usd','total_debt','lp_debt','eth_debt','lp_collateral_added',
                     'lp_borrower_net_cash','active_stables','active_quote',
                     'extra_sell_to_edge','pool_principal_peg_value',
                     'accrued_stable_fees','accrued_quote_fees'}
    rows = []
    for seed in (10000,20000,50000):
        for row in normalized:
            rows.append({k:(v*seed/10000 if k in dollar_fields else v)
                         for k,v in row.items()})
    envelope_rows = simulate(max_multiple=60,checkpoint_multiples=tuple(i/100 for i in range(6001)))
    envelopes = []
    for fraction in (.05,.10,.20):
        for previous, current in zip(envelope_rows,envelope_rows[1:]):
            prev_gap=previous['extra_sell_to_edge']-fraction*previous['total_debt']
            gap=current['extra_sell_to_edge']-fraction*current['total_debt']
            if gap <= 0:
                weight=prev_gap/(prev_gap-gap)
                ceiling=previous['total_debt']+weight*(current['total_debt']-previous['total_debt'])
                envelopes.append(dict(secondary_sale_fraction=fraction,
                                      additional_debt_at_10k_seed=ceiling,
                                      method='Linear interpolation across $100 debt cohorts'))
                break
    scenarios = dict(assumptions=dict(range_lower=.97,range_upper=1.0,starting_price=1.0,
                     peg_reference=1.0,seed_inventory='Entirely external quote at upper boundary',
                     upper_peg_expansion='Proposed policy, not simulated'),
                     base=rows, secondary_sale_envelopes=envelopes,
                     fee_5bps=simulate(fee=.0005,max_multiple=100,
                     checkpoint_multiples=(0,1,10,100)),
                     lp_share_85pct=simulate(lp_share=.85,max_multiple=100,
                     checkpoint_multiples=(0,1,5,10,25,50,100)),
                     full_95pct_ltv=simulate(actual_ltv=.95,max_multiple=100,
                     checkpoint_multiples=(0,1,5,10,25,50,100)),
                     lp_share_96pct=simulate(lp_share=.96,max_multiple=100,
                     checkpoint_multiples=(0,1,10,100)),
                     analytic=dict(lp_share_threshold=.874,
                     asymptotic_price=asymptote(), asymptotic_discount_pct=100*(1-asymptote()),
                     asymptotic_price_fee_5bps=asymptote(fee=.0005),
                     asymptotic_price_96pct_lp=asymptote(lp_share=.96)))
    (args.output/'simulation.json').write_text(json.dumps(scenarios,indent=2)+'\n')
    with (args.output/'issuance.csv').open('w',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=list(rows[0]),lineterminator='\n')
        writer.writeheader();writer.writerows(rows)
    print(json.dumps({'asymptote':scenarios['analytic'],'secondary_sale_envelopes':envelopes,
                     '10k_seed_checkpoints':[{k:r[k] for k in ('total_debt','discount_pct','active_quote','extra_sell_to_edge')}
                                            for r in normalized],
                     '85pct_lp_boundary':scenarios['lp_share_85pct'][-1]},indent=2))


if __name__ == '__main__':
    main()
