# pragma version 0.4.3
# Only the two getters used by the genuine pool are mocked.
admin: public(immutable(address))
fee_receiver: public(immutable(address))

@deploy
def __init__(_admin: address, _fee_receiver: address):
    admin = _admin
    fee_receiver = _fee_receiver
