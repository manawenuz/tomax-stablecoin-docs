# pragma version 0.4.3
# Local test token. Minting is deliberately unrestricted.
name: public(String[64])
symbol: public(String[32])
decimals: public(constant(uint8)) = 18
totalSupply: public(uint256)
balanceOf: public(HashMap[address, uint256])
allowance: public(HashMap[address, HashMap[address, uint256]])

@deploy
def __init__(_name: String[64], _symbol: String[32]):
    self.name = _name
    self.symbol = _symbol

@external
def mint(receiver: address, amount: uint256):
    self.balanceOf[receiver] += amount
    self.totalSupply += amount

@external
def approve(spender: address, amount: uint256) -> bool:
    self.allowance[msg.sender][spender] = amount
    return True

@external
def transfer(receiver: address, amount: uint256) -> bool:
    self.balanceOf[msg.sender] -= amount
    self.balanceOf[receiver] += amount
    return True

@external
def transferFrom(sender: address, receiver: address, amount: uint256) -> bool:
    if sender != msg.sender:
        self.allowance[sender][msg.sender] -= amount
    self.balanceOf[sender] -= amount
    self.balanceOf[receiver] += amount
    return True
