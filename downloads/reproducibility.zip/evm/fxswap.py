"""Execute FXSwap's verified pool AND deployed StableSwap math in local py-evm.

Only ERC20 tokens and the factory getters are mocked. There is no chain fork,
RPC, signer, private key, or live transaction. Calls use genuine creation
bytecode with fresh constructor arguments and admin ``set_periphery``.

The Python convenience API uses whole-token units like model.fxswap.FXPool;
``contract`` and ``tokens`` expose integer wei APIs inside ``context()``.
Wallets are finite. Every deposit/swap spends actual mock-token balances.
"""
from __future__ import annotations

from contextlib import contextmanager
from decimal import Decimal
from importlib.metadata import version
from pathlib import Path
import os
import tempfile

from .artifacts import DEFAULT_CACHE, SPECS, digest, load_artifacts, validate_artifacts

WAD = 10**18
FEE_UNIT = 10**10
ZERO = "0x0000000000000000000000000000000000000000"
MOCKS = Path(__file__).parent / "mocks"


def units(amount: float | int | str | Decimal, scale: int = WAD) -> int:
    value = Decimal(str(amount))
    if not value.is_finite() or value < 0:
        raise ValueError("amount must be nonnegative and finite")
    return int(value * scale)


def _runtime():
    # vvm otherwise creates ~/.vvm at import time, even for precompiled code.
    os.environ.setdefault("VVM_BINARY_PATH", str(Path(tempfile.gettempdir()) / "tomax-vvm"))
    import boa
    from boa.contracts.vvm.vvm_contract import VVMDeployer
    boa.interpret.set_cache_dir(Path(tempfile.gettempdir()) / "tomax-boa-cache")
    return boa, VVMDeployer


class FXEVMPool:
    """One isolated local EVM, genuine FXSwap, and explicitly funded wallets.

    ``wallet_balance`` is a finite initial mock endowment per coin, never
    topped up by swap/deposit methods. Use ``fund`` only for explicit issuance.
    ``quote`` simulates a real exchange under an EVM snapshot and rolls it back;
    consequently no substitute Views implementation participates in pricing.
    """

    def __init__(self, params=None, price: float = 1.0, timestamp: int = 0, *,
                 wallet_balance=(1_000_000.0, 1_000_000.0), artifacts=None,
                 cache_dir=DEFAULT_CACHE):
        if params is None:
            from model.fxswap import FXParams
            params = FXParams()
        if params.noise_fee != 1e-5 or params.admin_claim_interval != 86400:
            raise ValueError("NOISE_FEE and admin claim interval are source constants")
        self.params = params
        self.artifacts = (validate_artifacts(artifacts) if artifacts is not None
                          else load_artifacts(cache_dir))
        self.boa, Deployer = _runtime()
        self.env = self.boa.Env()
        self.env.timestamp = int(timestamp)
        self.owner = self.env.eoa
        self.fee_receiver = self.env.generate_address("fee_receiver")
        self.accounts = {self.owner, self.fee_receiver}
        self.gas_used = 0
        self.last_gas_used = 0
        self._snapshots = []
        with self.context():
            self.tokens = [self.boa.load(str(MOCKS / "ERC20.vy"), name, symbol)
                           for name, symbol in (("External quote", "EXT"), ("Own stable", "OWN"))]
            self.factory = self.boa.load(str(MOCKS / "Factory.vy"), self.owner, self.fee_receiver)
            self.math = Deployer(self.artifacts["math"]["abi"],
                                 bytes.fromhex(self.artifacts["math"]["bytecode"].removeprefix("0x")),
                                 "VerifiedStableswapMath", "verified/StableswapMath.vy").deploy()
            deployer = Deployer(self.artifacts["pool"]["abi"],
                                bytes.fromhex(self.artifacts["pool"]["bytecode"].removeprefix("0x")),
                                "VerifiedFXSwap", "verified/Twocrypto.vy")
            pack3 = lambda x, y, z: (x << 128) | (y << 64) | z
            # Local factory impersonation changes only constructor msg.sender;
            # the deployed mock supplies genuine subsequent EVM getter calls.
            with self.env.prank(self.factory.address):
                self.contract = deployer.deploy(
                    "Local FXSwap", "FX-LP", [t.address for t in self.tokens],
                    self.math.address, bytes(32), 1 | (1 << 128),
                    params.gamma | (params.raw_a << 128),
                    pack3(units(params.mid_fee, FEE_UNIT), units(params.out_fee, FEE_UNIT),
                          units(params.fee_gamma)),
                    pack3(units(params.allowed_extra_profit), units(params.adjustment_step),
                          int(params.ma_time)), units(price),
                )
            self.contract.set_periphery(ZERO, self.math.address)
            self.contract.set_admin_fee(units(params.admin_fee, FEE_UNIT))
            self.contract.set_donation_duration(int(params.donation_duration))
            self.contract.set_donation_protection_params(
                int(params.donation_protection_period), units(params.donation_protection_lp_threshold),
                units(params.donation_shares_max_ratio))
            self._approve(self.owner)
        self.fund(self.owner, wallet_balance)

    @contextmanager
    def context(self):
        with self.boa.swap_env(self.env):
            yield self

    def _call(self, name, *args):
        with self.context():
            return getattr(self.contract, name)(*args)

    def _at(self, timestamp):
        timestamp = int(timestamp)
        if timestamp < self.env.timestamp:
            raise ValueError("timestamp predates local EVM")
        self.env.timestamp = timestamp

    def begin_snapshot(self):
        """Checkpoint EVM state and driver bookkeeping; nested tokens are LIFO.

        Do not deepcopy this pool. A snapshot can be committed or reverted once.
        Pool/token storage, balances, LP ownership and block timestamp roll back.
        """
        with self.context():
            if not self._snapshots:
                # Reset before checkpointing: py-evm's warm-access journal must
                # never be cleared while a state checkpoint is active.
                self.env.reset_gas_used()
            token = {
                "state": self.env.evm.snapshot(),
                "timestamp": self.env.timestamp,
                "accounts": self.accounts.copy(),
                "gas_used": self.gas_used,
                "last_gas_used": self.last_gas_used,
            }
        self._snapshots.append(token)
        return token

    def _require_snapshot(self, token):
        if not self._snapshots or self._snapshots[-1] is not token:
            raise ValueError("snapshots must be committed/reverted once, in LIFO order")

    def revert_snapshot(self, token):
        self._require_snapshot(token)
        with self.context():
            self.env.evm.revert(token["state"])
        self.env.timestamp = token["timestamp"]
        self.accounts = token["accounts"]
        self.gas_used = token["gas_used"]
        self.last_gas_used = token["last_gas_used"]
        self._snapshots.pop()

    def commit_snapshot(self, token):
        self._require_snapshot(token)
        with self.context():
            # Titanoboa exposes snapshot/revert, while py-evm supplies commit.
            self.env.evm.vm.state.commit(token["state"])
        self._snapshots.pop()

    @contextmanager
    def atomic(self):
        """Keep a composite action on success; revert it on any exception."""
        token = self.begin_snapshot()
        try:
            yield self
        except BaseException:
            self.revert_snapshot(token)
            raise
        else:
            self.commit_snapshot(token)

    @contextmanager
    def rollback(self):
        """Always discard speculative pool/token actions, time and gas counters."""
        token = self.begin_snapshot()
        try:
            yield self
        finally:
            self.revert_snapshot(token)

    @contextmanager
    def _transaction(self, timestamp, account):
        self._at(timestamp)
        with self.context(), self.env.prank(account or self.owner):
            # A checkpointed composite keeps one warm-access journal. Clearing
            # it inside a py-evm checkpoint invalidates that checkpoint.
            if not self._snapshots:
                self.env.reset_gas_used()
            gas_before = self.env.get_gas_used()
            try:
                yield
            finally:
                self.last_gas_used = self.env.get_gas_used() - gas_before
                self.gas_used += self.last_gas_used

    def _approve(self, account):
        with self.env.prank(account):
            for token in self.tokens:
                token.approve(self.contract.address, 2**256 - 1)

    def new_account(self, label="actor", balances=(0, 0)):
        account = self.env.generate_address(label)
        with self.context():
            self._approve(account)
        self.fund(account, balances)
        return account

    def fund(self, account, amounts):
        """Explicitly mint mock assets; never called implicitly after setup."""
        self.accounts.add(account)
        with self.context():
            for token, amount in zip(self.tokens, amounts, strict=True):
                token.mint(account, units(amount))

    def wallet_balances_wei(self, account=None):
        with self.context():
            return tuple(t.balanceOf(account or self.owner) for t in self.tokens)

    def lp_balance_wei(self, account=None):
        return self._call("balanceOf", account or self.owner)

    @property
    def balances(self):
        return [self._call("balances", i) / WAD for i in range(2)]

    @property
    def total_supply(self):
        return self._call("totalSupply") / WAD

    @property
    def user_supply(self):
        return self._call("user_supply") / WAD

    @property
    def donation_shares(self):
        return self._call("donation_shares") / WAD

    @property
    def price_scale(self):
        return self._call("price_scale") / WAD

    @property
    def D(self):
        return self._call("D") / WAD

    @property
    def virtual_price(self):
        return self._call("virtual_price") / WAD

    @property
    def xcp_profit(self):
        return self._call("xcp_profit") / WAD

    @property
    def xcp_profit_a(self):
        return self._call("xcp_profit_a") / WAD

    @property
    def last_prices(self):
        return self._call("last_prices") / WAD

    @property
    def last_timestamp(self):
        return self._call("last_timestamp")

    def fee(self):
        return self._call("fee") / FEE_UNIT

    def price_oracle(self, timestamp):
        with self.context(), self.env.anchor():
            self._at(timestamp)
            return self.contract.price_oracle() / WAD

    def spot_price(self):
        with self.context():
            xp = [self.contract.balances(0),
                  self.contract.balances(1) * self.contract.price_scale() // WAD]
            return (self.math.get_p(xp, self.contract.D(),
                                    [self.contract.A(), self.contract.gamma()])
                    * self.contract.price_scale() // WAD) / WAD

    def swap(self, i, dx, timestamp, *, account=None, minimum=0):
        with self._transaction(timestamp, account):
            return self.contract.exchange(i, 1-i, units(dx), units(minimum)) / WAD

    def quote(self, i, dx, timestamp=None, *, account=None):
        with self.rollback():
            return self.swap(i, dx, self.env.timestamp if timestamp is None else timestamp,
                             account=account)

    def add_liquidity(self, amount0, amount1, timestamp, donation=False, *, account=None):
        account = account or self.owner
        with self._transaction(timestamp, account):
            return self.contract.add_liquidity(
                [units(amount0), units(amount1)], 0, ZERO if donation else account, donation) / WAD

    def refuel(self, amount0, amount1, timestamp, *, account=None):
        return self.add_liquidity(amount0, amount1, timestamp, True, account=account)

    def recoverable(self, shares):
        amount = units(shares)
        with self.context():
            supply = self.contract.totalSupply()
            if amount > self.contract.user_supply():
                raise ValueError("shares exceed user-owned supply")
            return tuple(self.contract.balances(i) * amount // supply / WAD if supply else 0.0
                         for i in range(2))

    def withdraw(self, shares, timestamp, *, account=None):
        with self._transaction(timestamp, account):
            return tuple(x / WAD for x in self.contract.remove_liquidity(units(shares), [0, 0]))

    def withdraw_all(self, timestamp, *, account=None):
        """Redeem an account's exact integer LP balance, avoiding float dust."""
        account = account or self.owner
        with self._transaction(timestamp, account):
            return tuple(x / WAD for x in self.contract.remove_liquidity(
                self.contract.balanceOf(account), [0, 0]))

    def withdraw_one_coin(self, shares, i, timestamp, *, account=None, minimum=0):
        with self._transaction(timestamp, account):
            return self.contract.remove_liquidity_one_coin(units(shares), i, units(minimum)) / WAD

    def withdraw_fixed_out(self, shares, i, amount_i, timestamp, *, account=None, minimum_other=0):
        with self._transaction(timestamp, account):
            return self.contract.remove_liquidity_fixed_out(
                units(shares), i, units(amount_i), units(minimum_other)) / WAD

    def quote_withdraw_one_coin(self, shares, i, timestamp=None, *, account=None):
        # Simulate the transaction, including its internal admin-fee claim.
        with self.rollback():
            return self.withdraw_one_coin(shares, i,
                self.env.timestamp if timestamp is None else timestamp, account=account)

    def state_wei(self):
        """Integer state for exact conservation/revert checks and result files."""
        names = ("D", "totalSupply", "user_supply", "donation_shares", "virtual_price",
                 "xcp_profit", "xcp_profit_a", "price_scale", "price_oracle", "last_prices",
                 "last_timestamp", "last_donation_release_ts", "donation_protection_expiry_ts")
        with self.context():
            out = {name: getattr(self.contract, name)() for name in names}
            out["balances"] = [self.contract.balances(i) for i in range(2)]
            out["actual_token_balances"] = [t.balanceOf(self.contract.address) for t in self.tokens]
            out["owner_tokens"] = list(self.wallet_balances_wei())
            out["owner_lp"] = self.contract.balanceOf(self.owner)
            out["admin_tokens"] = list(self.wallet_balances_wei(self.fee_receiver))
            return out

    def assert_conservation(self):
        """Pool accounting must match actual ERC20 balances; LP excludes donations."""
        with self.context():
            for i, token in enumerate(self.tokens):
                assert token.balanceOf(self.contract.address) == self.contract.balances(i)
                assert (sum(token.balanceOf(a) for a in self.accounts)
                        + token.balanceOf(self.contract.address)) == token.totalSupply()
            assert self.contract.user_supply() + self.contract.donation_shares() == self.contract.totalSupply()
            assert sum(self.contract.balanceOf(a) for a in self.accounts) == self.contract.user_supply()

    def provenance(self):
        with self.context():
            return {
                "backend": "titanoboa/py-evm (local, no fork)",
                "dependencies": {p: version(p) for p in ("titanoboa", "vyper", "py-evm")},
                "pool_version": self.contract.version(), "math_version": self.math.version(),
                "pinned": SPECS,
                "local_math_runtime_sha256": digest(self.env.get_code(self.math.address)),
                "mocked": ["18-decimal ERC20s with explicit minting", "factory admin/fee_receiver getters"],
                "views": "unused; quotes execute genuine pool exchanges under reverted snapshots",
                "constructor": "verified creation bytecode; fresh tokens, factory, parameters and price",
            }
