"""Atomic exact-bytecode replay of the sandbox's committed FXPool journal.

The fast model remains useful for strategy search and speculative clones. Every
committed mutation is also executed by genuine pool/math EVM bytecode here.
The enclosing sandbox owns economic wallet/issuance/collateral bookkeeping; the
EVM driver account is an explicit finite aggregate mock-token custodian.
"""
from __future__ import annotations

import math

from .fxswap import FXEVMPool, WAD, units


class EVMDivergence(ValueError):
    """The genuine EVM rejected a transition or diverged beyond tolerance."""


class EVMJournalAudit:
    def __init__(self, pool: FXEVMPool, *, relative_tolerance=2e-10,
                 absolute_tolerance=2e-8):
        self.pool = pool
        self.relative_tolerance = relative_tolerance
        self.absolute_tolerance = absolute_tolerance
        self.operations = 0
        self.batches = 0
        self.failures = 0
        self.maximum_absolute_error = 0.0
        self.maximum_relative_error = 0.0
        self.full_exit_rounding_adjustments = 0

    @classmethod
    def seeded(cls, seed, timestamp, params=None, price=1.0, *,
               wallet_balance=(10**12, 10**12), artifacts=None, cache_dir=None,
               relative_tolerance=2e-10, absolute_tolerance=2e-8):
        kwargs = {"wallet_balance": wallet_balance, "artifacts": artifacts}
        if cache_dir is not None:
            kwargs["cache_dir"] = cache_dir
        pool = FXEVMPool(params, price, timestamp, **kwargs)
        pool.add_liquidity(seed, seed / price, timestamp)
        out = cls(pool, relative_tolerance=relative_tolerance,
                  absolute_tolerance=absolute_tolerance)
        out.initial_mock_endowment = list(wallet_balance)
        return out

    def _compare(self, label, actual, expected, errors):
        if isinstance(actual, (tuple, list)):
            if len(actual) != len(expected):
                raise EVMDivergence(f"{label}: output lengths differ")
            for i, (a, e) in enumerate(zip(actual, expected, strict=True)):
                self._compare(f"{label}[{i}]", a, e, errors)
            return
        absolute = abs(actual - expected)
        relative = absolute / max(abs(expected), 1.0)
        if not math.isclose(actual, expected, rel_tol=self.relative_tolerance,
                            abs_tol=self.absolute_tolerance):
            raise EVMDivergence(f"{label}: actual EVM {actual:.17g}, float {expected:.17g}")
        errors.append((absolute, relative))

    def execute(self, journal, float_pool):
        """Replay a batch atomically; ``ValueError`` leaves the EVM unchanged.

        Entries are ``(method, positional_args, expected_float_output)``. The
        sandbox may then roll back its own ledger on EVMDivergence. Successful
        batches commit real EVM token transfers and LP mint/burn, not a quote.
        """
        errors = []
        receipts = []
        adjusted = 0
        try:
            with self.pool.atomic():
                for method, args, expected in journal:
                    if method not in {"swap", "add_liquidity", "withdraw", "withdraw_one_coin",
                                      "withdraw_fixed_out", "refuel"}:
                        raise EVMDivergence(f"unsupported journal operation: {method}")
                    if method == "withdraw":
                        shares, timestamp = args
                        actual_lp = self.pool.lp_balance_wei()
                        # Floating LP accounting cannot round-trip wei. When
                        # the journal means a complete aggregate exit, burn the
                        # actual integer account balance; never mint LP to fit.
                        tolerance = max(int(self.absolute_tolerance * WAD),
                                        int(self.relative_tolerance * actual_lp))
                        if abs(units(shares) - actual_lp) <= tolerance:
                            output = self.pool.withdraw_all(timestamp)
                            adjusted += units(shares) != actual_lp
                        else:
                            output = self.pool.withdraw(*args)
                    else:
                        output = getattr(self.pool, method)(*args)
                    self._compare(f"{method}.output", output, expected, errors)
                    self.pool.assert_conservation()
                    receipts.append({"operation": method, "execution_gas": self.pool.last_gas_used})
                for name in ("balances", "D", "total_supply", "user_supply", "donation_shares",
                             "price_scale", "virtual_price", "xcp_profit", "xcp_profit_a", "last_prices"):
                    self._compare(f"state.{name}", getattr(self.pool, name),
                                  getattr(float_pool, name), errors)
        except Exception as exc:
            self.failures += 1
            if isinstance(exc, EVMDivergence):
                raise
            raise EVMDivergence(f"genuine FXSwap EVM execution failed ({type(exc).__name__})") from exc
        self.operations += len(receipts)
        self.batches += 1
        self.full_exit_rounding_adjustments += adjusted
        self.maximum_absolute_error = max(self.maximum_absolute_error, *(x[0] for x in errors))
        self.maximum_relative_error = max(self.maximum_relative_error, *(x[1] for x in errors))
        return receipts

    def summary(self):
        return {
            "backend": "genuine verified FXSwap + StableSwap MATH in local py-evm",
            "operations": self.operations,
            "committed_batches": self.batches,
            "failed_batches": self.failures,
            "execution_gas": self.pool.gas_used,
            "maximum_absolute_difference": self.maximum_absolute_error,
            "maximum_relative_difference": self.maximum_relative_error,
            "relative_tolerance": self.relative_tolerance,
            "absolute_tolerance_tokens": self.absolute_tolerance,
            "full_exit_rounding_adjustments": self.full_exit_rounding_adjustments,
            "final_state_wei": self.pool.state_wei(),
            "provenance": self.pool.provenance(),
            "custody_note": "finite aggregate mock-token driver; individual economic wallets are in Sandbox",
        }
