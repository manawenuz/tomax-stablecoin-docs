# Exact FXSwap in a local EVM

This optional backend executes the verified FXSwap **v2.1.0d pool bytecode and
its actual StableSwap math v0.1.0 bytecode** in Titanoboa/py-evm. Pool arithmetic,
fees, EMA, price-scale adjustments, donation release/protection, LP mint/burn,
withdrawals and admin-fee transfers execute as EVM instructions. Only two
18-decimal ERC20s and factory `admin`/`fee_receiver` getters are mocked.

The environment starts with fresh reserves at the supplied historical timestamp.
It does not clone historical chain state. No RPC, fork, keys or live transactions
are used. `--fetch` only retrieves public verification metadata over HTTPS.

## Reproduce

```sh
UV_CACHE_DIR=/tmp/tomax-uv-cache uv venv --python 3.13 /tmp/tomax-evm
UV_CACHE_DIR=/tmp/tomax-uv-cache uv pip install --python /tmp/tomax-evm/bin/python -r requirements-evm.txt
/tmp/tomax-evm/bin/python tools/check_fxswap_evm.py --fetch --output evm/smoke-report.json
TOMAX_EVM_TESTS=1 /tmp/tomax-evm/bin/python -m unittest tests.test_fxswap_evm
```

Subsequent executions omit `--fetch` and work offline. The ABI/bytecode cache is
`tempfile.gettempdir()/tomax-fxswap-artifacts` (the per-user temporary directory on
macOS), configurable with `--cache-dir` or `TOMAX_EVM_CACHE` for tests. To use
existing metadata instead:

```sh
/tmp/tomax-evm/bin/python tools/check_fxswap_evm.py \
  --pool-artifact /path/to/sourcify.json --math-artifact /path/to/math.json
```

The verification JSON is filtered before caching: only ABI and compiled bytecode
are retained. Upstream contract source, carrying all-rights-reserved headers, is
not included in this directory. Public source endpoints, compiler/version pins,
ABI hashes and bytecode/source SHA-256 hashes are in `artifacts.py` and each
report. All code and ABI are checked against those pins before deployment.

The genuine constructor initially hardcodes mainnet periphery addresses. The
local mock factory is impersonated only for constructor `msg.sender`; subsequent
factory getter calls execute the deployed mock. The pool's own authorized
`set_periphery` switches MATH to the deployed genuine local math contract. The
Views contract is unused: quotes simulate an actual exchange and roll it back.
Source constructor arguments from mainnet are discarded; new tokens, pool
parameters and initial price are supplied. The math runtime hash is also checked
after deployment.

## Driver API

```python
from evm import FXEVMPool

p = FXEVMPool(timestamp=1700000000, wallet_balance=(20000, 20000))
lp = p.add_liquidity(10000, 10000, 1700000000)
received = p.swap(0, 100, 1700000001)
p.refuel(100, 100, 1700000002)
p.withdraw(10, 1700000003)
p.withdraw_one_coin(10, 0, 1700000004)
p.withdraw_fixed_out(10, 0, 5, 1700000005)
p.assert_conservation()
```

Whole-token convenience methods match `FXPool`'s units; integer amounts go through
the actual contracts. Input conversion floors at 18 decimals. Float outputs are
display conveniences and cannot round-trip arbitrary wei/LP dust. Use
`withdraw_all(timestamp)` for an exact complete account exit. For precise
integer input/output, use `with p.context(): p.contract.…` and `p.tokens`.
`state_wei()` returns integer pool, LP, owner and admin balances.

Wallet endowments are finite and explicit (default 1,000,000 of each mock token).
Methods never top up a wallet. `new_account(label, balances)` creates another
approved actor; mutations accept `account=actor`. `fund(actor, amounts)` is an
explicit mock issuance primitive. Token balance conservation checks include all
registered actors, pool and fee receiver; LP conservation excludes donation
shares. Issuance and any separate treasury/collateral ledger belong to the
calling experiment.

`quote` and `quote_withdraw_one_coin` run the real transaction under a reverted
checkpoint. They include any internal admin-fee claim that a static withdrawal
getter would omit. No alternate pricing implementation is used.

## Controller checkpoints

```python
checkpoint = p.begin_snapshot()
p.withdraw(100, timestamp)
p.swap(1, 50, timestamp)
if health_ok:
    p.commit_snapshot(checkpoint)
else:
    p.revert_snapshot(checkpoint)
```

Snapshots include the entire local EVM's account/storage/token state, timestamp,
registered-account ledger, and wrapper gas counters. Nested checkpoints must be
resolved once, in LIFO order. `with p.atomic(): …` commits on success and reverts
on an exception, which lets a controller reject a composite action after its
health check. `with p.rollback(): …` always discards speculative actions. Do not
`deepcopy` an EVM pool; clone the fast float model for strategy planning and use
checkpoints for actual EVM execution.

`gas_used` and `last_gas_used` count execution gas from wrapper mutations, excluding
setup, reads and rolled-back quotes. Reverting a controller checkpoint restores
these counters. They exclude intrinsic transaction/calldata gas, transactions
made directly on `contract`, and any external router/treasury overhead. A
checkpointed composite shares a warm-access journal; use these as diagnostics,
not a mainnet transaction gas quote.

## Sandbox journal replay

`EVMJournalAudit` connects to `Sandbox.audit.execute(journal, float_pool)` without
putting a live EVM object in the sandbox's deep-copied planning state:

```python
from evm import EVMJournalAudit

system.audit = EVMJournalAudit.seeded(seed, timestamp, params=system.pool.params)
# Normal system actions now replay their committed pool journal in the real EVM.
report = system.audit.summary()
```

Each batch executes genuine pool mutations, checks output/state differences and
integer conservation, then commits. A mismatch raises `EVMDivergence` (a
`ValueError`) and rolls the EVM back so the calling sandbox can also restore its
ledger. Float clones are used only for planning. The audit has an explicitly
finite aggregate token driver endowment (default 10^12 tokens per coin); the
sandbox's individual wallets and issuance rules remain the economic custody
ledger. No tokens are minted implicitly while replaying an operation. An entire
aggregate LP exit uses the driver's exact LP balance when the float share amount
differs only within the declared tolerance; this adjustment is counted. Individual
token/LP dust should be inspected through the integer state in the report.

## Checked behavior and limits

The smoke report covers both swap directions, balanced/imbalanced LP entry,
donation/refuel, time-aged recentering, actual donation-share consumption,
proportional/one-coin/fixed-output exits, admin claims, finite-wallet and slippage
reverts, controller rollback, and last-LP donation cleanup. Integer ERC20 and LP
conservation is checked after transitions. Common paths are compared to the
existing float port with stated tolerances; this finite sample does not establish
equivalence for every state. Expensive EVM tests are opt-in and default tests do
not download packages or metadata.

Token transfer quirks, six-decimal tokens, real external protocol integrations,
historical state forks, admin A/gamma ramps and live deployments are outside this
driver's smoke scenarios. They do not change the fact that the exercised pool
and MATH paths execute the pinned genuine bytecode.
