"""Fetch/validate pinned verified bytecode, without publishing upstream source.

No RPC is used. The optional network calls download verification metadata only.
The persistent cache contains ABI and compiled bytecode, not upstream source.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import tempfile
from urllib.request import Request, urlopen

POOL_ADDRESS = "0x027B40F5917FCd0eac57d7015e120096A5F92ca9"
MATH_ADDRESS = "0x79839c2d74531a8222c0f555865aac1834e82e51"
DEFAULT_CACHE = Path(tempfile.gettempdir()) / "tomax-fxswap-artifacts"
SPECS = {
    "pool": {
        "address": POOL_ADDRESS,
        "url": f"https://sourcify.dev/server/v2/contract/1/{POOL_ADDRESS}?fields=all",
        "compiler": "0.4.3+commit.bff19ea2",
        "version": "v2.1.0d",
        "creation_sha256": "5dde3ffe4c994f8038ec37c3a792cae2336f3b18f9c857d506db82f3722935ee",
        "abi_sha256": "1ee45d52dd51c319ef50b2041bb5cc2c2a10851069996313423a45f111133726",
        "source_sha256": "e9929d7c9b4d534d9255b46b3d1011975b4edb9d33235d662a81abc2409f7e86",
    },
    "math": {
        "address": MATH_ADDRESS,
        "url": f"https://eth.blockscout.com/api/v2/smart-contracts/{MATH_ADDRESS}",
        "compiler": "0.4.3+commit.bff19ea2",
        "version": "v0.1.0",
        "creation_sha256": "a56b918e521361f283fce4472dfc224776ac0fda1aa01b24630dad83b15860d0",
        "runtime_sha256": "d27729f9d38d144c4af642c9bd95de192c842465d1657d9df6edcc11abdcdef9",
        "abi_sha256": "c70dc81b28f46e29ca493466530a98f7d685dfdf3d3ba72a8733d3d6482b6abc",
        "source_sha256": "6230daf126892fd0ea494d6533bc660533705267e7958dc01e50f7b3a87df75b",
    },
}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _normalize(kind: str, raw: dict) -> dict:
    if "bytecode" in raw and "abi" in raw:  # our source-free cache
        artifact = {"abi": raw["abi"], "bytecode": raw["bytecode"]}
    elif kind == "pool":
        if raw.get("creationMatch") != "match" or raw.get("runtimeMatch") != "match":
            raise ValueError("FXSwap verification no longer reports a full match")
        artifact = {"abi": raw["abi"], "bytecode": raw["creationBytecode"]["recompiledBytecode"]}
    else:
        if not raw.get("is_verified"):
            raise ValueError("StableSwap math verification missing")
        artifact = {"abi": raw["abi"], "bytecode": raw["creation_bytecode"]}
    bytecode = bytes.fromhex(artifact["bytecode"].removeprefix("0x"))
    abi = json.dumps(artifact["abi"], sort_keys=True, separators=(",", ":")).encode()
    spec = SPECS[kind]
    if digest(bytecode) != spec["creation_sha256"]:
        raise ValueError(f"{kind} creation bytecode does not match its pinned SHA-256")
    if digest(abi) != spec["abi_sha256"]:
        raise ValueError(f"{kind} ABI does not match its pinned SHA-256")
    return artifact


def validate_artifacts(artifacts: dict) -> dict:
    """Validate even programmatically supplied bytecode and ABI."""
    return {kind: _normalize(kind, artifacts[kind]) for kind in SPECS}


def load_artifacts(cache_dir: str | Path = DEFAULT_CACHE, *, fetch: bool = False,
                   pool_artifact: str | Path | None = None,
                   math_artifact: str | Path | None = None) -> dict:
    """Read pinned ABI/bytecode; internet access requires explicit ``fetch=True``.

    Explicit files may be the original Sourcify/Blockscout JSON or this module's
    smaller cache format. Constructor arguments from mainnet are never reused.
    """
    cache_dir = Path(cache_dir)
    out = {}
    for kind, explicit in (("pool", pool_artifact), ("math", math_artifact)):
        path = Path(explicit) if explicit else cache_dir / f"{kind}.json"
        if path.exists():
            raw = json.loads(path.read_text())
        elif fetch and not explicit:
            req = Request(SPECS[kind]["url"], headers={"User-Agent": "Tomax-local-EVM-validation/1.0"})
            with urlopen(req, timeout=45) as response:
                raw = json.load(response)
        else:
            raise FileNotFoundError(
                f"Missing {kind} artifact: {path}. Run tools/check_fxswap_evm.py --fetch "
                "or supply --pool-artifact and --math-artifact."
            )
        out[kind] = _normalize(kind, raw)
        if fetch and not explicit:
            cache_dir.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(out[kind], separators=(",", ":")) + "\n")
    return out
