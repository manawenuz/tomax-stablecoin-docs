Tomax research model. Python 3.11+. Run python3 -m unittest discover -s tests -v and python3 -m model.simulate --output results. No production contracts.
