"""Export a read-only public research summary, never the runtime checkpoint."""
import json,sys,time
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from model.sandbox.paper import load_checkpoint,restore_system


def iso(t):return datetime.fromtimestamp(t,timezone.utc).isoformat().replace('+00:00','Z') if t is not None else None


def main():
    now=int(time.time());data=load_checkpoint(ROOT/'runtime/paper/checkpoint.json');c=data['config']
    system=restore_system(data['system']) if data['system'] else None
    metrics=[h['metrics'] for h in data['history'] if h.get('metrics')]
    actors={}
    if system:
        first=next(h for h in data['history'] if h.get('quotes'))['quotes']['ETH_USDT']['value']
        for name,f in c['actors'].items():
            holding=f['quote']+f.get('eth',f.get('eth_quote',0)/first)*system.market_eth
            equity=system.actor_equity(name,system.market_reference,system.market_eth)
            actors[name]=dict(marked_equity=equity,holding_benchmark=holding,pnl_vs_holding=equity-holding)
    result=dict(as_of_utc=iso(now),status='complete' if data['ends_at'] and now>=data['ends_at'] else data['status'],
        mock_only=True,actual_orders_or_chain_writes=0,started_utc=iso(data['started_at']),ends_utc=iso(data['ends_at']),
        decisions=data['decision_count'],scheduled_cadence_seconds=900,
        scheduler='Codex local thread heartbeat; host/app availability required',automation_id='tomax-14-day-paper-experiment',
        policy_config_sha256=data['policy_config_sha256'],
        funding=dict(external_pool_seed=c['seed'],additional_protocol_reserve=c['reserve'],
                     bootstrap_token_liability=c['seed'],initial_additional_debt=c['seed']*c['initial_debt_multiple']),
        raw_a=c['raw_a'],origination_band=c['origination_band'],
        last_decision_utc=iso(data['last_decision_at']),last_check_reason=data['last_result'].get('reason'),
        current_feed_ages_seconds={k:now-q['observed_at'] for k,q in data['last_quotes'].items()},
        sources={k:dict(source=q['source'],value=q['value'],observed_utc=iso(q['observed_at'])) for k,q in data['last_quotes'].items()},
        post_keeper_error=metrics[-1]['after']['error'] if metrics else None,
        max_sampled_pre_keeper_error=max((abs(m['before']['error']) for m in metrics),default=None),
        max_sampled_post_keeper_error=max((abs(m['after']['error']) for m in metrics),default=None),
        sampled_post_keeper_breaches=sum(abs(m['after']['error'])>.03 for m in metrics),
        protocol_equity=system.protocol_equity() if system else None,
        protocol_equity_change=system.protocol_equity()-c['seed']-c['reserve'] if system else None,
        debt=system.debt() if system else None,bad_debt=system.bad_debt if system else None,
        pending=system.pending_count() if system else None,assumed_gas_eth=system.gas_eth if system else None,
        actors=actors,limitations=['Only actual retrieved observations trigger decisions; no catch-up live fills',
            'Historical response success is not continuous3% or optimal-adversary proof',
            'Lending/oracle/ETH venue remain mocks; live pool uses validated float port',
            'This is an as-of export, not a continuously refreshed public dashboard'])
    (ROOT/'results/sandbox-paper-status.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:result[k] for k in ('as_of_utc','status','started_utc','ends_utc','decisions','post_keeper_error')}))


if __name__=='__main__':main()
