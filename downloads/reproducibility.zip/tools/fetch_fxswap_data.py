#!/usr/bin/env python3
"""Select IRR volatility days objectively and archive native minute/ETH data.

Uses only the Python standard library. Cached exact HTTP responses permit an
offline reproduction; --refresh makes a new, potentially revised observation.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
import csv
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
import json
import math
from pathlib import Path
import urllib.error
import urllib.parse
import urllib.request
from zoneinfo import ZoneInfo

UTC = timezone.utc
LOCAL = ZoneInfo("Asia/Tbilisi")
HOUR = 3600
WALLEX = "https://api.wallex.ir/v1/udf/history"
BINANCE = "https://api.binance.com/api/v3/klines"
FIELDS = ["timestamp", "datetime_utc", "open", "high", "low", "close", "volume_usdt"]


def iso(ts: int) -> str:
    return datetime.fromtimestamp(ts, UTC).isoformat().replace("+00:00", "Z")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def write_csv(path: Path, fields: list[str], rows: list[dict]) -> dict:
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows({key: row.get(key, "") for key in fields} for row in rows)
    return {"csv_file": str(path), "csv_sha256": sha(path), "rows": len(rows)}


def request_json(url: str, path: Path, *, offline: bool, refresh: bool) -> tuple[object, dict]:
    meta_path = path.with_suffix(".meta.json")
    if path.exists() and meta_path.exists() and not refresh:
        meta = json.loads(meta_path.read_text())
        if meta["url"] != url or meta["sha256"] != sha(path):
            raise ValueError(f"Cached response/hash differs: {path}")
        return json.loads(path.read_bytes(), parse_float=Decimal), meta
    if offline:
        raise ValueError(f"Offline cache missing: {path}")
    req = urllib.request.Request(url, headers={"User-Agent": "Tomax-FXSwap-Research/1.0"})
    with urllib.request.urlopen(req, timeout=60) as response:
        body = response.read()
        meta = {"url": url, "retrieved_at_utc": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
                "http_status": response.status, "http_date": response.headers.get("Date"),
                "content_type": response.headers.get("Content-Type"),
                "raw_file": str(path), "bytes": len(body),
                "sha256": hashlib.sha256(body).hexdigest()}
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(body)
    write_json(meta_path, meta)
    return json.loads(body, parse_float=Decimal), meta


def select_days(source: Path, output: Path) -> tuple[list[dict], dict]:
    rows = {int(row["timestamp"]): row for row in csv.DictReader(source.open())}
    by_day: dict = defaultdict(list)
    for ts, row in sorted(rows.items()):
        by_day[datetime.fromtimestamp(ts, LOCAL).date()].append(row)
    metrics = []
    eligible = []
    for day, candles in sorted(by_day.items()):
        start = int(datetime.combine(day, datetime.min.time(), LOCAL).timestamp())
        expected = list(range(start, start + 86400, HOUR))
        ts = [int(c["timestamp"]) for c in candles]
        complete = ts == expected
        zero = sum(Decimal(c["volume_usdt"]) == 0 for c in candles)
        previous = rows.get(start - HOUR)
        positive_previous = previous is not None and Decimal(previous["volume_usdt"]) > 0
        reasons = []
        if not complete:
            reasons.append("incomplete_24_hour_local_day")
        if zero:
            reasons.append("zero_volume_hour")
        if not positive_previous:
            reasons.append("missing_or_zero_volume_preceding_hour")
        m = {"local_date": str(day), "timezone": "Asia/Tbilisi", "start_timestamp": start,
             "end_timestamp_exclusive": start + 86400, "start_utc": iso(start),
             "end_utc_exclusive": iso(start + 86400), "hourly_bars": len(candles),
             "zero_volume_hours": zero, "eligible": not reasons,
             "exclusion_reasons": ";".join(reasons)}
        if complete and previous is not None:
            cs = [float(previous["close"])] + [float(c["close"]) for c in candles]
            returns = [math.log(b / a) for a, b in zip(cs, cs[1:])]
            op = float(candles[0]["open"])
            cl = float(candles[-1]["close"])
            high = max(float(c["high"]) for c in candles)
            low = min(float(c["low"]) for c in candles)
            m.update({"hourly_log_realized_volatility": math.sqrt(sum(r * r for r in returns)),
                      "open_to_close_return": cl / op - 1,
                      "previous_close_to_close_return": cl / cs[0] - 1,
                      "high_low_range_return": high / low - 1,
                      "high_from_open_return": high / op - 1,
                      "low_from_open_return": low / op - 1,
                      "open_irr_per_usdt": candles[0]["open"],
                      "close_irr_per_usdt": candles[-1]["close"],
                      "volume_usdt": str(sum(Decimal(c["volume_usdt"]) for c in candles))})
        metrics.append(m)
        if not reasons:
            eligible.append(m)
    eligible.sort(key=lambda d: (d["hourly_log_realized_volatility"], d["local_date"]))
    n = len(eligible)
    for i, m in enumerate(eligible):
        m["volatility_rank"] = i + 1
        m["empirical_percentile"] = i / (n - 1)
    # Fixed order-statistic rule, independent of subsequent strategy losses.
    # Nearest order statistic to p10 and its next neighbor, middle pair, top two.
    p10 = math.floor(.10 * (n - 1) + .5)
    indices = {"calm": [p10, p10 + 1],
               "median": [(n - 1) // 2, (n - 1) // 2 + 1],
               "high": [n - 2, n - 1]}
    selected = [{**eligible[i], "regime": regime} for regime, ix in indices.items() for i in ix]
    fields = list(dict.fromkeys(key for m in metrics for key in m))
    metric_artifact = write_csv(output / "daily_metrics.csv", fields, metrics)
    selection = {"source_hourly_csv": str(source), "source_hourly_csv_sha256": sha(source),
                 "all_local_date_groups": len(metrics), "complete_local_days": sum(m["hourly_bars"] == 24 for m in metrics),
                 "eligible_days": n, "excluded_days": len(metrics) - n,
                 "eligibility": "Exactly 24 consecutive hourly bars from local midnight; positive reported volume on every bar and preceding hour, and an observed preceding-hour close.",
                 "volatility_definition": "sqrt(sum_{h=1..24}(ln(C_h / C_(h-1)))^2); C_0 is the preceding-hour close. Dimensionless, not annualized.",
                 "selection_rule": "Sort eligible days ascending by hourly log realized volatility, ties by local_date. Calm: indices floor(.10*(n-1)+.5) and +1 (zero-based); median: floor((n-1)/2) and +1; high: n-2 and n-1. No strategy results enter selection.",
                 "selection_indices_zero_based": indices, "metrics": metric_artifact,
                 "direction_convention": "Positive IRR/USDT open-to-close return means rial depreciation. Token USDT parity is reciprocal, so parity return = 1/(1+return)-1.",
                 "selected_days": selected}
    write_json(output / "selected_days.json", selection)
    write_csv(output / "selected_days.csv", ["regime"] + fields, selected)
    return selected, selection


def validate_candle(prices: list[Decimal], volume: Decimal) -> None:
    op, hi, lo, cl = prices
    if min(prices) <= 0 or not lo <= min(op, cl) <= max(op, cl) <= hi or volume < 0:
        raise ValueError(f"Invalid OHLCV: {prices}, {volume}")


def coverage(candles: list[dict], start: int, end: int, interval: int, volume_key: str) -> dict:
    ts = [int(c["timestamp"]) for c in candles]
    missing = sorted(set(range(start, end, interval)) - set(ts))
    diffs = Counter(b - a for a, b in zip(ts, ts[1:]))
    longest_zero = current_zero = 0
    previous_ts = None
    for c in candles:
        if Decimal(c[volume_key]) == 0:
            current_zero = current_zero + 1 if previous_ts is not None and c["timestamp"] - previous_ts == interval else 1
            longest_zero = max(longest_zero, current_zero)
        else:
            current_zero = 0
        previous_ts = c["timestamp"]
    return {"requested_from_utc_inclusive": iso(start), "requested_to_utc_exclusive": iso(end),
            "expected_bars": (end - start) // interval, "actual_bars": len(candles),
            "missing_bars": len(missing), "missing_timestamps": missing,
            "zero_volume_bars": sum(Decimal(c[volume_key]) == 0 for c in candles),
            "flat_ohlc_bars": sum(len({c[k] for k in ("open", "high", "low", "close")}) == 1 for c in candles),
            "longest_consecutive_zero_volume_bars": longest_zero,
            "consecutive_timestamp_differences_seconds": dict(sorted(diffs.items())),
            "all_timestamp_alignment_valid": all(t % interval == 0 for t in ts),
            "first_candle_open_utc": iso(ts[0]) if ts else None,
            "last_candle_open_utc": iso(ts[-1]) if ts else None,
            "last_candle_end_utc_exclusive": iso(ts[-1] + interval) if ts else None}


def compare_hourly(source: Path, minute_sources: list[dict], output: Path) -> dict:
    hourly = {int(c["timestamp"]): c for c in csv.DictReader(source.open())}
    comparisons = []
    differences = []
    for entry in minute_sources:
        by_hour: dict = defaultdict(list)
        for c in csv.DictReader(Path(entry["csv_file"]).open()):
            ts = int(c["timestamp"])
            by_hour[ts - ts % HOUR].append(c)
        matches = complete = 0
        for ts, candles in sorted(by_hour.items()):
            if len(candles) != 60 or ts not in hourly:
                continue
            complete += 1
            agg = {"open": Decimal(candles[0]["open"]), "close": Decimal(candles[-1]["close"]),
                   "high": max(Decimal(c["high"]) for c in candles),
                   "low": min(Decimal(c["low"]) for c in candles),
                   "volume_usdt": sum(Decimal(c["volume_usdt"]) for c in candles)}
            different = {key: {"minute_aggregate": str(value), "existing_hourly": hourly[ts][key]}
                         for key, value in agg.items() if value != Decimal(hourly[ts][key])}
            if different:
                differences.append({"timestamp": ts, "datetime_utc": iso(ts), "differences": different})
            else:
                matches += 1
        comparisons.append({"local_date": entry["local_date"], "complete_minute_hours_comparable": complete,
                            "exact_ohlcv_hour_matches": matches, "differing_hours": complete - matches})
    fields_differing = Counter(key for d in differences for key in d["differences"])
    result = {"comparison": "Aggregate60 observed one-minute bars to each existing hourly candle using first open/max high/min low/last close/summed volume; exact Decimal comparison.",
              "per_day": comparisons, "differences": differences,
              "differing_hour_count_by_field": dict(fields_differing),
              "interpretation": "Disagreement can reflect later history revision or exchange aggregation differences; original responses are retained and never silently reconciled."}
    path = output / "hourly_aggregation_comparison.json"
    write_json(path, result)
    return {"file": str(path), "sha256": sha(path), "differing_hours": len(differences),
            "differing_hour_count_by_field": dict(fields_differing), "per_day": comparisons}


def fetch_day(day: dict, output: Path, offline: bool, refresh: bool) -> dict:
    start, end = day["start_timestamp"], day["end_timestamp_exclusive"]
    params = {"symbol": "USDTTMN", "resolution": "1", "from": start, "to": end - 1}
    url = WALLEX + "?" + urllib.parse.urlencode(params)
    payload, meta = request_json(url, output / "raw" / f"IRR_1m_{day['local_date']}.json", offline=offline, refresh=refresh)
    if payload.get("s") != "ok":
        raise ValueError(f"Minute history unavailable for {day['local_date']}: {payload}")
    keys = ("t", "o", "h", "l", "c", "v")
    if len({len(payload[k]) for k in keys}) != 1:
        raise ValueError("Wallex parallel arrays differ in length")
    candles = []
    for raw in zip(*(payload[k] for k in keys)):
        ts = int(raw[0])
        prices = [Decimal(str(v)) * 10 for v in raw[1:5]]
        volume = Decimal(str(raw[5]))
        validate_candle(prices, volume)
        if not start <= ts < end or ts % 60:
            raise ValueError(f"Out-of-window/unaligned minute timestamp: {ts}")
        candles.append(dict(zip(FIELDS, [ts, iso(ts), *(str(v) for v in prices), str(volume)])))
    candles.sort(key=lambda c: c["timestamp"])
    if len({c["timestamp"] for c in candles}) != len(candles):
        raise ValueError("Duplicate minute timestamps")
    cov = coverage(candles, start, end, 60, "volume_usdt")
    # Hourly output ignored resolution would have spacing3600 and no off-hour opens.
    actual_minute = cov["consecutive_timestamp_differences_seconds"].get(60, 0) > 0
    if not actual_minute:
        raise ValueError(f"Requested minute resolution not verified: {cov}")
    for c in candles:
        c["candle_end_timestamp"] = c["timestamp"] + 60
        c["candle_end_utc_exclusive"] = iso(c["timestamp"] + 60)
    artifact = write_csv(output / f"IRR_1m_{day['local_date']}.csv", FIELDS + ["candle_end_timestamp", "candle_end_utc_exclusive"], candles)
    minute_prices = [float(candles[0]["open"])] + [float(c["close"]) for c in candles]
    minute_rv = math.sqrt(sum(math.log(b / a) ** 2 for a, b in zip(minute_prices, minute_prices[1:])))
    print(f"{day['local_date']}: {len(candles)} minute bars, {cov['missing_bars']} missing, {cov['zero_volume_bars']} zero-volume", flush=True)
    return {"local_date": day["local_date"], "regime": day["regime"], "exchange": "Wallex",
            "symbol": "USDTTMN", "requested_resolution": "1", "verified_interval_seconds": 60,
            "normalization": "Native TMN OHLC multiplied by10 to IRR/USDT; native USDT volume unchanged.",
            "price_units": "IRR per USDT", "volume_units": "USDT",
            "minute_log_realized_volatility": minute_rv,
            "minute_rv_initial_mark": "First minute open, followed by all1440 minute closes; no preceding-minute request.",
            **artifact, **cov, "requests": [meta]}


def fetch_eth(start: int, end: int, output: Path, offline: bool, refresh: bool) -> dict:
    candles = []
    requests = []
    for cursor in range(start, end, 1000 * HOUR):
        chunk_end = min(cursor + 1000 * HOUR, end)
        params = {"symbol": "ETHUSDT", "interval": "1h", "startTime": cursor * 1000,
                  "endTime": chunk_end * 1000 - 1, "limit": 1000}
        url = BINANCE + "?" + urllib.parse.urlencode(params)
        payload, meta = request_json(url, output / "raw" / f"ETH_USDT_1h_{cursor}_{chunk_end}.json", offline=offline, refresh=refresh)
        if not isinstance(payload, list):
            raise ValueError(f"Binance returned error: {payload}")
        requests.append(meta)
        for raw in payload:
            ts = int(raw[0]) // 1000
            prices = [Decimal(v) for v in raw[1:5]]
            volume = Decimal(raw[5])
            validate_candle(prices, volume)
            if not cursor <= ts < chunk_end or ts % HOUR or int(raw[6]) != (ts + HOUR) * 1000 - 1:
                raise ValueError(f"Unexpected Binance timestamp: {raw}")
            candles.append(dict(zip(["timestamp", "datetime_utc", "open", "high", "low", "close", "volume_eth", "quote_volume_usdt", "candle_end_timestamp", "candle_end_utc_exclusive"],
                                    [ts, iso(ts), *raw[1:6], raw[7], ts + HOUR, iso(ts + HOUR)])))
    if len({c["timestamp"] for c in candles}) != len(candles):
        raise ValueError("Duplicate ETH timestamps")
    fields = ["timestamp", "datetime_utc", "open", "high", "low", "close", "volume_eth", "quote_volume_usdt", "candle_end_timestamp", "candle_end_utc_exclusive"]
    artifact = write_csv(output / "ETH_USDT_1h.csv", fields, candles)
    return {"exchange": "Binance spot", "symbol": "ETHUSDT", "interval_seconds": HOUR,
            "price_units": "USDT per ETH", "volume_units": "ETH", **artifact,
            **coverage(candles, start, end, HOUR, "volume_eth"), "requests": requests,
            "documentation_url": "https://developers.binance.com/docs/binance-spot-api-docs/rest-api/market-data-endpoints#klinecandlestick-data"}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=Path("research/fx_inputs/IRR_1h.csv"))
    parser.add_argument("--output", type=Path, default=Path("research/fxswap_data"))
    parser.add_argument("--offline", action="store_true")
    parser.add_argument("--refresh", action="store_true")
    args = parser.parse_args()
    if args.offline and args.refresh:
        parser.error("--offline and --refresh are mutually exclusive")
    args.output.mkdir(parents=True, exist_ok=True)
    selected, selection = select_days(args.source, args.output)
    source_manifest = json.loads((args.source.parent / "manifest.json").read_text())
    irr_source = next(s for s in source_manifest["sources"] if s["currency"] == "IRR")
    start = int(datetime.fromisoformat(irr_source["requested_from_utc_inclusive"].replace("Z", "+00:00")).timestamp())
    end = int(datetime.fromisoformat(irr_source["requested_to_utc_exclusive"].replace("Z", "+00:00")).timestamp())
    with ThreadPoolExecutor(max_workers=4) as pool:
        day_futures = [pool.submit(fetch_day, day, args.output, args.offline, args.refresh) for day in selected]
        eth_future = pool.submit(fetch_eth, start, end, args.output, args.offline, args.refresh)
        day_sources = [future.result() for future in day_futures]
        eth_source = eth_future.result()
    probe_day = selected[-1]
    params = {"symbol": "USDTTMN", "resolution": "5", "from": probe_day["start_timestamp"], "to": probe_day["end_timestamp_exclusive"] - 1}
    probe, meta = request_json(WALLEX + "?" + urllib.parse.urlencode(params), args.output / "raw" / "IRR_5m_resolution_probe.json", offline=args.offline, refresh=args.refresh)
    manifest = {"schema_version": 1, "generated_at_utc": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
                "timestamp_convention": "Bar open, Unix seconds UTC. Closes become known only at candle_end_timestamp (exclusive). No within-bar path or fills are observed.",
                "selection": selection,
                "selection_artifacts": [{"file": str(args.output / name), "sha256": sha(args.output / name)}
                                        for name in ("selected_days.csv", "selected_days.json", "daily_metrics.csv")],
                "hourly_source_manifest": str(args.source.parent / "manifest.json"),
                "hourly_source_manifest_sha256": sha(args.source.parent / "manifest.json"),
                "minute_sources": day_sources, "eth_collateral_source": eth_source,
                "minute_vs_existing_hourly": compare_hourly(args.source, day_sources, args.output),
                "resolution_probes": [{"requested_resolution_minutes": 5, "response": probe, "request": meta}],
                "limitations": ["No interpolation, forward fill, or synthetic ticks. Supplied zero-volume candles remain supplied zero-volume candles.",
                                "Quiet-day eligibility rejects zero-volume hours; minute bars can still include no-trade minutes, disclosed per day.",
                                "Wallex is a single exchange spot USDT/TMN feed, not an executable cross-venue FX composite or official USD fix.",
                                "OHLC bars cannot establish high/low ordering, spreads, order-book depth, actual fills, slippage, or continuous oracle compliance.",
                                "ETH hourly marks do not resolve within-hour collateral/liquidation paths; USDT/USD parity is an additional modeling assumption.",
                                "Native one-minute history is fetched for selected days only; 5-minute resolution was rejected by the exchange."]}
    write_json(args.output / "manifest.json", manifest)
    print(f"Selection: {selection['eligible_days']} eligible days; ETH: {eth_source['actual_bars']} hourly bars", flush=True)


if __name__ == "__main__":
    main()
