#!/usr/bin/env python3
"""Fetch and preserve public spot hourly candles for IRR/TRY/ARS per USDT.

No API keys or third-party Python packages are required. Prices are exchange
prices for USDT, not an official USD fixing. Missing hours remain missing.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import csv
import hashlib
import json
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path

UTC = timezone.utc
HOUR = 3600
SOURCES = {
    "IRR": {
        "exchange": "Wallex",
        "symbol": "USDTTMN",
        "base_asset": "USDT",
        "source_quote_asset": "TMN",
        "price_multiplier": "10",
        "documentation_url": "https://api-docs.wallex.ir/",
        "endpoint": "https://api.wallex.ir/v1/udf/history",
    },
    "TRY": {
        "exchange": "Binance spot",
        "symbol": "USDTTRY",
        "base_asset": "USDT",
        "source_quote_asset": "TRY",
        "price_multiplier": "1",
        "documentation_url": "https://developers.binance.com/docs/binance-spot-api-docs/rest-api/market-data-endpoints#klinecandlestick-data",
        "endpoint": "https://api.binance.com/api/v3/klines",
    },
    "ARS": {
        "exchange": "Binance spot",
        "symbol": "USDTARS",
        "base_asset": "USDT",
        "source_quote_asset": "ARS",
        "price_multiplier": "1",
        "documentation_url": "https://developers.binance.com/docs/binance-spot-api-docs/rest-api/market-data-endpoints#klinecandlestick-data",
        "endpoint": "https://api.binance.com/api/v3/klines",
    },
}


def iso(ts: int) -> str:
    return datetime.fromtimestamp(ts, UTC).isoformat().replace("+00:00", "Z")


def now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def request_json(url: str, raw_path: Path) -> tuple[object, dict]:
    """Save exact response bytes and request provenance, retrying only failures."""
    request = urllib.request.Request(url, headers={"User-Agent": "Tomax-FX-Research/1.0"})
    for attempt in range(3):
        try:
            with urllib.request.urlopen(request, timeout=45) as response:
                payload = response.read()
                headers = dict(response.headers)
                status = response.status
            break
        except (urllib.error.URLError, TimeoutError):
            if attempt == 2:
                raise
            time.sleep(attempt + 1)
    result = json.loads(payload)
    raw_path.parent.mkdir(parents=True, exist_ok=True)
    raw_path.write_bytes(payload)
    metadata = {
        "url": url,
        "retrieved_at_utc": now(),
        "http_status": status,
        "http_date": headers.get("Date", headers.get("date")),
        "content_type": headers.get("Content-Type", headers.get("content-type")),
        "raw_file": str(raw_path),
        "bytes": len(payload),
        "sha256": hashlib.sha256(payload).hexdigest(),
    }
    return result, metadata


def gaps(missing: list[int]) -> list[dict]:
    groups: list[dict] = []
    for ts in missing:
        if groups and groups[-1]["last_missing_timestamp"] + HOUR == ts:
            groups[-1]["last_missing_timestamp"] = ts
            groups[-1]["hours"] += 1
        else:
            groups.append({"first_missing_timestamp": ts, "last_missing_timestamp": ts, "hours": 1})
    return [
        {"first_missing_utc": iso(g["first_missing_timestamp"]),
         "last_missing_utc": iso(g["last_missing_timestamp"]), "hours": g["hours"]}
        for g in groups
    ]


def fetch_currency(currency: str, start: int, end: int, output: Path) -> dict:
    source = SOURCES[currency]
    multiplier = Decimal(source["price_multiplier"])
    cursor = start
    candles: dict[int, list] = {}
    requests: list[dict] = []
    duplicate_count = 0
    metadata_url = (
        "https://api.wallex.ir/v1/markets" if currency == "IRR" else
        "https://api.binance.com/api/v3/exchangeInfo?" +
        urllib.parse.urlencode({"symbol": source["symbol"]})
    )
    market_info, metadata = request_json(metadata_url, output / "raw" / f"{currency}_market.json")
    requests.append(metadata)
    if currency == "IRR":
        market = market_info["result"]["symbols"][source["symbol"]]
    else:
        market = market_info["symbols"][0]
    if market["baseAsset"] != "USDT" or market["quoteAsset"] != source["source_quote_asset"]:
        raise ValueError(f"Unexpected market assets for {currency}: {market}")

    while cursor < end:
        # Wallex takes seconds; Binance takes milliseconds and has a 1000-bar cap.
        span = 30 * 86400 if currency == "IRR" else 1000 * HOUR
        chunk_end = min(cursor + span, end)
        params = (
            {"symbol": source["symbol"], "resolution": "60", "from": cursor, "to": chunk_end - 1}
            if currency == "IRR" else
            {"symbol": source["symbol"], "interval": "1h", "startTime": cursor * 1000,
             "endTime": chunk_end * 1000 - 1, "limit": 1000}
        )
        url = source["endpoint"] + "?" + urllib.parse.urlencode(params)
        payload, metadata = request_json(url, output / "raw" / f"{currency}_{cursor}_{chunk_end}.json")
        if currency == "IRR":
            if payload.get("s") not in ("ok", "no_data"):
                raise ValueError(f"Wallex error response: {payload}")
            lengths = {len(payload.get(key, [])) for key in ("t", "o", "h", "l", "c", "v")}
            if len(lengths) != 1:
                raise ValueError("Wallex candle arrays have different lengths")
            raw_rows = list(zip(*(payload.get(key, []) for key in ("t", "o", "h", "l", "c", "v"))))
        else:
            if not isinstance(payload, list):
                raise ValueError(f"Binance error response: {payload}")
            raw_rows = [(int(row[0]) // 1000, *row[1:6]) for row in payload]
        metadata["returned_candles"] = len(raw_rows)
        requests.append(metadata)
        for raw in raw_rows:
            ts = int(raw[0])
            if not start <= ts < end:
                raise ValueError(f"API returned out-of-window candle {ts} for {currency}")
            if ts % HOUR:
                raise ValueError(f"Non-hourly candle {ts} for {currency}")
            prices = [Decimal(str(x)) * multiplier for x in raw[1:5]]
            op, hi, lo, cl = prices
            volume = Decimal(str(raw[5]))
            if min(prices) <= 0 or not lo <= min(op, cl) <= max(op, cl) <= hi or volume < 0:
                raise ValueError(f"Invalid OHLCV candle for {currency}: {raw}")
            normalized = [ts, iso(ts), *(str(x) for x in prices), str(volume)]
            if ts in candles:
                duplicate_count += 1
                if candles[ts] != normalized:
                    raise ValueError(f"Conflicting duplicate candle for {currency} at {ts}")
            candles[ts] = normalized
        cursor = chunk_end

    csv_path = output / f"{currency}_1h.csv"
    with csv_path.open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["timestamp", "datetime_utc", "open", "high", "low", "close", "volume_usdt"])
        writer.writerows(candles[t] for t in sorted(candles))
    missing = sorted(set(range(start, end, HOUR)) - candles.keys())
    ordered = sorted(candles)
    return {
        "currency": currency,
        **source,
        "normalized_quote_asset": currency,
        "price_units": f"{currency} per USDT",
        "volume_units": "USDT",
        "normalization": "OHLC multiplied by 10: 1 Toman = 10 Iranian rials; volume unchanged" if currency == "IRR" else "No conversion",
        "market_metadata": {key: market.get(key) for key in ("symbol", "baseAsset", "quoteAsset", "status", "enName", "enQuoteAsset") if key in market},
        "interval_seconds": HOUR,
        "csv_file": str(csv_path),
        "csv_sha256": hashlib.sha256(csv_path.read_bytes()).hexdigest(),
        "requested_from_utc_inclusive": iso(start),
        "requested_to_utc_exclusive": iso(end),
        "expected_hourly_candles": (end - start) // HOUR,
        "actual_hourly_candles": len(candles),
        "first_candle_open_utc": iso(ordered[0]) if ordered else None,
        "last_candle_open_utc": iso(ordered[-1]) if ordered else None,
        "last_candle_end_utc_exclusive": iso(ordered[-1] + HOUR) if ordered else None,
        "missing_hourly_candles": len(missing),
        "missing_intervals": gaps(missing),
        "identical_duplicate_candles": duplicate_count,
        "zero_volume_candles": sum(Decimal(row[6]) == 0 for row in candles.values()),
        "requests": requests,
        "limitations": [
            "Public exchange spot transactions; not an official USD central-bank fixing, bank transfer quote, or FX composite.",
            "USDT is the numeraire. Treating these prices as currency per USD additionally assumes USDT/USD parity.",
            "Hourly OHLC does not identify within-hour order of high and low, tick-path crossings, spreads, execution, or slippage.",
            "Missing candles are left missing, with no interpolation or forward fill.",
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--end-date", default="2026-10-21", help="Exclusive UTC date (YYYY-MM-DD)")
    parser.add_argument("--days", type=int, default=180)
    parser.add_argument("--output", type=Path, default=Path("research/fx_inputs"))
    args = parser.parse_args()
    end_dt = datetime.strptime(args.end_date, "%Y-%m-%d").replace(tzinfo=UTC)
    if args.days <= 0 or end_dt > datetime.now(UTC):
        parser.error("days must be positive and end date must not be in the future")
    start_dt = end_dt - timedelta(days=args.days)
    args.output.mkdir(parents=True, exist_ok=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        futures = {
            currency: pool.submit(fetch_currency, currency, int(start_dt.timestamp()), int(end_dt.timestamp()), args.output)
            for currency in SOURCES
        }
        entries = [future.result() for future in futures.values()]
    manifest = {
        "schema_version": 1,
        "generated_at_utc": now(),
        "client_date": args.end_date,
        "requested_days": args.days,
        "timestamp_convention": "Candle open, Unix seconds, UTC; end date exclusive. CSV preserves missing hours.",
        "sources": entries,
    }
    (args.output / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    for entry in entries:
        print(f"{entry['currency']}: {entry['actual_hourly_candles']} candles, {entry['missing_hourly_candles']} missing; "
              f"{entry['first_candle_open_utc']} through {entry['last_candle_open_utc']}")


if __name__ == "__main__":
    main()
