#!/usr/bin/env python3
"""Smoke real verified FXSwap bytecode in an isolated local EVM.

Install requirements-evm.txt in a separate virtualenv, then run with --fetch
once, or supply already downloaded Sourcify/Blockscout metadata files. Network
retrieval is read-only metadata; execution never uses RPC or a chain fork.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from evm import FXEVMPool
from evm.artifacts import DEFAULT_CACHE, SPECS, digest, load_artifacts
from evm.fxswap import WAD, units
from model.fxswap import FXPool


def check(artifacts: dict) -> dict:
    """Raise on a mismatch, revert failure, or conservation error."""
    start = 1_800_000_000
    exact = FXEVMPool(timestamp=start, artifacts=artifacts)
    approx = FXPool(timestamp=start)
    comparisons = []

    def close(name, actual, expected):
        if isinstance(actual, (list, tuple)):
            for i, (a, b) in enumerate(zip(actual, expected, strict=True)):
                close(f"{name}[{i}]", a, b)
            return
        error = abs(actual - expected)
        assert math.isclose(actual, expected, rel_tol=2e-10, abs_tol=2e-8), (name, actual, expected)
        comparisons.append({"name": name, "evm": actual, "float": expected, "absolute_error": error})

    def compare_state(name):
        exact.assert_conservation()
        for field in ("balances", "D", "total_supply", "donation_shares", "price_scale", "virtual_price"):
            close(f"{name}.{field}", getattr(exact, field), getattr(approx, field))

    def common(name, method, *args, **kwargs):
        result = getattr(exact, method)(*args, **kwargs)
        close(name, result, getattr(approx, method)(*args, **kwargs))
        compare_state(name)
        return result

    common("initial_liquidity", "add_liquidity", 10000, 10000, start)
    common("swap_external_in", "swap", 0, 123.45, start + 1)
    common("swap_own_in", "swap", 1, 77.25, start + 1800)
    before_quote = exact.state_wei()
    close("quote", exact.quote(0, 50), approx.quote(0, 50))
    assert exact.state_wei() == before_quote, "quote must revert all simulated changes"
    common("imbalanced_add", "add_liquidity", 50, 80, start + 1801)
    common("refuel_donation", "add_liquidity", 250, 500, start + 1802, donation=True)
    assert exact.donation_shares > 0
    common("add_with_donation_buffer", "add_liquidity", 100, 100, start + 1803)
    common("aged_swap_external_in", "swap", 0, 400, start + 4 * 86400)
    common("aged_swap_own_in", "swap", 1, 300, start + 4 * 86400 + 1)
    common("proportional_withdraw", "withdraw", 100, start + 4 * 86400 + 2)

    # These paths are executed from genuine source even if absent in the float
    # port. Both trigger the source's internal admin-fee routine.
    ts = start + 4 * 86400 + 3
    before = exact.wallet_balances_wei()
    before_lp = exact.lp_balance_wei()
    before_admin = exact.wallet_balances_wei(exact.fee_receiver)
    quote = exact.quote_withdraw_one_coin(100, 0, ts)
    one_coin = exact.withdraw_one_coin(100, 0, ts)
    after = exact.wallet_balances_wei()
    assert after[1] == before[1]
    assert after[0] > before[0]
    assert exact.lp_balance_wei() == before_lp - units(100)
    assert one_coin == quote
    exact.assert_conservation()
    one_coin_receipt = {
        "lp_burned_wei": before_lp - exact.lp_balance_wei(),
        "received_wei": [after[i] - before[i] for i in range(2)],
        "admin_received_wei": [a-b for a, b in zip(exact.wallet_balances_wei(exact.fee_receiver), before_admin)],
        "transaction_quote_matches": True,
    }
    assert sum(one_coin_receipt["admin_received_wei"]) > 0, "exercise internal admin fee claim"

    before = exact.wallet_balances_wei()
    before_lp = exact.lp_balance_wei()
    other = exact.withdraw_fixed_out(100, 0, 50, ts + 1)
    after = exact.wallet_balances_wei()
    assert after[0] - before[0] == units(50)
    assert after[1] > before[1]
    assert exact.lp_balance_wei() == before_lp - units(100)
    exact.assert_conservation()
    fixed_receipt = {"lp_burned_wei": before_lp - exact.lp_balance_wei(),
                     "received_wei": [after[i] - before[i] for i in range(2)],
                     "other_output_tokens": other}

    # A finite wallet cannot sell more than it owns. Reverts also must roll back
    # transfers, invariant changes, supply changes, and fee claims.
    empty_trader = exact.new_account("finite-wallet", (1, 0))
    before = exact.state_wei()
    trader_before = exact.wallet_balances_wei(empty_trader)
    try:
        exact.swap(0, 2, ts + 1, account=empty_trader)
    except exact.boa.BoaError:
        pass
    else:
        raise AssertionError("insufficient wallet swap unexpectedly succeeded")
    assert exact.state_wei() == before
    assert exact.wallet_balances_wei(empty_trader) == trader_before

    try:
        exact.swap(0, 1, ts + 1, minimum=1000)
    except exact.boa.BoaError:
        pass
    else:
        raise AssertionError("impossible slippage minimum unexpectedly succeeded")
    assert exact.state_wei() == before
    exact.assert_conservation()

    # A controller can reject a composite withdrawal+swap after checking its
    # resulting health. Roll back every underlying token transfer and the clock.
    state_before = exact.state_wei()
    time_before = exact.env.timestamp
    gas_before = exact.gas_used
    checkpoint = exact.begin_snapshot()
    exact.withdraw(10, ts + 2)
    exact.swap(1, 10, ts + 2)
    assert exact.gas_used > gas_before
    exact.revert_snapshot(checkpoint)
    assert exact.state_wei() == state_before
    assert exact.env.timestamp == time_before
    assert exact.gas_used == gas_before
    try:
        with exact.atomic():
            exact.swap(0, 1, ts + 2)
            raise ValueError("simulated controller health-check rejection")
    except ValueError:
        pass
    assert exact.state_wei() == state_before
    assert exact.env.timestamp == time_before
    assert exact.gas_used == gas_before

    # Exit all real LP. The source sends donation-only leftovers to the factory
    # fee receiver, so the last LP cannot extract the donation buffer.
    with exact.context():
        all_lp = exact.contract.balanceOf(exact.owner)
        old_supply = exact.contract.totalSupply()
        old_balances = [exact.contract.balances(i) for i in range(2)]
        expected = [b * all_lp // old_supply for b in old_balances]
        admin_before = exact.wallet_balances_wei(exact.fee_receiver)
        outputs = exact.contract.remove_liquidity(all_lp, [0, 0])
        assert list(outputs) == expected
        assert exact.contract.totalSupply() == 0
        assert exact.contract.donation_shares() == 0
        assert exact.contract.D() == 0
    exact.assert_conservation()
    leftovers = [a-b for a, b in zip(exact.wallet_balances_wei(exact.fee_receiver), admin_before)]
    assert any(leftovers)

    # Material displacement makes donation-share consumption observable.
    burn_pool = FXEVMPool(timestamp=start, artifacts=artifacts)
    burn_float = FXPool(timestamp=start)
    for p in (burn_pool, burn_float):
        p.add_liquidity(10000, 10000, start)
        p.add_liquidity(1000, 1000, start + 1, donation=True)
        p.swap(1, 5000, start + 2)
    donation_before = burn_pool.donation_shares
    for j in range(1, 5):
        close(f"refuel_burn.swap[{j}]", burn_pool.swap(1, 1, start + 7 * 86400 + j),
              burn_float.swap(1, 1, start + 7 * 86400 + j))
    close("refuel_burn.donation_shares", burn_pool.donation_shares, burn_float.donation_shares)
    close("refuel_burn.price_scale", burn_pool.price_scale, burn_float.price_scale)
    assert 0 < burn_pool.donation_shares < donation_before
    burn_pool.assert_conservation()

    source_checks = {}
    for kind, filename in (("pool", "Twocrypto.vy"), ("math", "StableswapMath.vy")):
        source = ROOT / "research" / "fxswap_source" / filename
        if source.exists():
            actual_hash = digest(source.read_bytes())
            assert actual_hash == SPECS[kind]["source_sha256"], f"pinned {filename} source changed"
            source_checks[filename] = actual_hash

    provenance = exact.provenance()
    assert provenance["pool_version"] == SPECS["pool"]["version"]
    assert provenance["math_version"] == SPECS["math"]["version"]
    assert provenance["local_math_runtime_sha256"] == SPECS["math"]["runtime_sha256"]
    return {
        "status": "passed",
        "coverage": ["initial/imbalanced LP add", "both swap directions", "transaction-snapshot quote",
                     "donation/refuel", "aged donation release/recentering", "proportional withdrawal",
                     "one-coin withdrawal", "fixed-output withdrawal", "automatic admin-fee claim",
                     "finite-wallet revert", "slippage revert", "controller composite rollback",
                     "refuel shares consumed by recentering", "last-LP donation cleanup"],
        "float_comparison_count": len(comparisons),
        "max_float_absolute_error": max(x["absolute_error"] for x in comparisons),
        "float_tolerance": {"relative": 2e-10, "absolute_tokens": 2e-8},
        "float_comparisons": comparisons,
        "one_coin_withdrawal": one_coin_receipt,
        "fixed_out_withdrawal": fixed_receipt,
        "last_lp_leftover_to_admin_wei": leftovers,
        "refuel_shares_burned_tokens": donation_before - burn_pool.donation_shares,
        "local_source_hashes": source_checks,
        "wrapper_execution_gas_used": exact.gas_used,
        "gas_note": "local execution gas; excludes intrinsic transaction/calldata gas and raw-contract calls",
        "final_state_wei": exact.state_wei(),
        "provenance": provenance,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fetch", action="store_true", help="download pinned public verification metadata")
    parser.add_argument("--cache-dir", type=Path, default=DEFAULT_CACHE)
    parser.add_argument("--pool-artifact", type=Path)
    parser.add_argument("--math-artifact", type=Path)
    parser.add_argument("--output", type=Path, help="optional detailed JSON report")
    args = parser.parse_args()
    artifacts = load_artifacts(args.cache_dir, fetch=args.fetch,
                              pool_artifact=args.pool_artifact, math_artifact=args.math_artifact)
    report = check(artifacts)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: report[k] for k in ("status", "coverage", "float_comparison_count",
                                             "max_float_absolute_error")}, indent=2))


if __name__ == "__main__":
    main()
