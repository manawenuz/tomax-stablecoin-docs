"""Standalone research plots of observed states, including pre-response gaps."""
from pathlib import Path
import csv,json
from datetime import datetime,timezone
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]


def main():
    fig,axes=plt.subplots(2,3,figsize=(13,7.5),layout='constrained')
    colors={'observed_before_keeper':'#c27b2e','after_actors':'#a83440','after_keeper':'#127c72'}
    for j,(name,label) in enumerate([('calm_train','Calm training'),('volatile_train','Volatile training'),('volatile_holdout','Volatile validation')]):
        with (ROOT/f'results/sandbox-trace-{name}_10000.csv').open() as f:rows=list(csv.DictReader(f))
        for phase in colors:
            r=[x for x in rows if x['phase']==phase]
            t=[datetime.fromtimestamp(int(x['t']),timezone.utc) for x in r]
            axes[0,j].plot(t,[100*float(x['error']) for x in r],color=colors[phase],lw=.9,
                          label=phase.replace('_',' '),alpha=.85)
        axes[0,j].axhspan(-3,3,color='#127c72',alpha=.07)
        for y in (-3,3):axes[0,j].axhline(y,color='#727a84',lw=.7,ls='--')
        axes[0,j].set_title(label,loc='left',fontweight='bold');axes[0,j].set_ylabel('Price / parity − 1 (%)')
        post=[x for x in rows if x['phase']=='after_keeper'];t=[datetime.fromtimestamp(int(x['t']),timezone.utc) for x in post]
        start=10000+float(json.loads((ROOT/'results/sandbox.json').read_text())['selection']['config']['reserve_multiple'])*10000
        axes[1,j].plot(t,[float(x['protocol_equity'])-start for x in post],color='#243f75',lw=1.6,label='Treasury marked P&L')
        axes[1,j].axhline(0,color='#727a84',lw=.7);axes[1,j].set_ylabel('Treasury equity change (USDT)')
        for ax in axes[:,j]:
            ax.grid(axis='y',alpha=.15);ax.spines[['top','right']].set_visible(False)
            ax.tick_params(axis='x',labelrotation=30);ax.xaxis.set_major_locator(matplotlib.dates.DayLocator(interval=4))
            ax.xaxis.set_major_formatter(matplotlib.dates.DateFormatter('%b %d'))
    axes[0,0].legend(fontsize=7,loc='best');axes[1,0].legend(fontsize=8)
    fig.suptitle('Funded FXSwap keeper • 14-day observed IRR/USDT paths • $10k external seed',fontsize=15,fontweight='bold')
    fig.supxlabel('UTC • hourly observed closes; no claim about missing intrahour prices',fontsize=10)
    dest=ROOT/'docs/assets';dest.mkdir(exist_ok=True)
    fig.savefig(dest/'sandbox-fortnights.png',dpi=170)
    fig.savefig(dest/'sandbox-fortnights.pdf')
    print(dest/'sandbox-fortnights.png')


if __name__=='__main__':main()
