#!/usr/bin/env python3
"""Archive three disjoint 14-day native-minute IRR/USDT replay windows.

Window choice uses only the previously archived hourly market path, never
strategy outputs. Python standard library only; --offline verifies and replays
the archived inputs and raw HTTP responses without making network requests.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
import csv
from datetime import datetime, timedelta, timezone
from decimal import Decimal
import hashlib
import http.client
import json
import math
from pathlib import Path
import shutil
import time
import urllib.error
import urllib.parse
import urllib.request
from zoneinfo import ZoneInfo

UTC = timezone.utc
LOCAL = ZoneInfo("Asia/Tbilisi")
HOUR = 3600
DAY = 86400
WINDOW = 14 * DAY
WALLEX = "https://api.wallex.ir/v1/udf/history"
FIELDS = ["timestamp", "datetime_utc", "open", "high", "low", "close", "volume_usdt",
          "candle_end_timestamp", "candle_end_utc_exclusive"]


def iso(ts: int) -> str:
    return datetime.fromtimestamp(ts, UTC).isoformat().replace("+00:00", "Z")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def write_csv(path: Path, fields: list[str], rows: list[dict]) -> dict:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows({k: row.get(k, "") for k in fields} for row in rows)
    return {"csv_file": str(path), "csv_sha256": sha(path), "rows": len(rows)}


def read_csv(path: Path) -> list[dict]:
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def snapshot(source: Path, destination: Path, *, offline: bool, refresh: bool) -> dict:
    meta_file = destination.with_suffix(destination.suffix + ".provenance.json")
    if destination.exists() and meta_file.exists() and not refresh:
        meta = json.loads(meta_file.read_text())
        if sha(destination) != meta["sha256"]:
            raise ValueError(f"Input snapshot hash differs: {destination}")
        return meta
    if offline:
        raise ValueError(f"Offline input snapshot missing: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
    meta = {"source_file": str(source), "file": str(destination), "sha256": sha(destination),
            "copied_at_utc": datetime.now(UTC).isoformat().replace("+00:00", "Z")}
    write_json(meta_file, meta)
    return meta


def select_windows(source: Path, output: Path) -> dict:
    raw_rows = read_csv(source)
    rows = {int(r["timestamp"]): r for r in raw_rows}
    if len(rows) != len(raw_rows):
        raise ValueError("Duplicate hourly selection timestamps")
    for ts, row in rows.items():
        if ts % HOUR:
            raise ValueError("Unaligned hourly selection timestamp")
        validate([Decimal(row[k]) for k in ("open", "high", "low", "close")],
                 Decimal(row["volume_usdt"]))
    first = datetime.fromtimestamp(min(rows), LOCAL).date()
    last = datetime.fromtimestamp(max(rows) + HOUR, LOCAL).date()
    metrics = []
    for offset in range((last - first).days - 13):
        date = first + timedelta(days=offset)
        start = int(datetime.combine(date, datetime.min.time(), LOCAL).timestamp())
        end = start + WINDOW
        if start < min(rows) or end > max(rows) + HOUR:
            continue
        bars = [rows.get(t) for t in range(start, end, HOUR)]
        previous = rows.get(start - HOUR)
        missing = sum(r is None for r in bars)
        zero = sum(Decimal(r["volume_usdt"]) == 0 for r in bars if r is not None)
        reasons = []
        if missing:
            reasons.append("missing_hourly_bars")
        if zero:
            reasons.append("zero_volume_hours")
        if previous is None or Decimal(previous["volume_usdt"]) == 0:
            reasons.append("missing_or_zero_volume_preceding_hour")
        m = {"start_local_date": str(date), "end_local_date_exclusive": str(date + timedelta(days=14)),
             "timezone": "Asia/Tbilisi", "start_timestamp": start, "end_timestamp_exclusive": end,
             "start_utc": iso(start), "end_utc_exclusive": iso(end), "expected_hours": 336,
             "observed_hours": 336 - missing, "missing_hours": missing, "zero_volume_hours": zero,
             "positive_preceding_hour": previous is not None and Decimal(previous["volume_usdt"]) > 0,
             "eligible": not reasons, "exclusion_reasons": ";".join(reasons)}
        if not missing and previous is not None:
            closes = [float(previous["close"])] + [float(r["close"]) for r in bars]
            returns = [math.log(b / a) for a, b in zip(closes, closes[1:])]
            m.update({"hourly_log_realized_volatility": math.sqrt(sum(r * r for r in returns)),
                      "previous_close_to_close_return": closes[-1] / closes[0] - 1,
                      "open_to_close_return": float(bars[-1]["close"]) / float(bars[0]["open"]) - 1,
                      "high_low_range_return": max(float(r["high"]) for r in bars)
                                               / min(float(r["low"]) for r in bars) - 1})
        metrics.append(m)
    eligible = sorted((m for m in metrics if m["eligible"]),
                      key=lambda m: (m["hourly_log_realized_volatility"], m["start_timestamp"]))
    for rank, m in enumerate(eligible, 1):
        m["volatility_rank"] = rank
    if not eligible:
        raise ValueError("No strictly eligible windows; no silent quality relaxation")
    calm = eligible[0]

    def disjoint(a: dict, b: dict) -> bool:
        return a["end_timestamp_exclusive"] <= b["start_timestamp"] or b["end_timestamp_exclusive"] <= a["start_timestamp"]

    descending = sorted(eligible, key=lambda m: (-m["hourly_log_realized_volatility"], m["start_timestamp"]))
    volatile = next((m for m in descending if disjoint(m, calm)), None)
    holdout = next((m for m in descending if volatile and disjoint(m, calm) and disjoint(m, volatile)), None)
    if volatile is None or holdout is None:
        raise ValueError("Fewer than three disjoint strictly eligible windows; explicit quality decision required")
    selected = [{"id": ident, "role": role, **m} for ident, role, m in (
        ("calm_train", "training", calm), ("volatile_train", "training", volatile),
        ("volatile_holdout", "holdout", holdout))]
    fields = list(dict.fromkeys(k for m in metrics for k in m))
    metric_artifact = write_csv(output / "window_metrics.csv", fields, metrics)
    selected_artifact = write_csv(output / "selected_windows.csv", ["id", "role"] + fields, selected)
    selection = {
        "schema_version": 1, "source_hourly_csv": str(source), "source_hourly_csv_sha256": sha(source),
        "window_days": 14, "window_boundary_timezone": "Asia/Tbilisi", "candidate_windows": len(metrics),
        "eligible_windows": len(eligible), "excluded_windows": len(metrics) - len(eligible),
        "eligibility": "All 336 hourly bars and the preceding-hour bar observed, positive reported volume on every one. Missing or zero-volume windows excluded before volatility ranking.",
        "eligibility_relaxed": False,
        "volatility_definition": "sqrt(sum_(h=1..336)(ln(C_h/C_(h-1)))^2); C_0 is the preceding hourly close. Dimensionless, not annualized.",
        "selection_rule": "Minimum hourly RV eligible window for calm_train; maximum RV among eligible windows disjoint from calm_train for volatile_train; maximum RV among eligible windows disjoint from both for volatile_holdout. All ties use earliest start date. No strategy P&L enters selection.",
        "holdout_definition": "Disjoint market path withheld from policy calibration. Retrospective volatility selection uses full hourly history; this is not temporal forward validation or an untouched statistical holdout after evaluation.",
        "direction_convention": "Positive IRR/USDT return is rial depreciation; USDT per rial parity is reciprocal.",
        "metrics": metric_artifact, "selected_windows_csv": selected_artifact, "windows": selected}
    write_json(output / "selected_windows.json", selection)
    return selection


def validate(prices: list[Decimal], volume: Decimal) -> None:
    op, high, low, close = prices
    if not all(p.is_finite() for p in prices) or not volume.is_finite():
        raise ValueError("Nonfinite OHLCV")
    if min(prices) <= 0 or not low <= min(op, close) <= max(op, close) <= high or volume < 0:
        raise ValueError(f"Invalid OHLCV: {prices}, {volume}")


def coverage(rows: list[dict], start: int, end: int, interval: int, volume_key: str) -> dict:
    stamps = [int(r["timestamp"]) for r in rows]
    missing = sorted(set(range(start, end, interval)) - set(stamps))
    if len(set(stamps)) != len(stamps) or any(t < start or t >= end or t % interval for t in stamps):
        raise ValueError("Duplicate, out-of-range or unaligned timestamps")
    longest_zero = run = 0
    previous = None
    for row in rows:
        ts = int(row["timestamp"])
        if Decimal(row[volume_key]) == 0:
            run = run + 1 if previous is not None and ts - previous == interval else 1
            longest_zero = max(longest_zero, run)
        else:
            run = 0
        previous = ts
    return {"expected_bars": (end - start) // interval, "actual_bars": len(rows),
            "missing_bars": len(missing), "missing_timestamps": missing,
            "zero_volume_bars": sum(Decimal(r[volume_key]) == 0 for r in rows),
            "flat_ohlc_bars": sum(len({r[k] for k in ("open", "high", "low", "close")}) == 1 for r in rows),
            "longest_consecutive_zero_volume_bars": longest_zero,
            "timestamp_differences_seconds": dict(sorted(Counter(b - a for a, b in zip(stamps, stamps[1:])).items())),
            "first_candle_open_utc": iso(stamps[0]) if stamps else None,
            "last_candle_end_utc_exclusive": iso(stamps[-1] + interval) if stamps else None}


def request_json(url: str, path: Path, reuse: Path, *, offline: bool, refresh: bool,
                 deadline: float, timeout: float, attempts: int) -> tuple[dict, dict]:
    meta_path = path.with_suffix(".meta.json")
    if not refresh and not path.exists() and reuse.exists() and reuse.with_suffix(".meta.json").exists():
        previous = json.loads(reuse.with_suffix(".meta.json").read_text())
        if previous["url"] == url and previous["sha256"] == sha(reuse):
            path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(reuse, path)
            previous["reused_exact_cache"] = {"file": str(reuse), "sha256": sha(reuse)}
            previous["raw_file"] = str(path)
            write_json(meta_path, previous)
    if path.exists() and meta_path.exists() and not refresh:
        meta = json.loads(meta_path.read_text())
        if meta["url"] != url or meta["sha256"] != sha(path):
            raise ValueError(f"Cached URL or raw hash differs: {path}")
        return json.loads(path.read_bytes(), parse_float=Decimal), meta
    if offline:
        raise ValueError(f"Offline raw cache missing: {path}")
    failures = []
    for attempt in range(attempts):
        if time.monotonic() >= deadline:
            raise ValueError("Native-minute download time budget exhausted")
        try:
            request = urllib.request.Request(url, headers={"User-Agent": "Tomax-14Day-Sandbox-Research/1.0"})
            with urllib.request.urlopen(request, timeout=min(timeout, max(1, deadline - time.monotonic()))) as response:
                body = response.read()
                meta = {"url": url, "retrieved_at_utc": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
                        "http_status": response.status, "http_date": response.headers.get("Date"),
                        "content_type": response.headers.get("Content-Type"), "raw_file": str(path),
                        "bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()}
            payload = json.loads(body, parse_float=Decimal)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(body)
            write_json(meta_path, meta)
            return payload, meta
        except (OSError, urllib.error.URLError, http.client.HTTPException) as error:
            failures.append({"attempt": attempt + 1, "observed_at_utc": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
                             "exception_type": type(error).__name__, "message": str(error)})
            write_json(path.with_suffix(".failure.json"), {"url": url, "attempts": failures,
                       "interpretation": "No candle payload obtained; no price or trade is inferred from this failed request."})
            if attempt == attempts - 1:
                raise
            time.sleep(min(2 ** attempt, max(0, deadline - time.monotonic())))
    raise RuntimeError("Unreachable request retry state")


def fetch_day(date: str, start: int, output: Path, reuse_root: Path, offline: bool, refresh: bool,
              deadline: float, timeout: float, attempts: int) -> dict:
    end = start + DAY
    url = WALLEX + "?" + urllib.parse.urlencode({"symbol": "USDTTMN", "resolution": "1", "from": start, "to": end - 1})
    name = f"IRR_1m_{date}"
    payload, meta = request_json(url, output / "raw" / f"{name}.json", reuse_root / "raw" / f"{name}.json",
                                 offline=offline, refresh=refresh, deadline=deadline, timeout=timeout, attempts=attempts)
    if payload.get("s") != "ok":
        raise ValueError(f"Wallex minute response unavailable: {date}: {payload}")
    keys = ("t", "o", "h", "l", "c", "v")
    if len({len(payload[k]) for k in keys}) != 1:
        raise ValueError("Wallex parallel-array lengths differ")
    rows = []
    for raw in zip(*(payload[k] for k in keys)):
        stamp = int(raw[0])
        prices = [Decimal(str(v)) * 10 for v in raw[1:5]]
        volume = Decimal(str(raw[5]))
        validate(prices, volume)
        rows.append(dict(zip(FIELDS, [stamp, iso(stamp), *(str(v) for v in prices), str(volume), stamp + 60, iso(stamp + 60)])))
    rows.sort(key=lambda r: r["timestamp"])
    cov = coverage(rows, start, end, 60, "volume_usdt")
    if cov["timestamp_differences_seconds"].get(60, 0) == 0:
        raise ValueError(f"Native minute interval not verified for {date}")
    artifact = write_csv(output / "daily" / f"{name}.csv", FIELDS, rows)
    print(f"{date}: {len(rows)}/1440 minute bars, {cov['zero_volume_bars']} zero-volume, {cov['missing_bars']} missing", flush=True)
    return {"local_date": date, "start_timestamp": start, "end_timestamp_exclusive": end,
            "start_utc": iso(start), "end_utc_exclusive": iso(end), "interval_seconds": 60,
            "price_units": "IRR per USDT", "volume_units": "USDT", **artifact, **cov, "request": meta}


def compare_hourly(hourly_file: Path, minute_rows: list[dict]) -> dict:
    source = {int(r["timestamp"]): r for r in read_csv(hourly_file)}
    grouped = defaultdict(list)
    for row in minute_rows:
        stamp = int(row["timestamp"])
        grouped[stamp - stamp % HOUR].append(row)
    differences = []
    compared = 0
    for stamp, rows in sorted(grouped.items()):
        if len(rows) != 60 or stamp not in source:
            continue
        compared += 1
        aggregate = {"open": Decimal(rows[0]["open"]), "close": Decimal(rows[-1]["close"]),
                     "high": max(Decimal(r["high"]) for r in rows), "low": min(Decimal(r["low"]) for r in rows),
                     "volume_usdt": sum(Decimal(r["volume_usdt"]) for r in rows)}
        diff = {key: {"minute_aggregate": str(v), "archived_hourly": source[stamp][key]}
                for key, v in aggregate.items() if v != Decimal(source[stamp][key])}
        if diff:
            differences.append({"timestamp": stamp, "datetime_utc": iso(stamp), "differences": diff})
    return {"complete_minute_hours_compared": compared, "differing_hours": len(differences),
            "differing_hour_count_by_field": dict(Counter(k for d in differences for k in d["differences"])),
            "differences": differences,
            "interpretation": "Exact Decimal OHLCV comparison. Disagreements are retained; no history is silently reconciled. Selection uses the fixed prior hourly archive and replay uses native minute responses."}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=Path("research/fx_inputs/IRR_1h.csv"))
    parser.add_argument("--reuse", type=Path, default=Path("research/fxswap_data"))
    parser.add_argument("--output", type=Path, default=Path("research/sandbox_data"))
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--offline", action="store_true")
    parser.add_argument("--refresh", action="store_true")
    parser.add_argument("--select-only", action="store_true")
    parser.add_argument("--cached-only", action="store_true", help="Use existing minute-day caches only; report remaining days as unavailable")
    parser.add_argument("--request-timeout", type=float, default=15, help="Seconds per public HTTP request")
    parser.add_argument("--attempts", type=int, default=2)
    parser.add_argument("--fetch-budget-seconds", type=float, default=120, help="Wall-clock budget for starting/retrying native-minute requests")
    parser.add_argument("--require-complete-minute", action="store_true", help="Fail after saving disclosures if any selected native-minute timestamp is unavailable")
    args = parser.parse_args()
    if (args.offline or args.cached_only) and args.refresh:
        parser.error("--offline/--cached-only and --refresh are mutually exclusive")
    if not 1 <= args.workers <= 8:
        parser.error("--workers must be between 1 and 8")
    if args.request_timeout <= 0 or args.attempts < 1 or args.fetch_budget_seconds <= 0:
        parser.error("Request timeout, attempts and fetch budget must be positive")
    args.output.mkdir(parents=True, exist_ok=True)
    source = args.output / "sources" / "IRR_1h.csv"
    hourly_snapshot = snapshot(args.source, source, offline=args.offline, refresh=args.refresh)
    hourly_manifest = args.output / "sources" / "fx_inputs_manifest.json"
    hourly_manifest_snapshot = snapshot(args.source.parent / "manifest.json", hourly_manifest, offline=args.offline, refresh=args.refresh)
    selection = select_windows(source, args.output)
    for window in selection["windows"]:
        print(f"SELECTED {window['id']}: {window['start_local_date']} to {window['end_local_date_exclusive']} exclusive, hourly RV={window['hourly_log_realized_volatility']:.10f}", flush=True)
    if args.select_only:
        return
    eth_file = args.output / "sources" / "ETH_USDT_1h.csv"
    eth_snapshot = snapshot(args.reuse / "ETH_USDT_1h.csv", eth_file, offline=args.offline, refresh=args.refresh)
    fxswap_manifest = args.output / "sources" / "fxswap_manifest.json"
    fxswap_snapshot = snapshot(args.reuse / "manifest.json", fxswap_manifest, offline=args.offline, refresh=args.refresh)
    eth_original = json.loads(fxswap_manifest.read_text())["eth_collateral_source"]
    if sha(eth_file) != eth_original["csv_sha256"]:
        raise ValueError("ETH archive disagrees with its source manifest")
    eth_rows = read_csv(eth_file)
    specs = []
    for window in selection["windows"]:
        for offset in range(14):
            start = window["start_timestamp"] + offset * DAY
            specs.append((str(datetime.fromtimestamp(start, LOCAL).date()), start))
    # Cache-only reproduction is useful even when the exchange was unreachable
    # for some dates: absent native candles remain absent, never interpolated.
    deadline = time.monotonic() + args.fetch_budget_seconds
    daily_sources = []
    unavailable = []
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = [(date, start, pool.submit(fetch_day, date, start, args.output, args.reuse,
                    args.offline or args.cached_only, args.refresh, deadline, args.request_timeout, args.attempts))
                   for date, start in specs]
        for date, start, future in futures:
            try:
                daily_sources.append(future.result())
            except (ValueError, OSError, urllib.error.URLError, http.client.HTTPException) as error:
                failure_file = args.output / "raw" / f"IRR_1m_{date}.failure.json"
                unavailable.append({"local_date": date, "start_timestamp": start,
                                    "end_timestamp_exclusive": start + DAY, "expected_native_minute_bars": 1440,
                                    "url": WALLEX + "?" + urllib.parse.urlencode({"symbol": "USDTTMN", "resolution": "1", "from": start, "to": start + DAY - 1}),
                                    "payload_obtained": False,
                                    "reason": f"{type(error).__name__}: {error}",
                                    "request_failure_file": str(failure_file) if failure_file.exists() else None})
    by_start = {d["start_timestamp"]: d for d in daily_sources}
    windows = []
    qa = {}
    for window in selection["windows"]:
        start, end = window["start_timestamp"], window["end_timestamp_exclusive"]
        days = [by_start[t] for t in range(start, end, DAY) if t in by_start]
        minute_rows = [r for d in days for r in read_csv(Path(d["csv_file"]))]
        artifact = write_csv(args.output / f"IRR_1m_{window['id']}.csv", FIELDS, minute_rows)
        cov = coverage(minute_rows, start, end, 60, "volume_usdt")
        hourly_rows = [r for r in read_csv(source) if start - HOUR <= int(r["timestamp"]) < end]
        for row in hourly_rows:
            stamp = int(row["timestamp"])
            row["candle_end_timestamp"] = stamp + HOUR
            row["candle_end_utc_exclusive"] = iso(stamp + HOUR)
        hourly_artifact = write_csv(args.output / f"IRR_1h_{window['id']}.csv", FIELDS, hourly_rows)
        hourly_cov = coverage(hourly_rows, start - HOUR, end, HOUR, "volume_usdt")
        eth_subset = [r for r in eth_rows if start - HOUR <= int(r["timestamp"]) < end]
        eth_artifact = write_csv(args.output / f"ETH_USDT_1h_{window['id']}.csv", list(eth_rows[0]), eth_subset)
        eth_cov = coverage(eth_subset, start - HOUR, end, HOUR, "volume_eth")
        qa[window["id"]] = compare_hourly(source, minute_rows)
        windows.append({**window, **artifact, **cov, "observed_interval_seconds": 60,
                        "native_minute_coverage_complete": cov["missing_bars"] == 0,
                        "daily_csv_files": [d["csv_file"] for d in days],
                        "hourly_fx": {**hourly_artifact, **hourly_cov, "interval_seconds": HOUR,
                                      "preceding_hour_included": True, "price_units": "IRR per USDT", "volume_units": "USDT"},
                        "eth_collateral": {**eth_artifact, **eth_cov, "interval_seconds": HOUR,
                                           "preceding_hour_included": True, "price_units": "USDT per ETH", "volume_units": "ETH"}})
    write_json(args.output / "hourly_aggregation_comparison.json", qa)
    manifest = {
        "schema_version": 1, "generated_at_utc": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
        "timestamp_convention": "Unix seconds UTC at candle open. Close known only at candle_end_timestamp, exclusive. Asia/Tbilisi midnight defines day and 14-day window boundaries.",
        "selection": selection,
        "selection_artifacts": [{"file": str(args.output / f), "sha256": sha(args.output / f)}
                                for f in ("selected_windows.json", "selected_windows.csv", "window_metrics.csv")],
        "input_snapshots": [hourly_snapshot, hourly_manifest_snapshot, eth_snapshot, fxswap_snapshot],
        "exchange": "Wallex", "symbol": "USDTTMN", "requested_resolution": "1", "verified_interval_seconds": 60,
        "normalization": "Native TMN OHLC multiplied by exactly 10 to IRR per USDT; reported USDT base volume unchanged. No interpolation, forward fill or synthetic ticks.",
        "documentation_url": "https://api-docs.wallex.ir/", "windows": windows, "minute_sources": daily_sources,
        "unavailable_minute_days": unavailable,
        "native_minute_coverage_complete": not unavailable and all(w["missing_bars"] == 0 for w in windows),
        "fallback_resolution": {"actual_observed_interval_seconds": HOUR,
                                "csv_window_key": "hourly_fx",
                                "replay_convention": "At a synthetic actor-event time, use only the most recent hourly close whose candle_end_timestamp is <= event time. Mark age is explicit state; a repeated last-known mark is not a fresh market observation. Never reveal next-hour close or assume a within-hour price path.",
                                "outage_convention": "Live/public-feed request failure is stale input; pause oracle-dependent operations under the controller's staleness rule. Do not substitute future prices or infer no movement.",
                                "continuous_parity_claim_supported": False},
        "eth_collateral_source": {**eth_original, "csv_file": str(eth_file), "csv_sha256": sha(eth_file)},
        "minute_vs_existing_hourly": {"file": str(args.output / "hourly_aggregation_comparison.json"),
                                       "sha256": sha(args.output / "hourly_aggregation_comparison.json")},
        "limitations": [
            "Volatility ranking is retrospective market-path selection, independent of policy P&L. The disjoint holdout is not temporal forward validation; reuse for tuning removes its holdout status.",
            "Zero-volume supplied minute candles are retained and counted, not treated as independently observed trades. Missing timestamps are left missing and disclosed.",
            "Single-exchange USDT/TMN is not an official USD fix or cross-venue executable FX composite. USDT/USD parity is an additional modeling assumption.",
            "OHLC does not reveal intra-minute high/low ordering, spreads, depth, fills, slippage or continuous oracle compliance.",
            "ETH collateral inputs remain hourly. Only closed hourly bars may be revealed causally; intra-hour collateral/liquidation paths remain unobserved.",
            "Native-minute coverage may be partial: use window.hourly_fx for complete observed-hourly replay. Never present a last-known hourly mark or actor-event grid as observed minute prices; no continuous or intra-hour 3% parity claim is supported.",
            "Exchange history may be revised. Raw bytes, retrieval timestamps, request URLs and hashes are retained; --offline is the immutable reproduction route."
        ]}
    write_json(args.output / "manifest.json", manifest)
    print(f"Completed {len(windows)} disjoint windows: {sum(w['actual_bars'] for w in windows)} native-minute bars; {sum(w['missing_bars'] for w in windows)} missing", flush=True)
    if args.require_complete_minute and not manifest["native_minute_coverage_complete"]:
        raise SystemExit("Native-minute archive incomplete; hourly fallback and exact coverage disclosures saved")


if __name__ == "__main__":
    main()
