"""Reproduce FXSwap capacity and conditional historical IRR research replays."""
from __future__ import annotations

import csv
import datetime as dt
import hashlib
import json
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from model.fxswap_backtest import (ZONE,Book,eth_history,issue,load_csv,replay,static_capacity)

OUT=ROOT/'results'


def csv_out(path,rows):
    if not rows:return
    with path.open('w',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=list(rows[0]))
        writer.writeheader();writer.writerows(rows)


def main():
    OUT.mkdir(exist_ok=True)
    selection=json.loads((ROOT/'research/fxswap_data/selected_days.json').read_text())['selected_days']
    eth=eth_history()
    capacity=static_capacity(steps=1000)
    bid_capacity=static_capacity(steps=1000,fee_inclusive=True)
    debt_multiple=.5*capacity['additional_debt']/10000
    starts=dt.datetime(2026,4,25,tzinfo=ZONE).timestamp()
    ends=dt.datetime(2026,10,21,tzinfo=ZONE).timestamp()
    hourly=[r for r in load_csv(ROOT/'research/fx_inputs/IRR_1h.csv') if starts<=r['timestamp']<ends]
    minutes={day['local_date']:load_csv(ROOT/f"research/fxswap_data/IRR_1m_{day['local_date']}.csv")
             for day in selection}
    mixed=[]
    for row in hourly:
        day=dt.datetime.fromtimestamp(row['timestamp'],ZONE).date().isoformat()
        if day not in minutes:mixed.append(row)
    for rows in minutes.values():mixed.extend(rows)
    mixed.sort(key=lambda r:r['timestamp'])
    summaries=[];daily_rows=[];cold_rows=[];sensitivity=[]
    metadata=dict(pool_template='0x027B40F5917FCd0eac57d7015e120096A5F92ca9',
        snapshot_block=26241105,external_seed_definition='USDT paid in; equal-value own-token leg is separately minted as bootstrap liability',
        lp_debt_share=.96,eth_debt_share=.04,actual_lp_ltv=.874,eth_opening_ltv=.67,
        main_debt_multiple=debt_multiple,main_debt_policy='50% of fixed-FX instantaneous issuance boundary; illustrative, not recommended',
        external_execution_cost=.0005,minimum_arbitrage_profit_usdt=.5,
        path='Observed candle closes; close supplied at candle end, ETH last known hourly close',
        finite_inventory='No own-token sales beyond issued supply outside pool; all issued tokens initially in pool',
        unlimited_inventory='Diagnostic clearing benchmark: hypothetical outside route can supply tokens beyond total issued. Deficits reported; infeasible without additional issuance/backing mechanism.',
        refuels='Quote-only daily spend at first observed close of local day; source seven-day unlock and 10% outstanding-share cap; no preloaded buffer',
        full_window=dict(start_local='2026-04-25',end_local_exclusive='2026-10-21',nominal_days=179,
                         hourly_observations=len(hourly),expected_hours=179*24,mixed_observations=len(mixed),
                         missing_hourly_bars=179*24-len(hourly),minute_days=list(minutes)),
        pnl='Recoverable inventory at external parity; LP versus HODL; treasury LP less bootstrap liability and spent refuels; no interest, hedge, redemption or realized liquidation simulation',
        gas='Refuel transaction assumed 250000 gas; no measured deployment gas. Arbitrage gas paid by arbitrageurs through min-profit assumption, not treasury.',
        inputs_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
                       for p in [ROOT/'research/fx_inputs/IRR_1h.csv',ROOT/'research/fxswap_data/ETH_USDT_1h.csv',
                                 *sorted((ROOT/'research/fxswap_data').glob('IRR_1m_*.csv'))]})
    print('Capacity:',capacity['additional_debt'],'bid-inclusive:',bid_capacity['additional_debt'],flush=True)
    static=dict(main=capacity,fee_inclusive=bid_capacity,
                convergence=[static_capacity(steps=n) for n in (20,100,400)],
                external_seed_cases=[static_capacity(seed=e,steps=100) for e in range(10000,50001,10000)],
                total_lp_value_cases=[dict(total_initial_lp=e,external_seed=e/2,
                    additional_debt=capacity['additional_debt']*e/20000,
                    bootstrap_tokens=e/2) for e in range(10000,50001,10000)])
    (OUT/'fxswap_capacity.json').write_text(json.dumps(static,indent=2)+'\n')

    def run(label,bars,seed,budget,finite=True,debt=None,record=False,**kwargs):
        d=seed*debt_multiple if debt is None else debt
        result=replay(bars,seed,d,budget,eth,finite_inventory=finite,record=record,**kwargs)
        summary=dict(label=label,**result['summary']);summaries.append(summary)
        for day,row in result['daily'].items():
            daily_rows.append(dict(label=label,local_date=day,external_seed=seed,daily_refuel_budget=budget,
                                   finite_inventory=finite,**row))
        if record:csv_out(OUT/f'fxswap_series_{label}.csv',result['series'])
        print(label,'spot',round(summary['max_spot_error_pct'],3),'center',round(summary['max_center_error_pct'],3),
              'fuel',round(summary['refuel_spent'],2),'net equity P&L',round(summary['treasury_equity_pnl_after_refuels'],2),flush=True)
        return summary

    # Continuous established-pool replay with all six actual minute days.
    for finite in (True,False):
        for ratio in (0,.0001,.0003,.001,.003,.01):
            label=f"long_10k_{'finite' if finite else 'outside'}_{ratio:g}"
            run(label,mixed,10000,10000*ratio,finite,record=ratio in (0,.001))
    for finite in (True,False):
        for ratio in (0,.001):
            run(f"long_50k_{'finite' if finite else 'outside'}_{ratio:g}",mixed,50000,50000*ratio,finite)

    # Fresh one-day launches distinguish regime effects without carry-over state.
    for day in selection:
        date=day['local_date']
        for seed in (10000,50000):
            for ratio in (0,.001):
                label=f"cold_{date}_{seed}_{ratio:g}"
                s=run(label,minutes[date],seed,seed*ratio,record=seed==10000 and ratio==0)
                cold_rows.append(dict(local_date=date,regime=day['regime'],
                    hourly_log_rv_pct=100*day['hourly_log_realized_volatility'],
                    irr_per_usdt_return_pct=100*day['open_to_close_return'],**s))
        # Wider refuel sensitivity on independently chosen high-volatility days.
        if day['regime']=='high':
            for ratio in (.0001,.0003,.003,.01):
                s=run(f"cold_{date}_10000_{ratio:g}",minutes[date],10000,10000*ratio)
                sensitivity.append(s)
            for profit in (5,25):
                sensitivity.append(run(f'gasfloor_{date}_{profit}',minutes[date],10000,0,min_profit=profit))
            for path in ('ohlc','olhc'):
                sensitivity.append(run(f'intrabar_{date}_{path}',minutes[date],10000,0,path=path))

    # Hourly-only debt and ETH opening-LTV sensitivities (not extra minute claims).
    for fraction in (0,.25,1):
        sensitivity.append(run(f'debt_fraction_{fraction}',hourly,10000,0,debt=capacity['additional_debt']*fraction))
    for ltv in (.60,.75):
        sensitivity.append(run(f'eth_ltv_{ltv}',hourly,10000,0,eth_ltv=ltv))
    outputs=dict(assumptions=metadata,capacity=static,selected_days=selection,
                 summaries=summaries,cold_days=cold_rows,sensitivities=sensitivity)
    (OUT/'fxswap_backtest.json').write_text(json.dumps(outputs,indent=2,allow_nan=False)+'\n')
    csv_out(OUT/'fxswap_summaries.csv',summaries)
    csv_out(OUT/'fxswap_daily.csv',daily_rows)
    csv_out(OUT/'fxswap_cold_days.csv',cold_rows)
    print('Saved',len(summaries),'runs,',len(daily_rows),'daily rows.',flush=True)


if __name__=='__main__':main()
