"""Declare the additional-reserve sensitivity for the appreciation stress."""
from pathlib import Path
import argparse,json,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from model.sandbox.simulate import replay


def main():
    p=argparse.ArgumentParser();p.add_argument('--evm',action='store_true');a=p.parse_args();rows=[]
    for reserve in (.1,.25,.5,1):
        c=dict(raw_a=600000,reserve_multiple=reserve,initial_debt_multiple=.5,origination_band=.03,keeper={})
        s,*_=replay('volatile_train',c,stress='up_jump',audit=a.evm and reserve==.5)
        rows.append(s)
    result=dict(stress='synthetic20% parity appreciation on volatile training path',runs=rows,
        note='additional sensitivity, not retuned holdout; existing livepaper funding remains frozen at10%')
    (ROOT/'results/sandbox-funding-envelope.json').write_text(json.dumps(result,indent=2)+'\n')
    for r in rows:print(r['config']['reserve_multiple'],r['max_post_keeper_error'],r['post_keeper_breaches'])


if __name__=='__main__':main()
