#!/usr/bin/env python3
"""Initialize, inspect or take ONE current step of a finite mock paper run.

Initialization is paused, has no invented prices, and starts no clock. To
activate, supply passing historical accounting/EVM gate evidence bound to the
entire normalized configuration hash printed by status. A live paper experiment
does not require a perfect historical 3% outcome. No orders, keys or chain calls.

Examples (run from any directory):
  python3 tools/paper_trading.py init results/paper/checkpoint.json --config config.json
  python3 tools/paper_trading.py status results/paper/checkpoint.json --probe
  python3 tools/paper_trading.py step results/paper/checkpoint.json --activate --gate-evidence gate.json
  python3 tools/paper_trading.py step results/paper/checkpoint.json

gate.json:
  {"historical_gate_passed":true,"policy_config_sha256":"<status hash>","note":"..."}
The first successful actual observation pair starts an absolute14day clock.
Feed failures pause decisions; that clock continues. This command never loops.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict
import json
from pathlib import Path
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from model.sandbox import paper


def probe(feeds):
    observation = feeds.collect()
    return {"checked_at": observation["checked_at"], "errors": observation["errors"],
            "quotes": {name: asdict(quote) for name, quote in observation["quotes"].items()}}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="command", required=True)
    init = sub.add_parser("init", help="Create a paused checkpoint, without market placeholders or a running clock")
    init.add_argument("checkpoint", type=Path)
    init.add_argument("--config", type=Path)
    inspect = sub.add_parser("status", help="Inspect state; optional public-adapter probe never starts the run")
    inspect.add_argument("checkpoint", type=Path)
    inspect.add_argument("--probe", action="store_true")
    step = sub.add_parser("step", help="Fetch current public observations and make at most one mock decision")
    step.add_argument("checkpoint", type=Path)
    step.add_argument("--activate", action="store_true")
    step.add_argument("--gate-evidence", type=Path)
    for command in (inspect, step):
        command.add_argument("--timeout", type=float, default=3.)
        command.add_argument("--attempts", type=int, default=2)
    args = parser.parse_args(argv)
    try:
        if args.command == "init":
            config = json.loads(args.config.read_text()) if args.config else {}
            with paper.checkpoint_lock(args.checkpoint):
                if args.checkpoint.exists():
                    raise FileExistsError("Checkpoint already exists; init never resets finite balances or the clock")
                data = paper.new_checkpoint(config, int(time.time()))
                paper.save_checkpoint(args.checkpoint, data)
            result = paper.status(data)
        elif args.command == "status":
            data = paper.load_checkpoint(args.checkpoint)
            result = paper.status(data)
            if args.probe:
                result["adapter_probe"] = probe(paper.PublicFeeds(args.timeout, args.attempts))
        else:
            with paper.checkpoint_lock(args.checkpoint):
                data = paper.load_checkpoint(args.checkpoint)
                now = int(time.time())
                stopped = data["ends_at"] is not None and now >= data["ends_at"]
                if stopped or data.get("fatal_error"):
                    paper.advance(data, now, None, None)
                elif data["started_at"] is None and not args.activate:
                    paper.advance(data, now, None, None)
                else:
                    evidence = json.loads(args.gate_evidence.read_text()) if args.gate_evidence else None
                    gate_passed = paper.gate_matches(evidence, data)
                    if data["started_at"] is None and not gate_passed:
                        paper.advance(data, now, None, None, activate=args.activate, gate_passed=False)
                    else:
                        try:
                            keeper = paper.load_keeper(data["config"])
                        except Exception as error:
                            keeper = None
                            paper.advance(data, now, None, None, activate=args.activate, gate_passed=gate_passed)
                            data["last_result"]["controller_error"] = f"{type(error).__name__}: {error}"
                        if keeper is not None:
                            observation = paper.PublicFeeds(args.timeout, args.attempts).collect()
                            # Receipt may be later than request start: decisions use
                            # wall time AFTER both bounded adapters have returned.
                            now = int(time.time())
                            if gate_passed:
                                data["gate_evidence"] = evidence
                            paper.advance(data, now, observation["quotes"].get("IRR_USDT"),
                                          observation["quotes"].get("ETH_USDT"), keeper=keeper,
                                          activate=args.activate, gate_passed=gate_passed,
                                          feed_errors=observation["errors"])
                paper.save_checkpoint(args.checkpoint, data)
            result = paper.status(data)
        print(json.dumps(result, indent=2, allow_nan=False))
        return 0
    except BlockingIOError:
        print(json.dumps({"status": "busy", "reason": "another_step_holds_checkpoint_lock", "mock_only": True}))
        return 0
    except (OSError, ValueError, TypeError, AssertionError, KeyError) as error:
        print(json.dumps({"status": "error", "error": f"{type(error).__name__}: {error}", "mock_only": True}), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
