"""Publication plots. Optional dependency: matplotlib (not needed to replay)."""
import csv
import json
import datetime as dt
from pathlib import Path
from zoneinfo import ZoneInfo

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'docs/assets'
ZONE=ZoneInfo('Asia/Tbilisi')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,
                     'axes.spines.right':False,'axes.grid':True,'grid.alpha':.18,
                     'figure.facecolor':'white','axes.facecolor':'white','text.parse_math':False})


def load(label):
    with (ROOT/f'results/fxswap_series_{label}.csv').open() as handle:
        return [{k:float(v) for k,v in row.items()} for row in csv.DictReader(handle)]


def times(rows):return [dt.datetime.fromtimestamp(r['timestamp'],ZONE) for r in rows]


def main():
    summaries={r['label']:r for r in json.loads((ROOT/'results/fxswap_backtest.json').read_text())['summaries']}
    cases=[('long_10k_finite_0','Finite supply; no refuel','#b84336'),
           ('long_10k_outside_0','Hypothetical outside supply; no refuel','#2276a8'),
           ('long_10k_outside_0.001','Hypothetical outside supply; $10/day','#39835a')]
    fig,axes=plt.subplots(3,1,figsize=(11,10),sharex=True,layout='constrained')
    first=load(cases[0][0]);x=times(first)
    axes[0].plot(x,[r['reference'] for r in first],color='#202b38',lw=2,label='Wallex IRR parity (USDT)')
    for label,name,color in cases:
        rows=load(label);x=times(rows)
        axes[0].plot(x,[r['spot'] for r in rows],color=color,lw=1,label=name)
        axes[1].plot(x,[r['treasury_equity_after_refuels']-summaries[label]['treasury_equity_initial'] for r in rows],
                     color=color,lw=1.2,label=name)
        axes[2].plot(x,[100*(r['spot']/r['reference']-1) for r in rows],color=color,lw=1)
    axes[0].set_ylabel('Normalized USDT / token');axes[0].legend(fontsize=8,loc='lower left')
    axes[1].set_ylabel('Treasury equity change (USDT)')
    axes[1].text(.01,.04,'LP claim less bootstrap-token liability and spent refuels; no interest or liquidations',
                 transform=axes[1].transAxes,fontsize=8,color='#44505e')
    axes[2].axhspan(-3,3,color='#4c8b57',alpha=.13,label='±3%')
    axes[2].set_ylabel('Spot / parity − 1 (%)');axes[2].set_xlabel('2026 · Asia/Tbilisi')
    fig.suptitle('Frozen debt after launch · $10k external seed · ~$15.8k new debt · 96% LP / 4% ETH\n'
                 'Observed closes: hourly history, actual minute bars on six selected days',fontsize=13)
    fig.savefig(OUT/'fxswap-history.png',dpi=170)
    fig.savefig(OUT/'fxswap-history.pdf')
    plt.close(fig)

    dates=['2026-04-26','2026-08-12','2026-08-29','2026-06-09','2026-06-15','2026-05-24']
    fig,axes=plt.subplots(3,2,figsize=(12,10),layout='constrained')
    for ax,date,regime in zip(axes.flat,dates,['Calm','Calm','Median','Median','High RV','High RV']):
        rows=load(f'cold_{date}_10000_0');hours=[(r['timestamp']-rows[0]['timestamp'])/3600 for r in rows]
        ax.plot(hours,[r['reference'] for r in rows],color='#202b38',label='Wallex parity',lw=1.4)
        ax.plot(hours,[r['spot'] for r in rows],color='#2276a8',label='Pool spot',lw=1)
        ax.plot(hours,[r['center'] for r in rows],color='#b17728',label='Liquidity center',lw=1,ls='--')
        ax.set_title(f'{regime} · {date}',fontsize=11);ax.set_xlim(0,24)
        ax.set_xlabel('Hours since local midnight');ax.set_ylabel('USDT / normalized token')
    axes[0,0].legend(fontsize=8)
    fig.suptitle('Independent one-day launches · $10k external seed · ~$15.8k new debt · no refuels\n'
                 'Finite issued supply; conditional arbitrage after observed minute closes',fontsize=13)
    fig.savefig(OUT/'fxswap-selected-days.png',dpi=170)
    fig.savefig(OUT/'fxswap-selected-days.pdf')
    plt.close(fig)
    print('Saved FXSwap PNG and PDF figures')


if __name__=='__main__':main()
