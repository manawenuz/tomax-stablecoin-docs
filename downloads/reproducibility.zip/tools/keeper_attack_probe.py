"""Matched no-attack counterfactual for finite treasury-keeper extraction."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from model.sandbox.state import Sandbox,Rejected
from model.sandbox.policies import Keeper
from model.fxswap import FXParams


def run():
    rows=[]
    for a in (600000,200000):
        for ref in (.9,1.08,1):
            s=Sandbox.seeded(10000,2500,2000,0,FXParams(raw_a=a))
            for name,q,e in [('lp',30000,1),('eth',10000,10),('attack',20000,1)]:s.add_actor(name,q,e)
            s.report(1,2000,0,0,1);s.open_bundle('lp','eth',5000,0)
            s.observe_market(ref,2000,60);s.report(ref,2000,60,60,2)
            k=Keeper({});baseline=s.fork();k.run(baseline,60);k.run(baseline,60)
            for amount in (1,10,50,100,200,500,1000,2000,5000,10000):
                t=s.fork()
                try:
                    got=t.swap('attack',0,amount,60);k.run(t,60);t.swap('attack',1,got,60)
                    pre=t.pool.spot_price()/ref-1;k.run(t,60)
                    profit=t.wallets['attack'].quote-20000-(1-t.wallets['attack'].eth)*2000
                    rows.append(dict(raw_a=a,reference=ref,front_quote=amount,
                        realized_quote_profit=t.wallets['attack'].quote-20000,net_profit_after_gas=profit,
                        residual_acquired_tokens=t.wallets['attack'].stable,
                        protocol_delta_vs_no_attack=t.protocol_equity()-baseline.protocol_equity(),
                        lp_borrower_delta=t.actor_equity('lp')-baseline.actor_equity('lp'),
                        eth_borrower_delta=t.actor_equity('eth')-baseline.actor_equity('eth'),
                        error_after_attacker_close=pre,error_after_second_keeper=t.pool.spot_price()/ref-1))
                except Rejected as exc:rows.append(dict(raw_a=a,reference=ref,front_quote=amount,rejected=str(exc)))
    best=[]
    for a in (600000,200000):
        for ref in (.9,1.08,1):
            best.append(max((x for x in rows if x['raw_a']==a and x['reference']==ref and 'net_profit_after_gas'in x),
                            key=lambda x:x['net_profit_after_gas']))
    return dict(all_probes=rows,best_by_launch_A_and_reference=best,
                warning='discrete myopic sizes, not maximum possible MEV; no external own-token venue')


if __name__=='__main__':
    r=run();(ROOT/'results/sandbox-attack.json').write_text(json.dumps(r,indent=2)+'\n')
    print(json.dumps(r['best_by_launch_A_and_reference'],indent=2))
