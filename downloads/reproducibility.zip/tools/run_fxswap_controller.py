"""Conditional above-peg borrowing demand; explicitly funded expansion sensitivity."""
import datetime as dt
import json
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from model.fxswap_backtest import ZONE,ETH_LTV,eth_history,load_csv,replay
from tools.run_fxswap_experiments import csv_out


def main():
    data=json.loads((ROOT/'results/fxswap_backtest.json').read_text())
    meta=data['assumptions'];w=meta['full_window']
    start=dt.datetime(2026,4,25,tzinfo=ZONE).timestamp();end=dt.datetime(2026,10,21,tzinfo=ZONE).timestamp()
    bars=[r for r in load_csv(ROOT/'research/fx_inputs/IRR_1h.csv') if start<=r['timestamp']<end
          and dt.datetime.fromtimestamp(r['timestamp'],ZONE).date().isoformat() not in w['minute_days']]
    for date in w['minute_days']:bars.extend(load_csv(ROOT/f'research/fxswap_data/IRR_1m_{date}.csv'))
    bars.sort(key=lambda r:r['timestamp']);eth=eth_history();runs=[];daily=[]
    cases=[(10000,cap,fuel) for cap in (.5,2) for fuel in (0,.001,.003)]+[(50000,2,.001)]
    for seed,cap,fuel in cases:
        label=f'growth_{seed}_{cap}_{fuel:g}'
        r=replay(bars,seed,seed*meta['main_debt_multiple'],seed*fuel,eth,
                 daily_new_debt_cap=seed*cap,record=True,eth_ltv=ETH_LTV)
        s=dict(label=label,**r['summary']);runs.append(s)
        daily.extend(dict(label=label,local_date=day,**row) for day,row in r['daily'].items())
        if seed==10000 and cap==2 and fuel==.001:
            csv_out(ROOT/'results/fxswap_series_growth.csv',r['series'])
        print(label,'added',round(s['controller_added_debt']),
              'LP cash',round(s['controller_lp_net_quote_cash']),
              'ETH posted',round(s['controller_eth_collateral_posted_usdt']),
              'spot error',round(s['max_spot_error_pct'],3),flush=True)
    result=dict(assumptions=dict(trigger=1.025,target=1.01,total_new_debt_cap_seed_multiple=100,
        cohorts_seed_multiple=.05,reference='External FX used for loan valuation and keeper trigger; not injected into pool EMA',
        demand='Assume independently funded new borrowers always available up to each cap; no organic demand evidence',
        debt_units='Normalized tokens at launch value; current USDT debt value changes with IRR parity',
        eth_opening_ltv=ETH_LTV,
        collateral=f"Same 96% LP / 4% ETH, .874 LP and {ETH_LTV:.2f} ETH opening LTV; new receipts bought and locked, all minted tokens sold",
        accounting='New LP equity contributions excluded from borrower equity P&L; quote cash is net of LP loan sale proceeds, ETH is gross collateral posted at each entry; treasury equity remains seed LP less bootstrap liability/refuels, excluding gas'),
        summaries=runs,daily=daily)
    (ROOT/'results/fxswap_growth.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    csv_out(ROOT/'results/fxswap_growth.csv',runs)
    csv_out(ROOT/'results/fxswap_growth_daily.csv',daily)
    print('Saved growth sensitivity',flush=True)


if __name__=='__main__':main()
