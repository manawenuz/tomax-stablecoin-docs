"""Train only on two fixed paths; freeze policy before disjoint holdout.

Run with /tmp/tomax-evm/bin/python tools/run_sandbox.py --evm to verify every
selected hourly run's committed AMM action against genuine pinned bytecode.
"""
from __future__ import annotations
import argparse,csv,json,sys
from pathlib import Path
from copy import deepcopy
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from model.sandbox.simulate import replay


def write_csv(path,rows):
    if not rows:return
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--evm',action='store_true')
    parser.add_argument('--output',type=Path,default=ROOT/'results');args=parser.parse_args()
    out=args.output;out.mkdir(parents=True,exist_ok=True);train=[]
    # Round 1 was the isolated debt-route diagnosis. This round changes launch
    # concentration and explicitly funded reserves, with the same actor grid.
    for raw_a in (600000,200000):
        for reserve in (0,.1,.25,.5):
            for window in ('calm_train','volatile_train'):
                c=dict(raw_a=raw_a,reserve_multiple=reserve,initial_debt_multiple=.5,origination_band=.03,keeper={})
                s,*_=replay(window,c);train.append(s)
    groups=[]
    for a in (600000,200000):
        for r in (0,.1,.25,.5):
            rows=[s for s in train if s['config']['raw_a']==a and s['config']['reserve_multiple']==r]
            score=(sum(x['post_keeper_breaches'] for x in rows),sum(x['bad_debt'] for x in rows),
                   sum(x['pending'] for x in rows),r,round(max(x['max_post_keeper_error'] for x in rows),6),
                   -sum(x['protocol_equity_change'] for x in rows))
            groups.append((score,deepcopy(rows[0]['config'])))
    score,selected=min(groups,key=lambda x:x[0])
    # Freeze before touching held-out P&L. Later stress failures do not silently
    # rewrite the policy; a new round would require a newly declared holdout.
    selection=dict(config=selected,training_score=score,selection_order=['sampled postkeeper breaches','bad debt',
        'pending queue','extra reserve capital','worst postkeeper error','protocol equity'],
        holdout_used_for_selection=False)
    (out/'sandbox-selection.json').write_text(json.dumps(selection,indent=2)+'\n')
    final=[];traces={};events={};attacks={}
    for seed in (10000,30000,50000):
        for window in ('calm_train','volatile_train','volatile_holdout'):
            key=f'{window}_{seed}';s,t,e,a=replay(window,selected,seed,audit=args.evm)
            final.append(s);traces[key]=t;events[key]=e;attacks[key]=a
    comparisons=[]
    for mode in ('issuance','inventory'):
        for window in ('calm_train','volatile_train','volatile_holdout'):
            c=dict(raw_a=600000,reserve_multiple=.25,initial_debt_multiple=.5,
                   origination_band=None if mode=='issuance' else .03,
                   keeper=dict(mode=mode,preflight_liquidations=mode!='issuance'))
            s,*_=replay(window,c);comparisons.append(s)
    stress=[]
    for name in ('down_jump','up_jump','eth_crash','feed_outage','keeper_outage','devaluation_outage','bank_run'):
        s,t,e,a=replay('volatile_train',selected,stress=name,audit=args.evm)
        stress.append(s);traces[f'stress_{name}']=t;events[f'stress_{name}']=e;attacks[f'stress_{name}']=a
    minute=[]
    for window in ('calm_train','volatile_holdout'):
        s,t,e,a=replay(window,selected,minutes=True)
        minute.append(s);traces[f'partial_minutes_{window}']=t
    # Capacity sweep is a funded historical scenario, not an optimized supply
    # ceiling. Higher debt cannot magically be made safe by passing spot once.
    capacity=[]
    for multiple in (.5,1,2,5):
        for window in ('calm_train','volatile_train'):
            c=deepcopy(selected);c['initial_debt_multiple']=multiple
            c['debt_ceiling_multiple']=max(2,multiple)
            try:s,*_=replay(window,c,attack=True);capacity.append(s)
            except ValueError as exc:capacity.append(dict(window=window,initial_debt_multiple=multiple,rejected=str(exc)))
    result=dict(round=3,prior_round='sandbox-round2.json',
                changes=['shared observed-block clock for all actor helpers, matching paper ordering',
                         'keeper outage covers nested actor helpers','active loan impairment in marked treasury equity',
                         'combineddevaluation and feed outage stress'],
                holdout_status='disjoint validation path reused after security guard review; not untouched or forward validation',
                selection=selection,training=train,selected_runs=final,comparisons=comparisons,
                stress=stress,partial_native_minutes=minute,capacity=capacity,
                limitations=['No intrahour path where native minutes unavailable','myopic discrete adversarial action grid',
                    'mock lending/oracle/ETH venue; genuine pool operations when evm flag set',
                    'zero borrowing interest and quote yield isolate marketmaking','USDT treated as quote USD',
                    'no unbounded capital or outside own-token exchange','heldout path is disjoint, not forward temporal validation'])
    (out/'sandbox.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    (out/'sandbox-events.json').write_text(json.dumps(dict(events=events,attacks=attacks),indent=2)+'\n')
    for key,rows in traces.items():write_csv(out/f'sandbox-trace-{key}.csv',rows)
    cols=('window','seed','stress','max_pre_keeper_error','max_after_actor_error','max_committed_transaction_error',
          'max_post_keeper_error','post_keeper_breaches','finite_quote_breaches','protocol_equity_change','peak_debt',
          'final_debt','bad_debt','pending','keeper_gas_eth_per_day','refuel_quote')
    write_csv(out/'sandbox-summary.csv',[{k:r.get(k) for k in cols} for r in final+comparisons+stress+minute])
    print(json.dumps(dict(selected=selected,runs=len(final),stress=len(stress),
            max_error=max(r['max_post_keeper_error'] for r in final),
            breaches=sum(r['post_keeper_breaches'] for r in final),evm=args.evm),indent=2))


if __name__=='__main__':main()
